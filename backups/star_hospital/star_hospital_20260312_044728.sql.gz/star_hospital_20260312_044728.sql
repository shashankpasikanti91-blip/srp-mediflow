--
-- PostgreSQL database dump
--

\restrict wEFKh0iGlqsaaLw4Euju8mL9VyQgyZ3pMtSNJMUDjgIMEiInWl1uTUBkslv4IUq

-- Dumped from database version 17.8
-- Dumped by pg_dump version 17.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointments; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.appointments (
    id integer NOT NULL,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20),
    patient_aadhar character varying(20) DEFAULT ''::character varying,
    age character varying(10) DEFAULT ''::character varying,
    issue text DEFAULT ''::text,
    doctor_name character varying(150) DEFAULT ''::character varying,
    department character varying(100) DEFAULT ''::character varying,
    appointment_date date,
    appointment_time character varying(20) DEFAULT ''::character varying,
    status character varying(30) DEFAULT 'pending'::character varying,
    source character varying(30) DEFAULT 'chatbot'::character varying,
    notes text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    patient_id integer,
    reminder_sent boolean DEFAULT false,
    reminder_sent_at timestamp without time zone
);


ALTER TABLE public.appointments OWNER TO ats_user;

--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.appointments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointments_id_seq OWNER TO ats_user;

--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.appointments_id_seq OWNED BY public.appointments.id;


--
-- Name: attendance; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.attendance (
    id integer NOT NULL,
    staff_name character varying(150) NOT NULL,
    action character varying(20) NOT NULL,
    notes text DEFAULT ''::text,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attendance OWNER TO ats_user;

--
-- Name: attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attendance_id_seq OWNER TO ats_user;

--
-- Name: attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.attendance_id_seq OWNED BY public.attendance.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    client_id integer,
    username character varying(80) DEFAULT 'system'::character varying,
    role character varying(20) DEFAULT ''::character varying,
    action character varying(200) NOT NULL,
    details text DEFAULT ''::text,
    ip_address character varying(45) DEFAULT ''::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_log OWNER TO ats_user;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO ats_user;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: bed_assignments; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.bed_assignments (
    id integer NOT NULL,
    bed_id integer,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    admitted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    discharged_at timestamp without time zone,
    notes text DEFAULT ''::text
);


ALTER TABLE public.bed_assignments OWNER TO ats_user;

--
-- Name: bed_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.bed_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bed_assignments_id_seq OWNER TO ats_user;

--
-- Name: bed_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.bed_assignments_id_seq OWNED BY public.bed_assignments.id;


--
-- Name: beds; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.beds (
    id integer NOT NULL,
    ward_id integer,
    bed_number character varying(20) NOT NULL,
    bed_type character varying(50) DEFAULT 'General'::character varying,
    status character varying(20) DEFAULT 'available'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.beds OWNER TO ats_user;

--
-- Name: beds_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.beds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.beds_id_seq OWNER TO ats_user;

--
-- Name: beds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.beds_id_seq OWNED BY public.beds.id;


--
-- Name: bill_items; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.bill_items (
    id integer NOT NULL,
    bill_id integer,
    item_type character varying(50) DEFAULT 'consultation'::character varying,
    item_name character varying(200) NOT NULL,
    item_price numeric(10,2) DEFAULT 0,
    quantity integer DEFAULT 1,
    actual_price numeric(10,2) DEFAULT 0,
    negotiated_price numeric(10,2) DEFAULT 0,
    tax_percent numeric(5,2) DEFAULT 0,
    tax_amount numeric(10,2) DEFAULT 0,
    total_amount numeric(10,2) DEFAULT 0,
    notes text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.bill_items OWNER TO ats_user;

--
-- Name: bill_items_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.bill_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bill_items_id_seq OWNER TO ats_user;

--
-- Name: bill_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.bill_items_id_seq OWNED BY public.bill_items.id;


--
-- Name: billing; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.billing (
    id integer NOT NULL,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    bill_type character varying(20) DEFAULT 'OPD'::character varying,
    consultation_fee numeric(10,2) DEFAULT 0,
    lab_charges numeric(10,2) DEFAULT 0,
    pharmacy_charges numeric(10,2) DEFAULT 0,
    imaging_charges numeric(10,2) DEFAULT 0,
    misc_charges numeric(10,2) DEFAULT 0,
    total_amount numeric(10,2) DEFAULT 0,
    discount numeric(10,2) DEFAULT 0,
    net_amount numeric(10,2) DEFAULT 0,
    status character varying(20) DEFAULT 'unpaid'::character varying,
    created_by character varying(80),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    bed_charges numeric(10,2) DEFAULT 0,
    surgery_charges numeric(10,2) DEFAULT 0,
    procedure_charges numeric(10,2) DEFAULT 0,
    tax_amount numeric(10,2) DEFAULT 0,
    admission_id integer,
    notes text DEFAULT ''::text
);


ALTER TABLE public.billing OWNER TO ats_user;

--
-- Name: billing_accounts; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.billing_accounts (
    id integer NOT NULL,
    client_id integer NOT NULL,
    plan_name character varying(50) DEFAULT 'Starter'::character varying,
    price numeric(10,2) DEFAULT 999,
    billing_cycle character varying(20) DEFAULT 'monthly'::character varying,
    next_payment_date date,
    trial_end_date date,
    payment_status character varying(20) DEFAULT 'trial'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_accounts OWNER TO ats_user;

--
-- Name: billing_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.billing_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.billing_accounts_id_seq OWNER TO ats_user;

--
-- Name: billing_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.billing_accounts_id_seq OWNED BY public.billing_accounts.id;


--
-- Name: billing_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.billing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.billing_id_seq OWNER TO ats_user;

--
-- Name: billing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.billing_id_seq OWNED BY public.billing.id;


--
-- Name: clients; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.clients (
    client_id integer NOT NULL,
    slug character varying(80) NOT NULL,
    hospital_name character varying(150) NOT NULL,
    hospital_phone character varying(30) DEFAULT ''::character varying,
    hospital_address text DEFAULT ''::text,
    city character varying(100) DEFAULT ''::character varying,
    state character varying(100) DEFAULT ''::character varying,
    country character varying(80) DEFAULT 'India'::character varying,
    tagline text DEFAULT ''::text,
    logo_path text DEFAULT ''::text,
    primary_color character varying(20) DEFAULT '#1a73e8'::character varying,
    secondary_color character varying(20) DEFAULT '#00b896'::character varying,
    database_name character varying(100) DEFAULT ''::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    subdomain character varying(80) DEFAULT ''::character varying,
    plan_type character varying(50) DEFAULT 'starter'::character varying,
    status character varying(20) DEFAULT 'active'::character varying,
    billing_start_date date,
    billing_expiry_date date,
    last_activity timestamp without time zone,
    db_status character varying(20) DEFAULT 'ready'::character varying,
    admin_email character varying(200) DEFAULT ''::character varying
);


ALTER TABLE public.clients OWNER TO ats_user;

--
-- Name: clients_client_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.clients_client_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clients_client_id_seq OWNER TO ats_user;

--
-- Name: clients_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.clients_client_id_seq OWNED BY public.clients.client_id;


--
-- Name: daily_rounds; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.daily_rounds (
    id integer NOT NULL,
    admission_id integer,
    patient_name character varying(150) NOT NULL,
    doctor_name character varying(150) DEFAULT ''::character varying,
    doctor_username character varying(80) DEFAULT ''::character varying,
    round_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    bp character varying(20) DEFAULT ''::character varying,
    pulse character varying(10) DEFAULT ''::character varying,
    temperature character varying(10) DEFAULT ''::character varying,
    spo2 character varying(10) DEFAULT ''::character varying,
    clinical_notes text DEFAULT ''::text,
    treatment_change text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.daily_rounds OWNER TO ats_user;

--
-- Name: daily_rounds_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.daily_rounds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.daily_rounds_id_seq OWNER TO ats_user;

--
-- Name: daily_rounds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.daily_rounds_id_seq OWNED BY public.daily_rounds.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text DEFAULT ''::text,
    head_doctor character varying(150) DEFAULT ''::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.departments OWNER TO ats_user;

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.departments_id_seq OWNER TO ats_user;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: discharge_summaries; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.discharge_summaries (
    id integer NOT NULL,
    admission_id integer,
    patient_name character varying(150) NOT NULL,
    discharge_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    final_diagnosis text DEFAULT ''::text,
    treatment_given text DEFAULT ''::text,
    discharge_medicines text DEFAULT ''::text,
    follow_up_date date,
    follow_up_notes text DEFAULT ''::text,
    diet_advice text DEFAULT ''::text,
    activity_advice text DEFAULT ''::text,
    doctor_name character varying(150) DEFAULT ''::character varying,
    doctor_username character varying(80) DEFAULT ''::character varying,
    bill_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.discharge_summaries OWNER TO ats_user;

--
-- Name: discharge_summaries_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.discharge_summaries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.discharge_summaries_id_seq OWNER TO ats_user;

--
-- Name: discharge_summaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.discharge_summaries_id_seq OWNED BY public.discharge_summaries.id;


--
-- Name: doctor_attendance; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.doctor_attendance (
    id integer NOT NULL,
    doctor_name character varying(150) NOT NULL,
    action character varying(20) NOT NULL,
    shift character varying(20) DEFAULT 'Morning'::character varying,
    notes text DEFAULT ''::text,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.doctor_attendance OWNER TO ats_user;

--
-- Name: doctor_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.doctor_attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctor_attendance_id_seq OWNER TO ats_user;

--
-- Name: doctor_attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.doctor_attendance_id_seq OWNED BY public.doctor_attendance.id;


--
-- Name: doctor_notes; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.doctor_notes (
    note_id integer NOT NULL,
    patient_id integer,
    visit_id integer,
    doctor_username character varying(80) NOT NULL,
    doctor_name character varying(150) DEFAULT ''::character varying,
    note_type character varying(50) DEFAULT 'clinical'::character varying,
    note_text text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.doctor_notes OWNER TO ats_user;

--
-- Name: doctor_notes_note_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.doctor_notes_note_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctor_notes_note_id_seq OWNER TO ats_user;

--
-- Name: doctor_notes_note_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.doctor_notes_note_id_seq OWNED BY public.doctor_notes.note_id;


--
-- Name: doctor_rounds; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.doctor_rounds (
    id integer NOT NULL,
    doctor_name character varying(150) NOT NULL,
    ward character varying(80) DEFAULT ''::character varying,
    round_time character varying(20) DEFAULT ''::character varying,
    status character varying(20) DEFAULT 'pending'::character varying,
    notes text DEFAULT ''::text,
    scheduled_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone
);


ALTER TABLE public.doctor_rounds OWNER TO ats_user;

--
-- Name: doctor_rounds_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.doctor_rounds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctor_rounds_id_seq OWNER TO ats_user;

--
-- Name: doctor_rounds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.doctor_rounds_id_seq OWNED BY public.doctor_rounds.id;


--
-- Name: doctors; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.doctors (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    department character varying(100) DEFAULT ''::character varying,
    specialization character varying(200) DEFAULT ''::character varying,
    phone character varying(20) DEFAULT ''::character varying,
    status character varying(20) DEFAULT 'available'::character varying,
    on_duty boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    qualifications text DEFAULT ''::text,
    registration_no character varying(50) DEFAULT ''::character varying
);


ALTER TABLE public.doctors OWNER TO ats_user;

--
-- Name: doctors_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.doctors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctors_id_seq OWNER TO ats_user;

--
-- Name: doctors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.doctors_id_seq OWNED BY public.doctors.id;


--
-- Name: hospital_expenses; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.hospital_expenses (
    expense_id integer NOT NULL,
    expense_date date DEFAULT CURRENT_DATE NOT NULL,
    category character varying(80) NOT NULL,
    sub_category character varying(120) DEFAULT ''::character varying,
    description character varying(300) DEFAULT ''::character varying,
    amount numeric(12,2) DEFAULT 0 NOT NULL,
    payment_mode character varying(40) DEFAULT 'Cash'::character varying,
    vendor character varying(150) DEFAULT ''::character varying,
    invoice_ref character varying(80) DEFAULT ''::character varying,
    recurring boolean DEFAULT false,
    created_by character varying(60) DEFAULT 'admin'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.hospital_expenses OWNER TO ats_user;

--
-- Name: hospital_expenses_expense_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.hospital_expenses_expense_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hospital_expenses_expense_id_seq OWNER TO ats_user;

--
-- Name: hospital_expenses_expense_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.hospital_expenses_expense_id_seq OWNED BY public.hospital_expenses.expense_id;


--
-- Name: imaging_orders; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.imaging_orders (
    id integer NOT NULL,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    doctor_username character varying(80),
    modality character varying(50) DEFAULT 'X-Ray'::character varying,
    body_part character varying(100) DEFAULT ''::character varying,
    clinical_notes text DEFAULT ''::text,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone
);


ALTER TABLE public.imaging_orders OWNER TO ats_user;

--
-- Name: imaging_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.imaging_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.imaging_orders_id_seq OWNER TO ats_user;

--
-- Name: imaging_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.imaging_orders_id_seq OWNED BY public.imaging_orders.id;


--
-- Name: imaging_reports; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.imaging_reports (
    id integer NOT NULL,
    order_id integer,
    patient_name character varying(150),
    modality character varying(50) DEFAULT 'X-Ray'::character varying,
    findings text DEFAULT ''::text,
    impression text DEFAULT ''::text,
    report_file_path text DEFAULT ''::text,
    radiologist character varying(150) DEFAULT ''::character varying,
    reported_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.imaging_reports OWNER TO ats_user;

--
-- Name: imaging_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.imaging_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.imaging_reports_id_seq OWNER TO ats_user;

--
-- Name: imaging_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.imaging_reports_id_seq OWNED BY public.imaging_reports.id;


--
-- Name: imaging_tests; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.imaging_tests (
    id integer NOT NULL,
    test_code character varying(20) NOT NULL,
    test_name character varying(200) NOT NULL,
    modality character varying(50) DEFAULT 'X-Ray'::character varying,
    body_part character varying(100) DEFAULT ''::character varying,
    price numeric(10,2) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.imaging_tests OWNER TO ats_user;

--
-- Name: imaging_tests_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.imaging_tests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.imaging_tests_id_seq OWNER TO ats_user;

--
-- Name: imaging_tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.imaging_tests_id_seq OWNED BY public.imaging_tests.id;


--
-- Name: inventory_stock; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.inventory_stock (
    id integer NOT NULL,
    medicine_id integer,
    batch_no character varying(50) DEFAULT ''::character varying,
    expiry_date date,
    quantity integer DEFAULT 0,
    min_quantity integer DEFAULT 10,
    purchase_price numeric(10,2) DEFAULT 0,
    sell_price numeric(10,2) DEFAULT 0,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    supplier character varying(150) DEFAULT ''::character varying,
    batch_number character varying(50) DEFAULT ''::character varying
);


ALTER TABLE public.inventory_stock OWNER TO ats_user;

--
-- Name: inventory_stock_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.inventory_stock_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_stock_id_seq OWNER TO ats_user;

--
-- Name: inventory_stock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.inventory_stock_id_seq OWNED BY public.inventory_stock.id;


--
-- Name: lab_orders; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.lab_orders (
    id integer NOT NULL,
    patient_name character varying(150),
    patient_phone character varying(20),
    doctor_username character varying(80),
    test_type character varying(30) DEFAULT 'LAB'::character varying,
    test_name character varying(200),
    status character varying(20) DEFAULT 'PENDING'::character varying,
    result_text text DEFAULT ''::text,
    result_file text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone,
    prescription_id integer,
    patient_id integer,
    visit_id integer,
    urgency character varying(20) DEFAULT 'routine'::character varying,
    lab_notes text DEFAULT ''::text
);


ALTER TABLE public.lab_orders OWNER TO ats_user;

--
-- Name: lab_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.lab_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lab_orders_id_seq OWNER TO ats_user;

--
-- Name: lab_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.lab_orders_id_seq OWNED BY public.lab_orders.id;


--
-- Name: lab_reports; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.lab_reports (
    id integer NOT NULL,
    order_id integer,
    patient_name character varying(150),
    patient_phone character varying(20) DEFAULT ''::character varying,
    test_name character varying(200),
    result_text text DEFAULT ''::text,
    result_file_path text DEFAULT ''::text,
    remarks text DEFAULT ''::text,
    lab_username character varying(80),
    reported_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.lab_reports OWNER TO ats_user;

--
-- Name: lab_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.lab_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lab_reports_id_seq OWNER TO ats_user;

--
-- Name: lab_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.lab_reports_id_seq OWNED BY public.lab_reports.id;


--
-- Name: lab_results; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.lab_results (
    result_id integer NOT NULL,
    order_id integer,
    patient_id integer,
    patient_name character varying(150) DEFAULT ''::character varying,
    test_name character varying(200) DEFAULT ''::character varying,
    result_value text DEFAULT ''::text,
    reference_range character varying(100) DEFAULT ''::character varying,
    unit character varying(30) DEFAULT ''::character varying,
    is_abnormal boolean DEFAULT false,
    remarks text DEFAULT ''::text,
    lab_username character varying(80) DEFAULT ''::character varying,
    reported_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.lab_results OWNER TO ats_user;

--
-- Name: lab_results_result_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.lab_results_result_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lab_results_result_id_seq OWNER TO ats_user;

--
-- Name: lab_results_result_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.lab_results_result_id_seq OWNED BY public.lab_results.result_id;


--
-- Name: lab_tests; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.lab_tests (
    id integer NOT NULL,
    test_code character varying(20) NOT NULL,
    test_name character varying(200) NOT NULL,
    category character varying(80) DEFAULT 'Pathology'::character varying,
    normal_range character varying(100) DEFAULT ''::character varying,
    unit character varying(30) DEFAULT ''::character varying,
    price numeric(10,2) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.lab_tests OWNER TO ats_user;

--
-- Name: lab_tests_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.lab_tests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lab_tests_id_seq OWNER TO ats_user;

--
-- Name: lab_tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.lab_tests_id_seq OWNED BY public.lab_tests.id;


--
-- Name: medicines; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.medicines (
    id integer NOT NULL,
    medicine_name character varying(200) NOT NULL,
    generic_name character varying(200) DEFAULT ''::character varying,
    category character varying(80) DEFAULT 'Tablet'::character varying,
    manufacturer character varying(150) DEFAULT ''::character varying,
    unit character varying(30) DEFAULT 'Strip'::character varying,
    unit_price numeric(10,2) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.medicines OWNER TO ats_user;

--
-- Name: medicines_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.medicines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.medicines_id_seq OWNER TO ats_user;

--
-- Name: medicines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.medicines_id_seq OWNED BY public.medicines.id;


--
-- Name: notification_logs; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.notification_logs (
    id integer NOT NULL,
    tenant_slug character varying(80) DEFAULT ''::character varying,
    channel character varying(30) DEFAULT ''::character varying,
    event_type character varying(80) DEFAULT ''::character varying,
    recipient character varying(150) DEFAULT ''::character varying,
    message_preview text DEFAULT ''::text,
    status character varying(20) DEFAULT 'sent'::character varying,
    provider_response text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_logs OWNER TO ats_user;

--
-- Name: notification_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.notification_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_logs_id_seq OWNER TO ats_user;

--
-- Name: notification_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.notification_logs_id_seq OWNED BY public.notification_logs.id;


--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.notification_settings (
    id integer NOT NULL,
    tenant_slug character varying(80) DEFAULT ''::character varying,
    setting_key character varying(100) NOT NULL,
    setting_value text DEFAULT ''::text,
    is_encrypted boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by character varying(80) DEFAULT ''::character varying
);


ALTER TABLE public.notification_settings OWNER TO ats_user;

--
-- Name: notification_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.notification_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_settings_id_seq OWNER TO ats_user;

--
-- Name: notification_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.notification_settings_id_seq OWNED BY public.notification_settings.id;


--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.notification_templates (
    id integer NOT NULL,
    tenant_slug character varying(80) DEFAULT ''::character varying,
    template_key character varying(80) NOT NULL,
    subject character varying(200) DEFAULT ''::character varying,
    body text NOT NULL,
    variables text DEFAULT ''::text,
    is_active boolean DEFAULT true,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_templates OWNER TO ats_user;

--
-- Name: notification_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.notification_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_templates_id_seq OWNER TO ats_user;

--
-- Name: notification_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.notification_templates_id_seq OWNED BY public.notification_templates.id;


--
-- Name: nurse_assignments; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.nurse_assignments (
    id integer NOT NULL,
    nurse_username character varying(80) NOT NULL,
    patient_name character varying(150),
    patient_phone character varying(20) DEFAULT ''::character varying,
    ward character varying(80) DEFAULT ''::character varying,
    bed_number character varying(20) DEFAULT ''::character varying,
    shift character varying(20) DEFAULT 'Morning'::character varying,
    assigned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    discharged_at timestamp without time zone
);


ALTER TABLE public.nurse_assignments OWNER TO ats_user;

--
-- Name: nurse_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.nurse_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nurse_assignments_id_seq OWNER TO ats_user;

--
-- Name: nurse_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.nurse_assignments_id_seq OWNED BY public.nurse_assignments.id;


--
-- Name: op_tickets; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.op_tickets (
    ticket_id integer NOT NULL,
    ticket_no character varying(30) NOT NULL,
    patient_id integer,
    visit_id integer,
    doctor_name character varying(150) DEFAULT ''::character varying,
    department character varying(100) DEFAULT ''::character varying,
    issued_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20) DEFAULT 'waiting'::character varying
);


ALTER TABLE public.op_tickets OWNER TO ats_user;

--
-- Name: op_tickets_ticket_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.op_tickets_ticket_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.op_tickets_ticket_id_seq OWNER TO ats_user;

--
-- Name: op_tickets_ticket_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.op_tickets_ticket_id_seq OWNED BY public.op_tickets.ticket_id;


--
-- Name: patient_admissions; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.patient_admissions (
    id integer NOT NULL,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    patient_aadhar character varying(20) DEFAULT ''::character varying,
    age character varying(10) DEFAULT ''::character varying,
    gender character varying(10) DEFAULT 'Unknown'::character varying,
    blood_group character varying(5) DEFAULT ''::character varying,
    address text DEFAULT ''::text,
    admission_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    discharge_date timestamp without time zone,
    ward_name character varying(100) DEFAULT ''::character varying,
    bed_number character varying(20) DEFAULT ''::character varying,
    admitting_doctor character varying(150) DEFAULT ''::character varying,
    department character varying(100) DEFAULT ''::character varying,
    diagnosis text DEFAULT ''::text,
    admission_notes text DEFAULT ''::text,
    status character varying(20) DEFAULT 'admitted'::character varying,
    created_by character varying(80) DEFAULT 'reception'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.patient_admissions OWNER TO ats_user;

--
-- Name: patient_admissions_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.patient_admissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patient_admissions_id_seq OWNER TO ats_user;

--
-- Name: patient_admissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.patient_admissions_id_seq OWNED BY public.patient_admissions.id;


--
-- Name: patient_visits; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.patient_visits (
    visit_id integer NOT NULL,
    patient_id integer,
    visit_type character varying(10) DEFAULT 'OP'::character varying,
    doctor_assigned character varying(150) DEFAULT ''::character varying,
    doctor_username character varying(80) DEFAULT ''::character varying,
    department character varying(100) DEFAULT ''::character varying,
    visit_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    chief_complaint text DEFAULT ''::text,
    diagnosis text DEFAULT ''::text,
    notes text DEFAULT ''::text,
    status character varying(30) DEFAULT 'active'::character varying,
    op_ticket_no character varying(30) DEFAULT ''::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.patient_visits OWNER TO ats_user;

--
-- Name: patients; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.patients (
    id integer NOT NULL,
    full_name character varying(150) NOT NULL,
    dob date,
    gender character varying(10) DEFAULT 'Unknown'::character varying,
    phone character varying(20),
    aadhar character varying(20),
    address text DEFAULT ''::text,
    blood_group character varying(5) DEFAULT ''::character varying,
    allergies text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    uhid character varying(20) DEFAULT NULL::character varying
);


ALTER TABLE public.patients OWNER TO ats_user;

--
-- Name: prescriptions; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.prescriptions (
    id integer NOT NULL,
    patient_name character varying(150),
    patient_phone character varying(20),
    doctor_username character varying(80),
    doctor_name character varying(150),
    diagnosis text,
    medicines text,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    chief_complaint text DEFAULT ''::text,
    symptoms text DEFAULT ''::text,
    advice text DEFAULT ''::text,
    diet_advice text DEFAULT ''::text,
    follow_up_days integer DEFAULT 0,
    visit_id integer,
    patient_id integer,
    uhid character varying(20) DEFAULT ''::character varying,
    clinical_notes text DEFAULT ''::text,
    bp character varying(20) DEFAULT ''::character varying,
    temperature character varying(10) DEFAULT ''::character varying,
    pulse character varying(10) DEFAULT ''::character varying,
    spo2 character varying(10) DEFAULT ''::character varying,
    weight character varying(10) DEFAULT ''::character varying,
    special_instructions text DEFAULT ''::text,
    follow_up_date date,
    generated_pdf_path text,
    created_by_doctor character varying(150) DEFAULT ''::character varying
);


ALTER TABLE public.prescriptions OWNER TO ats_user;

--
-- Name: patient_timeline; Type: VIEW; Schema: public; Owner: ats_user
--

CREATE VIEW public.patient_timeline AS
 SELECT p.id AS patient_id,
    p.full_name AS patient_name,
    p.uhid,
    'visit'::text AS event_type,
    v.visit_id AS event_id,
    v.visit_date AS event_date,
    v.chief_complaint AS summary,
    v.doctor_assigned AS actor,
    v.status
   FROM (public.patients p
     JOIN public.patient_visits v ON ((v.patient_id = p.id)))
UNION ALL
 SELECT p.id AS patient_id,
    p.full_name AS patient_name,
    p.uhid,
    'prescription'::text AS event_type,
    rx.id AS event_id,
    rx.created_at AS event_date,
    rx.diagnosis AS summary,
    rx.doctor_name AS actor,
    'saved'::character varying AS status
   FROM (public.patients p
     JOIN public.prescriptions rx ON ((rx.patient_id = p.id)))
UNION ALL
 SELECT p.id AS patient_id,
    p.full_name AS patient_name,
    p.uhid,
    'lab_order'::text AS event_type,
    lo.id AS event_id,
    lo.created_at AS event_date,
    lo.test_name AS summary,
    lo.doctor_username AS actor,
    lo.status
   FROM (public.patients p
     JOIN public.lab_orders lo ON ((lo.patient_id = p.id)));


ALTER VIEW public.patient_timeline OWNER TO ats_user;

--
-- Name: patient_visits_visit_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.patient_visits_visit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patient_visits_visit_id_seq OWNER TO ats_user;

--
-- Name: patient_visits_visit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.patient_visits_visit_id_seq OWNED BY public.patient_visits.visit_id;


--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.patients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patients_id_seq OWNER TO ats_user;

--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.patients_id_seq OWNED BY public.patients.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    bill_id integer,
    amount_paid numeric(10,2) DEFAULT 0,
    payment_mode character varying(30) DEFAULT 'Cash'::character varying,
    reference_no character varying(100) DEFAULT ''::character varying,
    received_by character varying(80),
    paid_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.payments OWNER TO ats_user;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO ats_user;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: pharmacy_sale_items; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.pharmacy_sale_items (
    id integer NOT NULL,
    sale_id integer,
    medicine_id integer,
    medicine_name character varying(200),
    quantity integer DEFAULT 1,
    unit_price numeric(10,2) DEFAULT 0,
    total_price numeric(10,2) DEFAULT 0
);


ALTER TABLE public.pharmacy_sale_items OWNER TO ats_user;

--
-- Name: pharmacy_sale_items_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.pharmacy_sale_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pharmacy_sale_items_id_seq OWNER TO ats_user;

--
-- Name: pharmacy_sale_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.pharmacy_sale_items_id_seq OWNED BY public.pharmacy_sale_items.id;


--
-- Name: pharmacy_sales; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.pharmacy_sales (
    id integer NOT NULL,
    patient_name character varying(150) DEFAULT 'Walk-in'::character varying,
    patient_phone character varying(20) DEFAULT ''::character varying,
    prescription_id integer,
    total_amount numeric(10,2) DEFAULT 0,
    discount numeric(10,2) DEFAULT 0,
    net_amount numeric(10,2) DEFAULT 0,
    payment_mode character varying(30) DEFAULT 'Cash'::character varying,
    staff_username character varying(80),
    sold_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.pharmacy_sales OWNER TO ats_user;

--
-- Name: pharmacy_sales_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.pharmacy_sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pharmacy_sales_id_seq OWNER TO ats_user;

--
-- Name: pharmacy_sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.pharmacy_sales_id_seq OWNED BY public.pharmacy_sales.id;


--
-- Name: pharmacy_stock; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.pharmacy_stock (
    stock_id integer NOT NULL,
    medicine_id integer,
    medicine_name character varying(200) DEFAULT ''::character varying,
    batch_no character varying(50) DEFAULT ''::character varying,
    expiry_date date,
    quantity integer DEFAULT 0,
    min_quantity integer DEFAULT 10,
    unit_price numeric(10,2) DEFAULT 0,
    sell_price numeric(10,2) DEFAULT 0,
    supplier character varying(150) DEFAULT ''::character varying,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.pharmacy_stock OWNER TO ats_user;

--
-- Name: pharmacy_stock_stock_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.pharmacy_stock_stock_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pharmacy_stock_stock_id_seq OWNER TO ats_user;

--
-- Name: pharmacy_stock_stock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.pharmacy_stock_stock_id_seq OWNED BY public.pharmacy_stock.stock_id;


--
-- Name: prescription_items; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.prescription_items (
    item_id integer NOT NULL,
    prescription_id integer,
    medicine_name character varying(200) NOT NULL,
    dosage character varying(100) DEFAULT ''::character varying,
    frequency character varying(100) DEFAULT ''::character varying,
    duration character varying(50) DEFAULT ''::character varying,
    instructions text DEFAULT ''::text,
    quantity integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    route character varying(30) DEFAULT 'Oral'::character varying,
    med_notes text DEFAULT ''::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.prescription_items OWNER TO ats_user;

--
-- Name: prescription_items_item_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.prescription_items_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prescription_items_item_id_seq OWNER TO ats_user;

--
-- Name: prescription_items_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.prescription_items_item_id_seq OWNED BY public.prescription_items.item_id;


--
-- Name: prescription_medicines; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.prescription_medicines (
    id integer NOT NULL,
    prescription_id integer,
    medicine_name character varying(200) DEFAULT ''::character varying NOT NULL,
    dose character varying(100) DEFAULT ''::character varying,
    frequency character varying(100) DEFAULT ''::character varying,
    duration character varying(50) DEFAULT ''::character varying,
    route character varying(50) DEFAULT 'Oral'::character varying,
    notes text DEFAULT ''::text,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.prescription_medicines OWNER TO ats_user;

--
-- Name: prescription_medicines_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.prescription_medicines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prescription_medicines_id_seq OWNER TO ats_user;

--
-- Name: prescription_medicines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.prescription_medicines_id_seq OWNED BY public.prescription_medicines.id;


--
-- Name: prescriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.prescriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prescriptions_id_seq OWNER TO ats_user;

--
-- Name: prescriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.prescriptions_id_seq OWNED BY public.prescriptions.id;


--
-- Name: procedure_charges; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.procedure_charges (
    id integer NOT NULL,
    procedure_name character varying(200) NOT NULL,
    category character varying(80) DEFAULT 'General'::character varying,
    default_price numeric(10,2) DEFAULT 0,
    gst_percent numeric(5,2) DEFAULT 0,
    description text DEFAULT ''::text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.procedure_charges OWNER TO ats_user;

--
-- Name: procedure_charges_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.procedure_charges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procedure_charges_id_seq OWNER TO ats_user;

--
-- Name: procedure_charges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.procedure_charges_id_seq OWNED BY public.procedure_charges.id;


--
-- Name: registrations; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.registrations (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    age character varying(10) DEFAULT ''::character varying,
    phone character varying(20) DEFAULT ''::character varying,
    aadhar character varying(20) DEFAULT ''::character varying,
    issue text DEFAULT ''::text,
    doctor character varying(150) DEFAULT ''::character varying,
    appointment_time character varying(100) DEFAULT ''::character varying,
    status character varying(30) DEFAULT 'pending'::character varying,
    source character varying(30) DEFAULT 'chatbot'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.registrations OWNER TO ats_user;

--
-- Name: registrations_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.registrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.registrations_id_seq OWNER TO ats_user;

--
-- Name: registrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.registrations_id_seq OWNED BY public.registrations.id;


--
-- Name: services_catalogue; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.services_catalogue (
    service_id integer NOT NULL,
    service_name character varying(200) NOT NULL,
    department character varying(100) DEFAULT ''::character varying,
    default_price numeric(10,2) DEFAULT 0,
    tax_percentage numeric(5,2) DEFAULT 0,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.services_catalogue OWNER TO ats_user;

--
-- Name: services_catalogue_service_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.services_catalogue_service_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.services_catalogue_service_id_seq OWNER TO ats_user;

--
-- Name: services_catalogue_service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.services_catalogue_service_id_seq OWNED BY public.services_catalogue.service_id;


--
-- Name: staff_users; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.staff_users (
    id integer NOT NULL,
    username character varying(80) NOT NULL,
    password_hash text NOT NULL,
    role character varying(20) DEFAULT 'RECEPTION'::character varying NOT NULL,
    department character varying(100) DEFAULT ''::character varying,
    full_name character varying(150) DEFAULT ''::character varying,
    is_active boolean DEFAULT true,
    must_change_password boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.staff_users OWNER TO ats_user;

--
-- Name: staff_users_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.staff_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.staff_users_id_seq OWNER TO ats_user;

--
-- Name: staff_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.staff_users_id_seq OWNED BY public.staff_users.id;


--
-- Name: stock; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.stock (
    id integer NOT NULL,
    item_name character varying(200) NOT NULL,
    category character varying(80) DEFAULT 'Medicine'::character varying,
    quantity integer DEFAULT 0,
    unit character varying(30) DEFAULT 'units'::character varying,
    min_quantity integer DEFAULT 10,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.stock OWNER TO ats_user;

--
-- Name: stock_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.stock_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_id_seq OWNER TO ats_user;

--
-- Name: stock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.stock_id_seq OWNED BY public.stock.id;


--
-- Name: surgery_records; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.surgery_records (
    id integer NOT NULL,
    admission_id integer,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    surgeon_name character varying(150) DEFAULT ''::character varying,
    surgeon_username character varying(80) DEFAULT ''::character varying,
    surgery_type character varying(200) NOT NULL,
    anesthesia_type character varying(100) DEFAULT 'General'::character varying,
    estimated_cost numeric(10,2) DEFAULT 0,
    negotiated_cost numeric(10,2) DEFAULT 0,
    operation_date timestamp without time zone,
    duration_minutes integer DEFAULT 0,
    operation_notes text DEFAULT ''::text,
    complications text DEFAULT ''::text,
    status character varying(30) DEFAULT 'scheduled'::character varying,
    created_by character varying(80) DEFAULT ''::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.surgery_records OWNER TO ats_user;

--
-- Name: surgery_records_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.surgery_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.surgery_records_id_seq OWNER TO ats_user;

--
-- Name: surgery_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.surgery_records_id_seq OWNED BY public.surgery_records.id;


--
-- Name: system_logs; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.system_logs (
    id integer NOT NULL,
    username character varying(80) DEFAULT 'system'::character varying,
    role character varying(20) DEFAULT ''::character varying,
    action character varying(200) NOT NULL,
    details text DEFAULT ''::text,
    ip_address character varying(45) DEFAULT ''::character varying,
    logged_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_logs OWNER TO ats_user;

--
-- Name: system_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.system_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_logs_id_seq OWNER TO ats_user;

--
-- Name: system_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.system_logs_id_seq OWNED BY public.system_logs.id;


--
-- Name: visit_records; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.visit_records (
    id integer NOT NULL,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    doctor_username character varying(80),
    doctor_name character varying(150) DEFAULT ''::character varying,
    department character varying(100) DEFAULT ''::character varying,
    chief_complaint text DEFAULT ''::text,
    examination text DEFAULT ''::text,
    diagnosis text DEFAULT ''::text,
    treatment_plan text DEFAULT ''::text,
    follow_up_date date,
    visit_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.visit_records OWNER TO ats_user;

--
-- Name: visit_records_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.visit_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.visit_records_id_seq OWNER TO ats_user;

--
-- Name: visit_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.visit_records_id_seq OWNED BY public.visit_records.id;


--
-- Name: vitals; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.vitals (
    id integer NOT NULL,
    patient_name character varying(150),
    patient_phone character varying(20),
    nurse_username character varying(80),
    bp character varying(20) DEFAULT ''::character varying,
    pulse character varying(10) DEFAULT ''::character varying,
    temperature character varying(10) DEFAULT ''::character varying,
    spo2 character varying(10) DEFAULT ''::character varying,
    weight character varying(10) DEFAULT ''::character varying,
    notes text DEFAULT ''::text,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.vitals OWNER TO ats_user;

--
-- Name: vitals_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.vitals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vitals_id_seq OWNER TO ats_user;

--
-- Name: vitals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.vitals_id_seq OWNED BY public.vitals.id;


--
-- Name: wards; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.wards (
    id integer NOT NULL,
    ward_name character varying(100) NOT NULL,
    ward_type character varying(50) DEFAULT 'General'::character varying,
    total_beds integer DEFAULT 0,
    floor character varying(20) DEFAULT 'Ground'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.wards OWNER TO ats_user;

--
-- Name: wards_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.wards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wards_id_seq OWNER TO ats_user;

--
-- Name: wards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.wards_id_seq OWNED BY public.wards.id;


--
-- Name: appointments id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.appointments ALTER COLUMN id SET DEFAULT nextval('public.appointments_id_seq'::regclass);


--
-- Name: attendance id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.attendance ALTER COLUMN id SET DEFAULT nextval('public.attendance_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: bed_assignments id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bed_assignments ALTER COLUMN id SET DEFAULT nextval('public.bed_assignments_id_seq'::regclass);


--
-- Name: beds id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.beds ALTER COLUMN id SET DEFAULT nextval('public.beds_id_seq'::regclass);


--
-- Name: bill_items id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bill_items ALTER COLUMN id SET DEFAULT nextval('public.bill_items_id_seq'::regclass);


--
-- Name: billing id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.billing ALTER COLUMN id SET DEFAULT nextval('public.billing_id_seq'::regclass);


--
-- Name: billing_accounts id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.billing_accounts ALTER COLUMN id SET DEFAULT nextval('public.billing_accounts_id_seq'::regclass);


--
-- Name: clients client_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.clients ALTER COLUMN client_id SET DEFAULT nextval('public.clients_client_id_seq'::regclass);


--
-- Name: daily_rounds id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.daily_rounds ALTER COLUMN id SET DEFAULT nextval('public.daily_rounds_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: discharge_summaries id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.discharge_summaries ALTER COLUMN id SET DEFAULT nextval('public.discharge_summaries_id_seq'::regclass);


--
-- Name: doctor_attendance id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_attendance ALTER COLUMN id SET DEFAULT nextval('public.doctor_attendance_id_seq'::regclass);


--
-- Name: doctor_notes note_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_notes ALTER COLUMN note_id SET DEFAULT nextval('public.doctor_notes_note_id_seq'::regclass);


--
-- Name: doctor_rounds id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_rounds ALTER COLUMN id SET DEFAULT nextval('public.doctor_rounds_id_seq'::regclass);


--
-- Name: doctors id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctors ALTER COLUMN id SET DEFAULT nextval('public.doctors_id_seq'::regclass);


--
-- Name: hospital_expenses expense_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.hospital_expenses ALTER COLUMN expense_id SET DEFAULT nextval('public.hospital_expenses_expense_id_seq'::regclass);


--
-- Name: imaging_orders id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_orders ALTER COLUMN id SET DEFAULT nextval('public.imaging_orders_id_seq'::regclass);


--
-- Name: imaging_reports id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_reports ALTER COLUMN id SET DEFAULT nextval('public.imaging_reports_id_seq'::regclass);


--
-- Name: imaging_tests id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_tests ALTER COLUMN id SET DEFAULT nextval('public.imaging_tests_id_seq'::regclass);


--
-- Name: inventory_stock id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.inventory_stock ALTER COLUMN id SET DEFAULT nextval('public.inventory_stock_id_seq'::regclass);


--
-- Name: lab_orders id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_orders ALTER COLUMN id SET DEFAULT nextval('public.lab_orders_id_seq'::regclass);


--
-- Name: lab_reports id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_reports ALTER COLUMN id SET DEFAULT nextval('public.lab_reports_id_seq'::regclass);


--
-- Name: lab_results result_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_results ALTER COLUMN result_id SET DEFAULT nextval('public.lab_results_result_id_seq'::regclass);


--
-- Name: lab_tests id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_tests ALTER COLUMN id SET DEFAULT nextval('public.lab_tests_id_seq'::regclass);


--
-- Name: medicines id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.medicines ALTER COLUMN id SET DEFAULT nextval('public.medicines_id_seq'::regclass);


--
-- Name: notification_logs id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_logs ALTER COLUMN id SET DEFAULT nextval('public.notification_logs_id_seq'::regclass);


--
-- Name: notification_settings id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_settings ALTER COLUMN id SET DEFAULT nextval('public.notification_settings_id_seq'::regclass);


--
-- Name: notification_templates id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_templates ALTER COLUMN id SET DEFAULT nextval('public.notification_templates_id_seq'::regclass);


--
-- Name: nurse_assignments id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.nurse_assignments ALTER COLUMN id SET DEFAULT nextval('public.nurse_assignments_id_seq'::regclass);


--
-- Name: op_tickets ticket_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.op_tickets ALTER COLUMN ticket_id SET DEFAULT nextval('public.op_tickets_ticket_id_seq'::regclass);


--
-- Name: patient_admissions id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patient_admissions ALTER COLUMN id SET DEFAULT nextval('public.patient_admissions_id_seq'::regclass);


--
-- Name: patient_visits visit_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patient_visits ALTER COLUMN visit_id SET DEFAULT nextval('public.patient_visits_visit_id_seq'::regclass);


--
-- Name: patients id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patients ALTER COLUMN id SET DEFAULT nextval('public.patients_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: pharmacy_sale_items id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sale_items ALTER COLUMN id SET DEFAULT nextval('public.pharmacy_sale_items_id_seq'::regclass);


--
-- Name: pharmacy_sales id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sales ALTER COLUMN id SET DEFAULT nextval('public.pharmacy_sales_id_seq'::regclass);


--
-- Name: pharmacy_stock stock_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_stock ALTER COLUMN stock_id SET DEFAULT nextval('public.pharmacy_stock_stock_id_seq'::regclass);


--
-- Name: prescription_items item_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_items ALTER COLUMN item_id SET DEFAULT nextval('public.prescription_items_item_id_seq'::regclass);


--
-- Name: prescription_medicines id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_medicines ALTER COLUMN id SET DEFAULT nextval('public.prescription_medicines_id_seq'::regclass);


--
-- Name: prescriptions id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescriptions ALTER COLUMN id SET DEFAULT nextval('public.prescriptions_id_seq'::regclass);


--
-- Name: procedure_charges id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.procedure_charges ALTER COLUMN id SET DEFAULT nextval('public.procedure_charges_id_seq'::regclass);


--
-- Name: registrations id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.registrations ALTER COLUMN id SET DEFAULT nextval('public.registrations_id_seq'::regclass);


--
-- Name: services_catalogue service_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.services_catalogue ALTER COLUMN service_id SET DEFAULT nextval('public.services_catalogue_service_id_seq'::regclass);


--
-- Name: staff_users id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.staff_users ALTER COLUMN id SET DEFAULT nextval('public.staff_users_id_seq'::regclass);


--
-- Name: stock id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.stock ALTER COLUMN id SET DEFAULT nextval('public.stock_id_seq'::regclass);


--
-- Name: surgery_records id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.surgery_records ALTER COLUMN id SET DEFAULT nextval('public.surgery_records_id_seq'::regclass);


--
-- Name: system_logs id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.system_logs ALTER COLUMN id SET DEFAULT nextval('public.system_logs_id_seq'::regclass);


--
-- Name: visit_records id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.visit_records ALTER COLUMN id SET DEFAULT nextval('public.visit_records_id_seq'::regclass);


--
-- Name: vitals id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.vitals ALTER COLUMN id SET DEFAULT nextval('public.vitals_id_seq'::regclass);


--
-- Name: wards id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.wards ALTER COLUMN id SET DEFAULT nextval('public.wards_id_seq'::regclass);


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.appointments (id, patient_name, patient_phone, patient_aadhar, age, issue, doctor_name, department, appointment_date, appointment_time, status, source, notes, created_at, updated_at, patient_id, reminder_sent, reminder_sent_at) FROM stdin;
1	Rajesh Kumar	9876543210			Chest pain	Dr. Srujan	Orthopedics	2026-03-11	09:00	pending	chatbot		2026-03-10 22:51:23.725907	2026-03-10 22:51:23.725907	\N	f	\N
2	Priya Sharma	9876543211			Fever & cough	Dr. K. Ramyanadh	General Medicine	2026-03-12	010:00	pending	chatbot		2026-03-10 22:51:23.725907	2026-03-10 22:51:23.725907	\N	f	\N
3	Suresh Reddy	9876543212			Knee pain	Dr. B. Ramachandra Nayak	General Surgery	2026-03-13	011:00	pending	chatbot		2026-03-10 22:51:23.725907	2026-03-10 22:51:23.725907	\N	f	\N
4	Suresh Kumar	+91 9901000001				Dr. General	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839	9	f	\N
5	Lakshmi Devi	+91 9901000002				Dr. General	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839	10	f	\N
6	Ravi Teja	+91 9901000003				Dr. General	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839	11	f	\N
7	Anita Rao	+91 9901000004				Dr. General	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839	12	f	\N
8	Meena Reddy	+91 9901000006				Dr. General	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839	13	f	\N
9	Suresh Kumar	+91 9901000001				Dr. Ramesh Kumar	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:09:14.00081	2026-03-11 00:09:14.00081	9	f	\N
10	Lakshmi Devi	+91 9901000002				Dr. Priya Sharma	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:09:14.00081	2026-03-11 00:09:14.00081	10	f	\N
11	Ravi Teja	+91 9901000003				Dr. Anil Reddy	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:09:14.00081	2026-03-11 00:09:14.00081	11	f	\N
12	Anita Rao	+91 9901000004				Dr. Sunita Patel	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:09:14.00081	2026-03-11 00:09:14.00081	12	f	\N
13	Meena Reddy	+91 9901000006				Dr. Venkat Rao	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:09:14.00081	2026-03-11 00:09:14.00081	13	f	\N
14	Suresh Kumar	+91 9901000001				Dr. Ramesh Kumar	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:10:54.135292	2026-03-11 00:10:54.135292	9	f	\N
15	Lakshmi Devi	+91 9901000002				Dr. Priya Sharma	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:10:54.135292	2026-03-11 00:10:54.135292	10	f	\N
16	Ravi Teja	+91 9901000003				Dr. Anil Reddy	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:10:54.135292	2026-03-11 00:10:54.135292	11	f	\N
17	Anita Rao	+91 9901000004				Dr. Sunita Patel	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:10:54.135292	2026-03-11 00:10:54.135292	12	f	\N
18	Meena Reddy	+91 9901000006				Dr. Venkat Rao	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:10:54.135292	2026-03-11 00:10:54.135292	13	f	\N
19	Suresh Kumar	+91 9901000001				Dr. Ramesh Kumar	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:12:31.614172	2026-03-11 00:12:31.614172	9	f	\N
20	Lakshmi Devi	+91 9901000002				Dr. Priya Sharma	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:12:31.614172	2026-03-11 00:12:31.614172	10	f	\N
21	Ravi Teja	+91 9901000003				Dr. Anil Reddy	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:12:31.614172	2026-03-11 00:12:31.614172	11	f	\N
22	Anita Rao	+91 9901000004				Dr. Sunita Patel	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:12:31.614172	2026-03-11 00:12:31.614172	12	f	\N
23	Meena Reddy	+91 9901000006				Dr. Venkat Rao	General Medicine	2026-03-11	10:00	scheduled	walk-in		2026-03-11 00:12:31.614172	2026-03-11 00:12:31.614172	13	f	\N
24	Lakshmi Bai	9479915632		41	Skin Rash	Dr. Priya Nair		2026-02-24	14:00	completed	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
25	Meena Kumari	9607774036		52	Chest Pain	Dr. Anitha Sharma		2026-03-06	12:00	completed	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
26	Mohan Das	9449556491		53	Diabetes Check	Dr. Suresh Reddy		2026-02-15	11:00	cancelled	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
27	Anita Rao	+91 9901000004		58	Fever	Dr. Anitha Sharma		2026-02-27	14:00	pending	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
28	Rajesh Kumar	9858489898		27	Back Pain	Dr. Ravi Kumar		2026-03-01	10:00	pending	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
29	Kavitha Nair	9908513002		47	Eye Check	Dr. Anitha Sharma		2026-02-28	11:00	cancelled	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
30	Priya Sharma	9908297152		24	Chest Pain	Dr. Anitha Sharma		2026-02-19	16:00	completed	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
31	Kavitha Nair	9908513002		48	Cough	Dr. Anitha Sharma		2026-03-05	14:00	cancelled	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
32	Ramesh Babu	9541839267		71	Diabetes Check	Dr. Anitha Sharma		2026-03-05	15:00	pending	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
33	Meena Reddy	+91 9901000006		40	Skin Rash	Dr. Anitha Sharma		2026-02-14	17:00	pending	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
34	Meena Reddy	+91 9901000006		40	Fever	Dr. Ravi Kumar		2026-03-12	17:00	cancelled	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
35	Suresh Reddy	9145032355		27	Joint Pain	Dr. Anitha Sharma		2026-02-13	10:00	completed	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
36	Venkatesh Rao	9903634942		51	Fever	Dr. Ravi Kumar		2026-03-03	10:00	completed	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
37	Priya Sharma	9876543211		65	Cough	Dr. Anitha Sharma		2026-02-27	13:00	pending	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
38	Lakshmi Devi	+91 9901000002		68	Cough	Dr. Ravi Kumar		2026-03-04	11:00	completed	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
39	Kavitha Nair	9908513002		69	Fever	Dr. Anitha Sharma		2026-02-18	16:00	pending	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
40	Priya Sharma	9908297152		44	Back Pain	Dr. Anitha Sharma		2026-02-27	10:00	pending	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
41	Meena Reddy	+91 9901000006		29	Chest Pain	Dr. Priya Nair		2026-02-27	16:00	pending	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
42	Suresh Kumar	+91 9901000001		50	Fever	Dr. Ravi Kumar		2026-02-12	16:00	completed	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
43	Rajesh Kumar	9858489898		51	Chest Pain	Dr. Anitha Sharma		2026-02-17	12:00	pending	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
44	Rajesh Kumar	9876543210		22	Hypertension	Dr. Ravi Kumar		2026-03-04	12:00	completed	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
45	Ravi Teja	+91 9901000003		38	Cough	Dr. Suresh Reddy		2026-02-26	17:00	completed	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
46	Suresh Reddy	9145032355		42	Skin Rash	Dr. Anitha Sharma		2026-03-01	12:00	completed	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
47	Suresh Reddy	9145032355		72	Headache	Dr. Anitha Sharma		2026-03-02	13:00	pending	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
48	Meena Reddy	+91 9901000006		22	Back Pain	Dr. Anitha Sharma		2026-02-17	17:00	cancelled	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
49	Rajesh Kumar	9876543210		22	Fever	Dr. Anitha Sharma		2026-02-23	17:00	completed	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
50	Anita Rao	+91 9901000004		47	Skin Rash	Dr. Ravi Kumar		2026-02-18	10:00	pending	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
51	Anita Rao	+91 9901000004		43	Headache	Dr. Suresh Reddy		2026-02-18	14:00	pending	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
52	Rajesh Kumar	9876543210		54	Hypertension	Dr. Priya Nair		2026-02-11	10:00	completed	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
53	Lakshmi Devi	+91 9901000002		44	Diabetes Check	Dr. Priya Nair		2026-02-23	14:00	completed	chatbot		2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N	f	\N
\.


--
-- Data for Name: attendance; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.attendance (id, staff_name, action, notes, recorded_at) FROM stdin;
1	Dr. K. Ramyanadh	checkin	Doctor check-in	2026-03-10 20:05:25.07255
2	star_hospital_admin	check-in	On duty	2026-03-11 00:04:09.403839
3	star_hospital_doctor	check-in	On duty	2026-03-11 00:04:09.403839
4	star_hospital_nurse	check-in	On duty	2026-03-11 00:04:09.403839
5	star_hospital_admin	check-in	On duty	2026-03-11 00:09:14.00081
6	star_hospital_doctor	check-in	On duty	2026-03-11 00:09:14.00081
7	star_hospital_nurse	check-in	On duty	2026-03-11 00:09:14.00081
8	star_hospital_lab	check-in	On duty	2026-03-11 00:09:14.00081
9	star_hospital_reception	check-in	On duty	2026-03-11 00:09:14.00081
10	star_hospital_admin	check-in	On duty	2026-03-11 00:10:54.135292
11	star_hospital_doctor	check-in	On duty	2026-03-11 00:10:54.135292
12	star_hospital_nurse	check-in	On duty	2026-03-11 00:10:54.135292
13	star_hospital_lab	check-in	On duty	2026-03-11 00:10:54.135292
14	star_hospital_reception	check-in	On duty	2026-03-11 00:10:54.135292
15	star_hospital_admin	check-in	On duty	2026-03-11 00:12:31.614172
16	star_hospital_doctor	check-in	On duty	2026-03-11 00:12:31.614172
17	star_hospital_nurse	check-in	On duty	2026-03-11 00:12:31.614172
18	star_hospital_lab	check-in	On duty	2026-03-11 00:12:31.614172
19	star_hospital_reception	check-in	On duty	2026-03-11 00:12:31.614172
20	Sita Devi	check-in	Role: Nurse	2026-03-12 08:18:00
21	Sita Devi	check-out	Role: Nurse	2026-03-12 17:37:00
22	Ramesh Babu	check-in	Role: Receptionist	2026-03-12 09:48:00
23	Ramesh Babu	check-out	Role: Receptionist	2026-03-12 17:26:00
24	Kavitha	check-in	Role: Lab Technician	2026-03-12 08:23:00
25	Kavitha	check-out	Role: Lab Technician	2026-03-12 18:36:00
26	Mohan Kumar	check-in	Role: Pharmacist	2026-03-12 09:42:00
27	Mohan Kumar	check-out	Role: Pharmacist	2026-03-12 18:51:00
28	Priya G	check-in	Role: Nurse	2026-03-12 09:19:00
29	Priya G	check-out	Role: Nurse	2026-03-12 18:51:00
30	Sita Devi	check-in	Role: Nurse	2026-03-11 08:50:00
31	Sita Devi	check-out	Role: Nurse	2026-03-11 17:13:00
32	Ramesh Babu	check-in	Role: Receptionist	2026-03-11 08:23:00
33	Ramesh Babu	check-out	Role: Receptionist	2026-03-11 18:35:00
34	Kavitha	check-in	Role: Lab Technician	2026-03-11 08:07:00
35	Kavitha	check-out	Role: Lab Technician	2026-03-11 17:55:00
36	Mohan Kumar	check-in	Role: Pharmacist	2026-03-11 08:55:00
37	Mohan Kumar	check-out	Role: Pharmacist	2026-03-11 18:37:00
38	Priya G	check-in	Role: Nurse	2026-03-11 08:30:00
39	Priya G	check-out	Role: Nurse	2026-03-11 18:55:00
40	Sita Devi	check-in	Role: Nurse	2026-03-10 08:11:00
41	Sita Devi	check-out	Role: Nurse	2026-03-10 17:00:00
42	Ramesh Babu	check-in	Role: Receptionist	2026-03-10 09:28:00
43	Ramesh Babu	check-out	Role: Receptionist	2026-03-10 18:33:00
44	Kavitha	check-in	Role: Lab Technician	2026-03-10 09:32:00
45	Kavitha	check-out	Role: Lab Technician	2026-03-10 17:57:00
46	Mohan Kumar	check-in	Role: Pharmacist	2026-03-10 08:15:00
47	Mohan Kumar	check-out	Role: Pharmacist	2026-03-10 17:44:00
48	Priya G	check-in	Role: Nurse	2026-03-10 09:53:00
49	Priya G	check-out	Role: Nurse	2026-03-10 17:42:00
50	Sita Devi	check-in	Role: Nurse	2026-03-09 09:06:00
51	Sita Devi	check-out	Role: Nurse	2026-03-09 18:37:00
52	Ramesh Babu	check-in	Role: Receptionist	2026-03-09 08:47:00
53	Ramesh Babu	check-out	Role: Receptionist	2026-03-09 18:43:00
54	Kavitha	check-in	Role: Lab Technician	2026-03-09 08:25:00
55	Kavitha	check-out	Role: Lab Technician	2026-03-09 17:28:00
56	Mohan Kumar	check-in	Role: Pharmacist	2026-03-09 08:24:00
57	Mohan Kumar	check-out	Role: Pharmacist	2026-03-09 18:23:00
58	Priya G	check-in	Role: Nurse	2026-03-09 09:10:00
59	Priya G	check-out	Role: Nurse	2026-03-09 17:07:00
60	Sita Devi	check-in	Role: Nurse	2026-03-08 09:33:00
61	Sita Devi	check-out	Role: Nurse	2026-03-08 17:22:00
62	Ramesh Babu	check-in	Role: Receptionist	2026-03-08 08:08:00
63	Ramesh Babu	check-out	Role: Receptionist	2026-03-08 18:25:00
64	Kavitha	check-in	Role: Lab Technician	2026-03-08 09:27:00
65	Kavitha	check-out	Role: Lab Technician	2026-03-08 17:34:00
66	Mohan Kumar	check-in	Role: Pharmacist	2026-03-08 08:34:00
67	Mohan Kumar	check-out	Role: Pharmacist	2026-03-08 18:19:00
68	Priya G	check-in	Role: Nurse	2026-03-08 08:52:00
69	Priya G	check-out	Role: Nurse	2026-03-08 18:23:00
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.audit_log (id, client_id, username, role, action, details, ip_address, created_at) FROM stdin;
1	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 07:07:10.68192
2	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 07:07:18.128783
3	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 07:07:57.181682
4	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 07:12:28.84251
5	\N	founder	FOUNDER	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 08:52:36.370044
6	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 08:52:37.394131
7	\N	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 08:52:38.091077
8	\N	founder	FOUNDER	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 08:52:38.712074
9	\N	founder	FOUNDER	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 08:52:47.958173
10	\N	founder	FOUNDER	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 08:52:59.574542
11	\N	founder	FOUNDER	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 08:54:19.733249
12	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 09:02:59.525483
13	\N	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 09:03:00.167918
14	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 09:03:06.72515
15	\N	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 09:03:07.257041
16	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 11:56:55.801827
17	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:10:52.881663
18	\N	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:11:04.429098
19	\N	star_hospital_nurse	NURSE	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:11:05.323645
20	\N	star_hospital_lab	LAB	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:11:06.04644
21	\N	star_hospital_stock	STOCK	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:11:06.943062
22	\N	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:11:07.743521
23	\N	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:12:49.60778
24	\N	star_hospital_nurse	NURSE	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:12:50.273485
25	\N	star_hospital_lab	LAB	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:12:50.926677
26	\N	star_hospital_stock	STOCK	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:12:51.66468
27	\N	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:12:52.286723
28	\N	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:13:02.647682
29	\N	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:13:08.588377
30	\N	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:13:14.547552
31	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:13:58.945968
32	\N	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:13:59.563404
33	\N	star_hospital_nurse	NURSE	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:14:00.12563
34	\N	star_hospital_lab	LAB	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:14:00.642727
35	\N	star_hospital_stock	STOCK	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:14:01.209021
36	\N	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:14:01.760004
37	\N	admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:51:39.469127
38	\N	admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:51:44.036029
39	\N	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:51:49.361916
40	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:56:31.945797
41	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:57:22.637061
42	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:59:08.332909
43	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:59:11.525514
44	\N	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:59:15.517354
45	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:59:44.726301
46	\N	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:59:48.570113
47	\N	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:59:52.404861
48	\N	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:59:56.199038
49	\N	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:59:59.503712
50	\N	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:00:03.221714
51	\N	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:00:06.553927
52	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:00:36.817951
53	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:00:56.653034
54	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:01:31.341273
55	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:01:35.192078
56	\N	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:01:39.957553
57	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:02:08.817945
58	\N	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:02:11.852345
59	\N	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:02:15.471212
60	\N	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:02:18.75698
61	\N	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:02:22.656356
62	\N	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:02:26.415187
63	\N	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:02:30.245486
64	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:03:36.7113
65	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:03:39.699503
66	\N	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:03:45.07221
67	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:04:13.493227
68	\N	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:04:16.500125
69	\N	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:04:21.464504
70	\N	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:04:25.1056
71	\N	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:04:28.694866
72	\N	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:04:31.760152
73	\N	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:04:34.995809
74	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:06:32.163703
75	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:06:59.033458
76	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:08:37.67802
77	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:08:40.651117
78	\N	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:08:45.379029
79	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:09:13.776141
80	\N	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:09:16.868402
81	\N	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:09:21.771982
82	\N	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:09:25.726381
83	\N	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:09:29.409438
84	\N	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:09:32.668995
85	\N	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:09:36.285491
86	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:10:46.291066
87	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:10:49.570511
88	\N	ghost	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:10:54.045291
89	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:11:13.685044
90	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:11:16.812206
91	\N	ghost	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:11:21.575586
92	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:18:28.43482
93	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:18:32.131081
94	\N	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:18:37.476621
95	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:19:07.148325
96	\N	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:19:10.282646
97	\N	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:19:14.401436
98	\N	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:19:17.497261
99	\N	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:19:21.001759
100	\N	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:19:24.590332
101	\N	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:19:28.015333
102	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:22:37.597228
103	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:22:41.286704
104	\N	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:22:46.821594
105	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:23:16.818263
106	\N	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:23:20.518561
107	\N	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:23:25.258448
108	\N	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:23:28.80415
109	\N	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:23:32.665575
110	\N	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:23:36.20878
111	\N	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:23:40.273496
112	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:00.839236
113	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:04.657485
114	\N	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:08.764097
115	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:39.040258
116	\N	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:42.761433
117	\N	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:47.383577
118	\N	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:50.818283
119	\N	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:54.777638
120	\N	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:58.423819
121	\N	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:29:02.003391
122	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:40:11.981623
123	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:40:14.90421
124	\N	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:40:20.124926
125	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:40:51.365468
126	\N	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:40:55.013894
127	\N	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:40:58.717721
128	\N	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:41:01.828236
129	\N	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:41:05.333511
130	\N	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:41:08.301071
131	\N	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:41:11.420048
132	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:46:22.436204
133	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:46:25.720826
134	\N	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:46:31.144807
135	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:47:02.379826
136	\N	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:47:05.627637
137	\N	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:47:09.326169
138	\N	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:47:12.419848
139	\N	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:47:15.622105
140	\N	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:47:18.844116
141	\N	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:47:21.950444
142	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:48:00.80511
143	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:48:16.999464
144	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 16:05:27.179317
145	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 16:05:45.295629
146	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 16:07:35.709649
147	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 16:08:20.086926
148	\N	reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:29:59.814803
149	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:30:07.466649
150	\N	reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:30:11.642779
151	\N	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:32:39.42664
152	\N	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:32:39.917869
153	\N	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:37:35.670215
154	\N	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:40:25.119005
155	\N	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:40:31.986421
156	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:40:40.866133
157	\N	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:40:45.804066
158	\N	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:41:42.755204
159	\N	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:41:49.619099
160	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:41:58.555095
161	\N	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:42:03.538827
162	\N	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:44:52.913572
163	\N	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:44:59.6546
164	\N	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:45:47.453598
165	\N	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:45:54.259752
166	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:46:05.340574
167	\N	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:46:11.053374
168	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:17:50.201663
169	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:28:00.915402
170	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:28:04.908233
171	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:29:06.916271
172	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:29:07.528762
173	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:29:11.089948
174	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:29:20.462423
175	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:30:06.629675
176	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:30:36.465985
177	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 20:03:59.38923
178	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 20:12:31.770846
179	\N	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 20:12:42.251549
180	\N	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 20:12:52.81278
181	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 20:42:05.4447
182	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 21:06:59.491999
183	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 21:07:16.141004
184	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 21:07:40.926495
185	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 21:11:05.678073
186	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 21:11:13.049962
187	\N	star_hospital_admin	ADMIN	ipd_discharge	admission_id=2	127.0.0.1	2026-03-10 21:17:13.437334
188	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 21:40:02.177418
189	\N	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 22:24:49.688801
190	\N	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 22:25:10.74596
191	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 22:26:44.804672
192	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:07:29.878803
193	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:19:15.764529
194	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:27:58.948535
195	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:28:03.137049
196	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:32:53.69845
197	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:36:45.431902
198	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:40:38.429321
199	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:41:03.705178
200	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:52:07.897731
201	\N	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=sai_care	127.0.0.1	2026-03-10 23:52:09.313155
202	\N	city_medical_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-10 23:52:10.769689
203	\N	apollo_warangal_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-10 23:52:14.529663
204	\N	green_cross_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=green_cross	127.0.0.1	2026-03-10 23:52:17.542765
205	\N	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:52:22.396741
206	\N	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=sai_care	127.0.0.1	2026-03-10 23:52:27.980733
207	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:56:32.448709
208	\N	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=sai_care	127.0.0.1	2026-03-10 23:56:33.887003
209	\N	city_medical_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-10 23:56:34.890989
210	\N	city_medical_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-10 23:56:36.009867
211	\N	apollo_warangal_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-10 23:56:37.172341
212	\N	green_cross_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=green_cross	127.0.0.1	2026-03-10 23:56:38.208487
213	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:19:25.167761
214	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:20:58.224384
215	\N	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=sai_care	127.0.0.1	2026-03-11 00:21:41.289301
216	\N	city_medical_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 00:21:45.084386
217	\N	apollo_warangal_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 00:21:48.380873
218	\N	green_cross_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=green_cross	127.0.0.1	2026-03-11 00:21:51.71895
219	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:21:56.25819
220	\N	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=sai_care	127.0.0.1	2026-03-11 00:22:01.85502
221	\N	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=sai_care	127.0.0.1	2026-03-11 00:22:22.383182
222	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:24:15.769032
223	\N	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=sai_care	127.0.0.1	2026-03-11 00:24:59.690866
224	\N	city_medical_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 00:25:02.989607
225	\N	apollo_warangal_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 00:25:06.206964
226	\N	green_cross_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=green_cross	127.0.0.1	2026-03-11 00:25:09.349236
227	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:25:13.960951
228	\N	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=sai_care	127.0.0.1	2026-03-11 00:25:19.362587
229	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:33:01.864427
230	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:38:18.205783
231	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:40:30.918801
232	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:43:57.593064
233	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:44:09.429051
234	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:47:41.956828
235	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:11:22.199447
236	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:13:40.734541
237	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:17:16.496346
238	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:17:29.412381
239	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:21:05.040304
240	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:21:19.189573
241	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:24:55.076916
242	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:25:09.244983
243	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:28:42.008431
244	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:28:54.649332
245	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:32:28.349018
246	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:44:24.235847
247	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 08:25:14.423002
248	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 08:32:52.362254
249	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 08:33:03.281129
250	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 08:49:19.723317
251	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 08:49:26.451483
252	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 08:49:52.924691
253	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 10:36:41.067012
254	\N	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 10:54:49.895799
255	\N	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 12:10:29.553384
\.


--
-- Data for Name: bed_assignments; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.bed_assignments (id, bed_id, patient_name, patient_phone, admitted_at, discharged_at, notes) FROM stdin;
\.


--
-- Data for Name: beds; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.beds (id, ward_id, bed_number, bed_type, status, created_at) FROM stdin;
\.


--
-- Data for Name: bill_items; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.bill_items (id, bill_id, item_type, item_name, item_price, quantity, actual_price, negotiated_price, tax_percent, tax_amount, total_amount, notes, created_at) FROM stdin;
\.


--
-- Data for Name: billing; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.billing (id, patient_name, patient_phone, bill_type, consultation_fee, lab_charges, pharmacy_charges, imaging_charges, misc_charges, total_amount, discount, net_amount, status, created_by, created_at, updated_at, bed_charges, surgery_charges, procedure_charges, tax_amount, admission_id, notes) FROM stdin;
1	Narsimha Reddy	9876543210	OPD	500.00	800.00	250.00	0.00	100.00	1650.00	100.00	1550.00	unpaid	\N	2026-03-10 20:52:54.35179	2026-03-10 20:52:54.35179	0.00	0.00	0.00	0.00	\N	
2	Lakshmi Devi	9876543211	IPD	0.00	0.00	0.00	0.00	500.00	18000.00	500.00	17500.00	unpaid	\N	2026-03-10 20:52:54.35179	2026-03-10 20:52:54.35179	3000.00	14500.00	0.00	0.00	\N	
3	Suresh Kumar	+91 9901000001	OPD	300.00	0.00	0.00	0.00	0.00	300.00	0.00	300.00	paid	star_hospital_admin	2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839	0.00	0.00	0.00	0.00	\N	
4	Lakshmi Devi	+91 9901000002	OPD	300.00	0.00	0.00	0.00	0.00	300.00	0.00	300.00	paid	star_hospital_admin	2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839	0.00	0.00	0.00	0.00	\N	
5	Ravi Teja	+91 9901000003	OPD	300.00	0.00	0.00	0.00	0.00	300.00	0.00	300.00	paid	star_hospital_admin	2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839	0.00	0.00	0.00	0.00	\N	
6	Anita Rao	+91 9901000004	OPD	300.00	0.00	0.00	0.00	0.00	300.00	0.00	300.00	paid	star_hospital_admin	2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839	0.00	0.00	0.00	0.00	\N	
7	Suresh Kumar	+91 9901000001	OPD	300.00	0.00	0.00	0.00	0.00	300.00	0.00	300.00	paid	star_hospital_admin	2026-03-11 00:09:14.00081	2026-03-11 00:09:14.00081	0.00	0.00	0.00	0.00	\N	
8	Lakshmi Devi	+91 9901000002	OPD	300.00	0.00	0.00	0.00	0.00	300.00	0.00	300.00	paid	star_hospital_admin	2026-03-11 00:09:14.00081	2026-03-11 00:09:14.00081	0.00	0.00	0.00	0.00	\N	
9	Ravi Teja	+91 9901000003	OPD	300.00	0.00	0.00	0.00	0.00	300.00	0.00	300.00	paid	star_hospital_admin	2026-03-11 00:09:14.00081	2026-03-11 00:09:14.00081	0.00	0.00	0.00	0.00	\N	
10	Anita Rao	+91 9901000004	OPD	300.00	0.00	0.00	0.00	0.00	300.00	0.00	300.00	paid	star_hospital_admin	2026-03-11 00:09:14.00081	2026-03-11 00:09:14.00081	0.00	0.00	0.00	0.00	\N	
11	Suresh Kumar	+91 9901000001	OPD	300.00	0.00	0.00	0.00	0.00	300.00	0.00	300.00	paid	star_hospital_admin	2026-03-11 00:10:54.135292	2026-03-11 00:10:54.135292	0.00	0.00	0.00	0.00	\N	
12	Lakshmi Devi	+91 9901000002	OPD	300.00	0.00	0.00	0.00	0.00	300.00	0.00	300.00	paid	star_hospital_admin	2026-03-11 00:10:54.135292	2026-03-11 00:10:54.135292	0.00	0.00	0.00	0.00	\N	
13	Ravi Teja	+91 9901000003	OPD	300.00	0.00	0.00	0.00	0.00	300.00	0.00	300.00	paid	star_hospital_admin	2026-03-11 00:10:54.135292	2026-03-11 00:10:54.135292	0.00	0.00	0.00	0.00	\N	
14	Anita Rao	+91 9901000004	OPD	300.00	0.00	0.00	0.00	0.00	300.00	0.00	300.00	paid	star_hospital_admin	2026-03-11 00:10:54.135292	2026-03-11 00:10:54.135292	0.00	0.00	0.00	0.00	\N	
15	Suresh Kumar	+91 9901000001	OPD	300.00	0.00	0.00	0.00	0.00	300.00	0.00	300.00	paid	star_hospital_admin	2026-03-11 00:12:31.614172	2026-03-11 00:12:31.614172	0.00	0.00	0.00	0.00	\N	
16	Lakshmi Devi	+91 9901000002	OPD	300.00	0.00	0.00	0.00	0.00	300.00	0.00	300.00	paid	star_hospital_admin	2026-03-11 00:12:31.614172	2026-03-11 00:12:31.614172	0.00	0.00	0.00	0.00	\N	
17	Ravi Teja	+91 9901000003	OPD	300.00	0.00	0.00	0.00	0.00	300.00	0.00	300.00	paid	star_hospital_admin	2026-03-11 00:12:31.614172	2026-03-11 00:12:31.614172	0.00	0.00	0.00	0.00	\N	
18	Anita Rao	+91 9901000004	OPD	300.00	0.00	0.00	0.00	0.00	300.00	0.00	300.00	paid	star_hospital_admin	2026-03-11 00:12:31.614172	2026-03-11 00:12:31.614172	0.00	0.00	0.00	0.00	\N	
19	Priya Sharma	9908297152	OPD	0.00	0.00	0.00	0.00	0.00	2457.00	0.00	2457.00	unpaid	\N	2026-02-24 00:00:00	2026-03-12 02:35:04.306367	0.00	0.00	0.00	0.00	\N	
20	Lakshmi Bai	9479915632	OPD	0.00	0.00	0.00	0.00	0.00	11827.00	0.00	11827.00	paid	\N	2026-02-18 00:00:00	2026-03-12 02:35:04.306367	0.00	0.00	0.00	0.00	\N	
21	Arun Verma	9404788539	Pharmacy	0.00	0.00	0.00	0.00	0.00	10099.00	0.00	10099.00	partial	\N	2026-02-26 00:00:00	2026-03-12 02:35:04.306367	0.00	0.00	0.00	0.00	\N	
22	Suresh Reddy	9876543212	OPD	0.00	0.00	0.00	0.00	0.00	3821.00	0.00	3821.00	paid	\N	2026-02-26 00:00:00	2026-03-12 02:35:04.306367	0.00	0.00	0.00	0.00	\N	
23	Lakshmi Bai	9479915632	OPD	0.00	0.00	0.00	0.00	0.00	1986.00	0.00	1986.00	paid	\N	2026-03-03 00:00:00	2026-03-12 02:35:04.306367	0.00	0.00	0.00	0.00	\N	
24	Anita Rao	+91 9901000004	OPD	0.00	0.00	0.00	0.00	0.00	5147.00	0.00	5147.00	unpaid	\N	2026-02-11 00:00:00	2026-03-12 02:35:04.306367	0.00	0.00	0.00	0.00	\N	
25	Suresh Reddy	9145032355	OPD	0.00	0.00	0.00	0.00	0.00	5020.00	0.00	5020.00	unpaid	\N	2026-02-18 00:00:00	2026-03-12 02:35:04.306367	0.00	0.00	0.00	0.00	\N	
26	Suresh Reddy	9876543212	Pharmacy	0.00	0.00	0.00	0.00	0.00	2273.00	0.00	2273.00	paid	\N	2026-02-21 00:00:00	2026-03-12 02:35:04.306367	0.00	0.00	0.00	0.00	\N	
27	Venkatesh Rao	9903634942	IPD	0.00	0.00	0.00	0.00	0.00	6780.00	0.00	6780.00	partial	\N	2026-02-17 00:00:00	2026-03-12 02:35:04.306367	0.00	0.00	0.00	0.00	\N	
28	Ravi Teja	+91 9901000003	Pharmacy	0.00	0.00	0.00	0.00	0.00	8864.00	0.00	8864.00	partial	\N	2026-02-16 00:00:00	2026-03-12 02:35:04.306367	0.00	0.00	0.00	0.00	\N	
29	Mohan Das	9449556491	OPD	0.00	0.00	0.00	0.00	0.00	2444.00	0.00	2444.00	partial	\N	2026-02-22 00:00:00	2026-03-12 02:35:04.306367	0.00	0.00	0.00	0.00	\N	
30	Mohan Das	9449556491	OPD	0.00	0.00	0.00	0.00	0.00	1154.00	0.00	1154.00	partial	\N	2026-03-11 00:00:00	2026-03-12 02:35:04.306367	0.00	0.00	0.00	0.00	\N	
31	Arun Verma	9404788539	IPD	0.00	0.00	0.00	0.00	0.00	8823.00	0.00	8823.00	paid	\N	2026-02-24 00:00:00	2026-03-12 02:35:04.306367	0.00	0.00	0.00	0.00	\N	
32	Priya Sharma	9876543211	OPD	0.00	0.00	0.00	0.00	0.00	833.00	0.00	833.00	paid	\N	2026-02-17 00:00:00	2026-03-12 02:35:04.306367	0.00	0.00	0.00	0.00	\N	
33	Ramesh Babu	9541839267	OPD	0.00	0.00	0.00	0.00	0.00	10086.00	0.00	10086.00	unpaid	\N	2026-02-12 00:00:00	2026-03-12 02:35:04.306367	0.00	0.00	0.00	0.00	\N	
\.


--
-- Data for Name: billing_accounts; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.billing_accounts (id, client_id, plan_name, price, billing_cycle, next_payment_date, trial_end_date, payment_status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.clients (client_id, slug, hospital_name, hospital_phone, hospital_address, city, state, country, tagline, logo_path, primary_color, secondary_color, database_name, is_active, created_at, subdomain, plan_type, status, billing_start_date, billing_expiry_date, last_activity, db_status, admin_email) FROM stdin;
1	star_hospital	Star Hospital	+91 7981971015	Karur Vysya Bank Lane, Ganesh Basthi, Kothagudem, Telangana 507101, India	Kothagudem	Telangana	India	24x7 Emergency Medical Services Available		#1a73e8	#00b896	hospital_ai	t	2026-03-10 07:06:48.085847		starter	active	\N	\N	\N	ready	
\.


--
-- Data for Name: daily_rounds; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.daily_rounds (id, admission_id, patient_name, doctor_name, doctor_username, round_date, bp, pulse, temperature, spo2, clinical_notes, treatment_change, created_at) FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.departments (id, name, description, head_doctor, is_active, created_at) FROM stdin;
121	Orthopedics	Bone & Joint Care	Dr. Srujan	t	2026-03-10 18:27:56.662472
122	General Medicine	General Medicine & Diabetes	Dr. K. Ramyanadh	t	2026-03-10 18:27:56.662472
123	General Surgery	Surgical Procedures	Dr. B. Ramachandra Nayak	t	2026-03-10 18:27:56.662472
124	Dental	Dental Care		t	2026-03-10 18:27:56.662472
125	ENT	Ear Nose Throat		t	2026-03-10 18:27:56.662472
\.


--
-- Data for Name: discharge_summaries; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.discharge_summaries (id, admission_id, patient_name, discharge_date, final_diagnosis, treatment_given, discharge_medicines, follow_up_date, follow_up_notes, diet_advice, activity_advice, doctor_name, doctor_username, bill_id, created_at) FROM stdin;
1	2	Narsimha Reddy	2026-03-10 21:17:13.284302	fever	siva	pracetomoal	2025-03-10	nothing			Hospital Administrator	star_hospital_admin	\N	2026-03-10 21:17:13.284302
\.


--
-- Data for Name: doctor_attendance; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.doctor_attendance (id, doctor_name, action, shift, notes, recorded_at) FROM stdin;
\.


--
-- Data for Name: doctor_notes; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.doctor_notes (note_id, patient_id, visit_id, doctor_username, doctor_name, note_type, note_text, created_at) FROM stdin;
\.


--
-- Data for Name: doctor_rounds; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.doctor_rounds (id, doctor_name, ward, round_time, status, notes, scheduled_at, completed_at) FROM stdin;
\.


--
-- Data for Name: doctors; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.doctors (id, name, department, specialization, phone, status, on_duty, created_at, qualifications, registration_no) FROM stdin;
1	Dr. Srujan	Orthopedics	Orthopedics		available	f	2026-03-10 18:27:56.662472	DNB Ortho FIJR	87679
3	Dr. B. Ramachandra Nayak	General Surgery	General Surgery		available	f	2026-03-10 18:27:56.662472	M.B.B.S., M.S.	13888
2	Dr. K. Ramyanadh	General Medicine	General Medicine / Diabetology		available	t	2026-03-10 18:27:56.662472	General Medicine (UK), Diabetology	111431
\.


--
-- Data for Name: hospital_expenses; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.hospital_expenses (expense_id, expense_date, category, sub_category, description, amount, payment_mode, vendor, invoice_ref, recurring, created_by, created_at) FROM stdin;
1	2026-03-01	Rent & Premises		Monthly hospital rent	85000.00	Bank Transfer			t	admin	2026-03-12 02:35:04.306367
2	2026-03-01	Staff Salaries		Monthly payroll	320000.00	Bank Transfer			t	admin	2026-03-12 02:35:04.306367
3	2026-03-01	Electricity & Power		Electricity bill - APSPDCL	28000.00	Bank Transfer			t	admin	2026-03-12 02:35:04.306367
4	2026-03-01	Water & Utilities		Municipal water charges	4500.00	Bank Transfer			t	admin	2026-03-12 02:35:04.306367
5	2026-03-01	Internet & Communication		Broadband + CCTV plan	3000.00	Bank Transfer			t	admin	2026-03-12 02:35:04.306367
6	2026-03-01	Medical Equipment		ECG machine EMI	45000.00	Bank Transfer			f	admin	2026-03-12 02:35:04.306367
7	2026-03-01	Medicines & Consumables		Monthly pharmacy stock	38000.00	Bank Transfer			f	admin	2026-03-12 02:35:04.306367
8	2026-03-01	Insurance		Hospital liability insurance	12000.00	Bank Transfer			t	admin	2026-03-12 02:35:04.306367
9	2026-03-01	Maintenance & Repairs		Generator service	8500.00	Bank Transfer			f	admin	2026-03-12 02:35:04.306367
10	2026-03-01	Marketing & Advertising		Google Ads + pamphlets	6000.00	Bank Transfer			f	admin	2026-03-12 02:35:04.306367
11	2026-03-01	Lab Supplies		Lab reagents & consumables	14000.00	Bank Transfer			f	admin	2026-03-12 02:35:04.306367
12	2026-03-01	Housekeeping		Cleaning & sanitisation	9500.00	Bank Transfer			t	admin	2026-03-12 02:35:04.306367
\.


--
-- Data for Name: imaging_orders; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.imaging_orders (id, patient_name, patient_phone, doctor_username, modality, body_part, clinical_notes, status, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: imaging_reports; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.imaging_reports (id, order_id, patient_name, modality, findings, impression, report_file_path, radiologist, reported_at) FROM stdin;
\.


--
-- Data for Name: imaging_tests; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.imaging_tests (id, test_code, test_name, modality, body_part, price, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: inventory_stock; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.inventory_stock (id, medicine_id, batch_no, expiry_date, quantity, min_quantity, purchase_price, sell_price, updated_at, supplier, batch_number) FROM stdin;
1	16	INV0016	2027-12-31	100	20	5.00	8.00	2026-03-11 00:09:13.870813	Demo Supply	
2	17	INV0017	2027-12-31	100	20	12.00	18.00	2026-03-11 00:09:13.870813	Demo Supply	
3	18	INV0018	2027-12-31	100	20	8.50	15.00	2026-03-11 00:09:13.870813	Demo Supply	
4	19	INV0019	2027-12-31	100	20	3.50	6.00	2026-03-11 00:09:13.870813	Demo Supply	
5	20	INV0020	2027-12-31	100	20	6.00	10.00	2026-03-11 00:09:13.870813	Demo Supply	
\.


--
-- Data for Name: lab_orders; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.lab_orders (id, patient_name, patient_phone, doctor_username, test_type, test_name, status, result_text, result_file, created_at, completed_at, prescription_id, patient_id, visit_id, urgency, lab_notes) FROM stdin;
4	Narsimha Reddy	9876543210	star_hospital_doctor	LAB	Complete Blood Count (CBC)	COMPLETED	Hb: 13.2 g/dL | WBC: 8200/uL | Platelets: 210K/uL — All within normal range.		2026-03-10 20:52:54.35179	\N	\N	\N	\N	routine	
5	Lakshmi Devi	9876543211	star_hospital_doctor	SCAN	X-Ray Chest	PENDING			2026-03-10 20:52:54.35179	\N	\N	\N	\N	routine	
1	E2E Test 139492	99000139492	star_hospital_doctor	Blood	CBC	PENDING			2026-03-10 18:45:01.757103	\N	1	\N	\N	routine	
2	E2E Test 139547	99000139547	star_hospital_doctor	Blood	CBC	PENDING			2026-03-10 18:45:56.363502	\N	2	\N	\N	routine	
6	Suresh Kumar	+91 9901000001	star_hospital_doctor	Pathology	CBC	pending			2026-03-11 00:04:09.403839	\N	\N	9	\N	routine	
7	Suresh Kumar	+91 9901000001	star_hospital_doctor	Pathology	Blood Sugar	pending			2026-03-11 00:04:09.403839	\N	\N	9	\N	routine	
8	Suresh Kumar	+91 9901000001	star_hospital_doctor	Pathology	Urine Routine	pending			2026-03-11 00:04:09.403839	\N	\N	9	\N	routine	
9	Lakshmi Devi	+91 9901000002	star_hospital_doctor	Pathology	CBC	pending			2026-03-11 00:04:09.403839	\N	\N	10	\N	routine	
10	Lakshmi Devi	+91 9901000002	star_hospital_doctor	Pathology	Blood Sugar	pending			2026-03-11 00:04:09.403839	\N	\N	10	\N	routine	
11	Lakshmi Devi	+91 9901000002	star_hospital_doctor	Pathology	Urine Routine	pending			2026-03-11 00:04:09.403839	\N	\N	10	\N	routine	
12	Ravi Teja	+91 9901000003	star_hospital_doctor	Pathology	CBC	pending			2026-03-11 00:04:09.403839	\N	\N	11	\N	routine	
13	Ravi Teja	+91 9901000003	star_hospital_doctor	Pathology	Blood Sugar	pending			2026-03-11 00:04:09.403839	\N	\N	11	\N	routine	
14	Ravi Teja	+91 9901000003	star_hospital_doctor	Pathology	Urine Routine	pending			2026-03-11 00:04:09.403839	\N	\N	11	\N	routine	
15	Suresh Kumar	+91 9901000001	star_hospital_doctor	Pathology	CBC	pending			2026-03-11 00:09:14.00081	\N	\N	9	\N	routine	
16	Suresh Kumar	+91 9901000001	star_hospital_doctor	Pathology	Blood Sugar	pending			2026-03-11 00:09:14.00081	\N	\N	9	\N	routine	
17	Suresh Kumar	+91 9901000001	star_hospital_doctor	Pathology	Urine Routine	pending			2026-03-11 00:09:14.00081	\N	\N	9	\N	routine	
18	Lakshmi Devi	+91 9901000002	star_hospital_doctor	Pathology	CBC	pending			2026-03-11 00:09:14.00081	\N	\N	10	\N	routine	
19	Lakshmi Devi	+91 9901000002	star_hospital_doctor	Pathology	Blood Sugar	pending			2026-03-11 00:09:14.00081	\N	\N	10	\N	routine	
20	Lakshmi Devi	+91 9901000002	star_hospital_doctor	Pathology	Urine Routine	pending			2026-03-11 00:09:14.00081	\N	\N	10	\N	routine	
21	Ravi Teja	+91 9901000003	star_hospital_doctor	Pathology	CBC	pending			2026-03-11 00:09:14.00081	\N	\N	11	\N	routine	
22	Ravi Teja	+91 9901000003	star_hospital_doctor	Pathology	Blood Sugar	pending			2026-03-11 00:09:14.00081	\N	\N	11	\N	routine	
23	Ravi Teja	+91 9901000003	star_hospital_doctor	Pathology	Urine Routine	pending			2026-03-11 00:09:14.00081	\N	\N	11	\N	routine	
24	Suresh Kumar	+91 9901000001	star_hospital_doctor	Pathology	CBC	pending			2026-03-11 00:10:54.135292	\N	\N	9	\N	routine	
25	Suresh Kumar	+91 9901000001	star_hospital_doctor	Pathology	Blood Sugar	pending			2026-03-11 00:10:54.135292	\N	\N	9	\N	routine	
26	Suresh Kumar	+91 9901000001	star_hospital_doctor	Pathology	Urine Routine	pending			2026-03-11 00:10:54.135292	\N	\N	9	\N	routine	
27	Lakshmi Devi	+91 9901000002	star_hospital_doctor	Pathology	CBC	pending			2026-03-11 00:10:54.135292	\N	\N	10	\N	routine	
28	Lakshmi Devi	+91 9901000002	star_hospital_doctor	Pathology	Blood Sugar	pending			2026-03-11 00:10:54.135292	\N	\N	10	\N	routine	
29	Lakshmi Devi	+91 9901000002	star_hospital_doctor	Pathology	Urine Routine	pending			2026-03-11 00:10:54.135292	\N	\N	10	\N	routine	
30	Ravi Teja	+91 9901000003	star_hospital_doctor	Pathology	CBC	pending			2026-03-11 00:10:54.135292	\N	\N	11	\N	routine	
31	Ravi Teja	+91 9901000003	star_hospital_doctor	Pathology	Blood Sugar	pending			2026-03-11 00:10:54.135292	\N	\N	11	\N	routine	
32	Ravi Teja	+91 9901000003	star_hospital_doctor	Pathology	Urine Routine	pending			2026-03-11 00:10:54.135292	\N	\N	11	\N	routine	
33	Suresh Kumar	+91 9901000001	star_hospital_doctor	Pathology	CBC	pending			2026-03-11 00:12:31.614172	\N	\N	9	\N	routine	
34	Suresh Kumar	+91 9901000001	star_hospital_doctor	Pathology	Blood Sugar	pending			2026-03-11 00:12:31.614172	\N	\N	9	\N	routine	
35	Suresh Kumar	+91 9901000001	star_hospital_doctor	Pathology	Urine Routine	pending			2026-03-11 00:12:31.614172	\N	\N	9	\N	routine	
36	Lakshmi Devi	+91 9901000002	star_hospital_doctor	Pathology	CBC	pending			2026-03-11 00:12:31.614172	\N	\N	10	\N	routine	
37	Lakshmi Devi	+91 9901000002	star_hospital_doctor	Pathology	Blood Sugar	pending			2026-03-11 00:12:31.614172	\N	\N	10	\N	routine	
38	Lakshmi Devi	+91 9901000002	star_hospital_doctor	Pathology	Urine Routine	pending			2026-03-11 00:12:31.614172	\N	\N	10	\N	routine	
39	Ravi Teja	+91 9901000003	star_hospital_doctor	Pathology	CBC	pending			2026-03-11 00:12:31.614172	\N	\N	11	\N	routine	
40	Ravi Teja	+91 9901000003	star_hospital_doctor	Pathology	Blood Sugar	pending			2026-03-11 00:12:31.614172	\N	\N	11	\N	routine	
41	Ravi Teja	+91 9901000003	star_hospital_doctor	Pathology	Urine Routine	pending			2026-03-11 00:12:31.614172	\N	\N	11	\N	routine	
\.


--
-- Data for Name: lab_reports; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.lab_reports (id, order_id, patient_name, patient_phone, test_name, result_text, result_file_path, remarks, lab_username, reported_at) FROM stdin;
1	\N	Arun Verma	9404788539	Complete Blood Count	Hemoglobin: 13.5 g/dL, WBC: 7200, Platelets: 2.8 lakhs – All Normal			\N	2026-03-12 00:00:00
2	\N	Sunita Patel	9643786082	Blood Sugar Fasting	FBS: 98 mg/dL – Normal (ref: 70–100)			\N	2026-03-09 00:00:00
3	\N	Kavitha Nair	9908513002	Urine Routine	Colour: Pale yellow, Pus Cells: 2-4, No sugar, No albumin – Normal			\N	2026-03-06 00:00:00
\.


--
-- Data for Name: lab_results; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.lab_results (result_id, order_id, patient_id, patient_name, test_name, result_value, reference_range, unit, is_abnormal, remarks, lab_username, reported_at) FROM stdin;
\.


--
-- Data for Name: lab_tests; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.lab_tests (id, test_code, test_name, category, normal_range, unit, price, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: medicines; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.medicines (id, medicine_name, generic_name, category, manufacturer, unit, unit_price, is_active, created_at) FROM stdin;
3	Paracetamol 500mg	Paracetamol	Analgesic		Tablet	2.50	t	2026-03-10 20:52:54.35179
4	Cetirizine 10mg	Cetirizine	Antihistamine		Tablet	3.00	t	2026-03-10 20:52:54.35179
5	Metformin 500mg	Metformin	Antidiabetic		Tablet	4.00	t	2026-03-10 20:52:54.35179
6	Amoxicillin 250mg	Amoxicillin	Antibiotic		Capsule	6.00	t	2026-03-10 20:52:54.35179
7	Amoxicillin 500mg	Amoxicillin	Antibiotic		Capsule	6.00	t	2026-03-10 21:46:12.742946
8	Amlodipine 5mg	Amlodipine Besylate	Antihypertensive		Tablet	5.00	t	2026-03-10 21:46:12.742946
9	Omeprazole 20mg	Omeprazole	Antacid		Capsule	8.00	t	2026-03-10 21:46:12.742946
10	Azithromycin 250mg	Azithromycin	Antibiotic		Tablet	18.00	t	2026-03-10 21:46:12.742946
11	Pantoprazole 40mg	Pantoprazole	Antacid		Tablet	9.50	t	2026-03-10 21:46:12.742946
12	Atorvastatin 10mg	Atorvastatin	Cholesterol		Tablet	12.00	t	2026-03-10 21:46:12.742946
13	Ibuprofen 400mg	Ibuprofen	NSAID		Tablet	4.00	t	2026-03-10 21:46:12.742946
14	Vitamin D3 60k IU	Cholecalciferol	Supplement		Capsule	25.00	t	2026-03-10 21:46:12.742946
15	Insulin Glargine 3ml	Insulin Glargine	Insulin		Vial	180.00	t	2026-03-10 21:46:12.742946
16	Paracetamol 500mg Tablet	Generic	Tablet	Cipla	Strip	5.00	t	2026-03-11 00:09:13.870813
17	Amoxicillin 250mg Cap	Antibiotic	Capsule	Sun Pharma	Strip	12.00	t	2026-03-11 00:09:13.870813
18	Pantoprazole 40mg Tab	Antacid	Tablet	Dr Reddys	Strip	8.50	t	2026-03-11 00:09:13.870813
19	Cetirizine 10mg Tab	Antihistamine	Tablet	Cipla	Strip	3.50	t	2026-03-11 00:09:13.870813
20	Metformin 500mg Tab	Antidiabetic	Tablet	Sun Pharma	Strip	6.00	t	2026-03-11 00:09:13.870813
21	Amlodipine 5mg Tab	Antihypertensive	Tablet	Lupin	Strip	9.00	t	2026-03-11 00:09:13.870813
22	Azithromycin 500mg Tab	Antibiotic	Tablet	Cipla	Strip	45.00	t	2026-03-11 00:09:13.870813
23	Ibuprofen 400mg Tab	NSAID	Tablet	Abbott	Strip	7.50	t	2026-03-11 00:09:13.870813
24	ORS Sachet	Electrolyte	Sachet	Electral	Strip	2.50	t	2026-03-11 00:09:13.870813
25	Vitamin D3 60K Cap	Supplement	Capsule	HealthVit	Strip	30.00	t	2026-03-11 00:09:13.870813
\.


--
-- Data for Name: notification_logs; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.notification_logs (id, tenant_slug, channel, event_type, recipient, message_preview, status, provider_response, created_at) FROM stdin;
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.notification_settings (id, tenant_slug, setting_key, setting_value, is_encrypted, updated_at, updated_by) FROM stdin;
1		active_provider	telegram	f	2026-03-10 17:25:48.316931	
2		telegram_enabled	true	f	2026-03-10 17:25:48.316931	
3		telegram_bot_token		f	2026-03-10 17:25:48.316931	
4		telegram_chat_id		f	2026-03-10 17:25:48.316931	
5		whatsapp_enabled	false	f	2026-03-10 17:25:48.316931	
6		whatsapp_provider_name	twilio	f	2026-03-10 17:25:48.316931	
7		whatsapp_api_base_url		f	2026-03-10 17:25:48.316931	
8		whatsapp_api_key		f	2026-03-10 17:25:48.316931	
9		whatsapp_sender_number		f	2026-03-10 17:25:48.316931	
10		whatsapp_template_id		f	2026-03-10 17:25:48.316931	
11		owner_contact_number		f	2026-03-10 17:25:48.316931	
12		patient_reminders_enabled	true	f	2026-03-10 17:25:48.316931	
13		end_of_day_summary_enabled	true	f	2026-03-10 17:25:48.316931	
22	star_hospital	active_provider	telegram	f	2026-03-10 20:52:54.35179	
23	star_hospital	telegram_token	8535042281:AAG6koMQ17LVJPigw8TNzJq5fAGZNEYObkE	t	2026-03-10 20:52:54.35179	
25	star_hospital	notify_on_appointment	true	f	2026-03-10 20:52:54.35179	
26	star_hospital	notify_on_prescription	true	f	2026-03-10 20:52:54.35179	
27	star_hospital	notify_on_lab_result	true	f	2026-03-10 20:52:54.35179	
28	star_hospital	notify_on_discharge	true	f	2026-03-10 20:52:54.35179	
29	star_hospital	daily_summary_enabled	true	f	2026-03-10 20:52:54.35179	
30	star_hospital	telegram_bot_token	8575178795:AAHjNz-MMmKFe54IPVFbgooMP4suyxOMPmQ	t	2026-03-10 21:52:30.788516	admin
24	star_hospital	telegram_chat_id	7144152487	f	2026-03-10 21:52:30.788516	
32	star_hospital	whatsapp_enabled	false	f	2026-03-11 00:04:09.403839	star_hospital_admin
33	star_hospital	email_enabled	false	f	2026-03-11 00:04:09.403839	star_hospital_admin
34	star_hospital	sms_enabled	false	f	2026-03-11 00:04:09.403839	star_hospital_admin
\.


--
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.notification_templates (id, tenant_slug, template_key, subject, body, variables, is_active, updated_at) FROM stdin;
1		appointment_confirmation	Appointment Confirmed	🏥 *{hospital_name}*\\n\\nDear {patient_name}, your appointment is confirmed.\\n📅 Date: {date}\\n⏰ Time: {time}\\n👨‍⚕️ Doctor: {doctor_name}\\n\\nPlease arrive 10 minutes early. Call {hospital_phone} for queries.	hospital_name,patient_name,date,time,doctor_name,hospital_phone	t	2026-03-10 17:25:48.316931
2		follow_up_reminder	Follow-Up Reminder	🏥 *{hospital_name}*\\n\\nDear {patient_name}, your follow-up is due today.\\n👨‍⚕️ Dr. {doctor_name} advised follow-up on {follow_up_date}.\\n\\nCall {hospital_phone} to book.	hospital_name,patient_name,doctor_name,follow_up_date,hospital_phone	t	2026-03-10 17:25:48.316931
3		lab_report_ready	Lab Report Ready	🏥 *{hospital_name}*\\n\\nDear {patient_name}, your lab report for *{test_name}* is ready.\\nPlease collect from the lab counter.\\n\\nCall {hospital_phone} for queries.	hospital_name,patient_name,test_name,hospital_phone	t	2026-03-10 17:25:48.316931
4		prescription_share	Your Prescription	🏥 *{hospital_name}*\\n\\nDear {patient_name}, your prescription from Dr. {doctor_name} is ready.\\n📄 View/Download: {pdf_url}\\n\\nFollow the prescribed medicines carefully. Call {hospital_phone} for queries.	hospital_name,patient_name,doctor_name,pdf_url,hospital_phone	t	2026-03-10 17:25:48.316931
5		discharge_summary	Discharge Summary	🏥 *{hospital_name}*\\n\\nDear {patient_name}, you have been discharged on {discharge_date}.\\nPlease follow the discharge instructions carefully.\\nNext follow-up: {follow_up_date}\\n\\nCall {hospital_phone} for any concerns.	hospital_name,patient_name,discharge_date,follow_up_date,hospital_phone	t	2026-03-10 17:25:48.316931
6		owner_daily_summary	Daily Summary — {date}	📊 *{hospital_name} — Daily Report ({date})*\\n\\nOPD Patients: {opd_count}\\nIPD Patients: {ipd_count}\\nTotal Collections: ₹{collections}\\nPending Bills: {pending_bills}\\nNotifications Sent: {notif_count}\\n\\nPowered by SRP MediFlow	hospital_name,date,opd_count,ipd_count,collections,pending_bills,notif_count	t	2026-03-10 17:25:48.316931
\.


--
-- Data for Name: nurse_assignments; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.nurse_assignments (id, nurse_username, patient_name, patient_phone, ward, bed_number, shift, assigned_at, discharged_at) FROM stdin;
\.


--
-- Data for Name: op_tickets; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.op_tickets (ticket_id, ticket_no, patient_id, visit_id, doctor_name, department, issued_at, status) FROM stdin;
\.


--
-- Data for Name: patient_admissions; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.patient_admissions (id, patient_name, patient_phone, patient_aadhar, age, gender, blood_group, address, admission_date, discharge_date, ward_name, bed_number, admitting_doctor, department, diagnosis, admission_notes, status, created_by, created_at, updated_at) FROM stdin;
2	Narsimha Reddy	9876543210		45	Male			2026-03-10 20:52:54.35179	2026-03-10 21:17:13.284302	General Ward	B-12	Dr. K. Ramyanadh		Typhoid Fever		discharged	reception	2026-03-10 20:52:54.35179	2026-03-10 21:17:13.284302
3	Suresh Kumar	+91 9901000001		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	star_hospital_doctor	General Medicine	Fever observation		admitted	star_hospital_admin	2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839
4	Lakshmi Devi	+91 9901000002		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	star_hospital_doctor	General Medicine	Fever observation		admitted	star_hospital_admin	2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839
5	Suresh Kumar	+91 9901000001		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	star_hospital_doctor	General Medicine	Fever observation		admitted	star_hospital_admin	2026-03-11 00:09:14.00081	2026-03-11 00:09:14.00081
6	Lakshmi Devi	+91 9901000002		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	star_hospital_doctor	General Medicine	Fever observation		admitted	star_hospital_admin	2026-03-11 00:09:14.00081	2026-03-11 00:09:14.00081
7	Ravi Teja	+91 9901000003		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	star_hospital_doctor	General Medicine	Fever observation		admitted	star_hospital_admin	2026-03-11 00:09:14.00081	2026-03-11 00:09:14.00081
8	Suresh Kumar	+91 9901000001		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	star_hospital_doctor	General Medicine	Fever observation		admitted	star_hospital_admin	2026-03-11 00:10:54.135292	2026-03-11 00:10:54.135292
9	Lakshmi Devi	+91 9901000002		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	star_hospital_doctor	General Medicine	Fever observation		admitted	star_hospital_admin	2026-03-11 00:10:54.135292	2026-03-11 00:10:54.135292
10	Ravi Teja	+91 9901000003		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	star_hospital_doctor	General Medicine	Fever observation		admitted	star_hospital_admin	2026-03-11 00:10:54.135292	2026-03-11 00:10:54.135292
11	Suresh Kumar	+91 9901000001		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	star_hospital_doctor	General Medicine	Fever observation		admitted	star_hospital_admin	2026-03-11 00:12:31.614172	2026-03-11 00:12:31.614172
12	Lakshmi Devi	+91 9901000002		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	star_hospital_doctor	General Medicine	Fever observation		admitted	star_hospital_admin	2026-03-11 00:12:31.614172	2026-03-11 00:12:31.614172
13	Ravi Teja	+91 9901000003		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	star_hospital_doctor	General Medicine	Fever observation		admitted	star_hospital_admin	2026-03-11 00:12:31.614172	2026-03-11 00:12:31.614172
\.


--
-- Data for Name: patient_visits; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.patient_visits (visit_id, patient_id, visit_type, doctor_assigned, doctor_username, department, visit_date, chief_complaint, diagnosis, notes, status, op_ticket_no, created_at) FROM stdin;
\.


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.patients (id, full_name, dob, gender, phone, aadhar, address, blood_group, allergies, created_at, updated_at, uhid) FROM stdin;
6	Rajesh Kumar	\N	M	9876543210	\N				2026-03-10 22:51:23.748686	2026-03-10 22:51:23.748686	\N
7	Priya Sharma	\N	F	9876543211	\N				2026-03-10 22:51:23.748686	2026-03-10 22:51:23.748686	\N
8	Suresh Reddy	\N	M	9876543212	\N				2026-03-10 22:51:23.748686	2026-03-10 22:51:23.748686	\N
9	Suresh Kumar	1978-05-10	Male	+91 9901000001	\N		B+		2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839	\N
10	Lakshmi Devi	1991-08-22	Female	+91 9901000002	\N		B+		2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839	\N
11	Ravi Teja	1995-03-14	Male	+91 9901000003	\N		B+		2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839	\N
12	Anita Rao	1968-11-30	Female	+91 9901000004	\N		B+		2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839	\N
13	Meena Reddy	1985-02-17	Female	+91 9901000006	\N		B+		2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839	\N
14	Rajesh Kumar	1965-03-27	Female	9858489898	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
15	Priya Sharma	1975-03-25	Female	9908297152	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
16	Suresh Reddy	1955-03-30	Female	9145032355	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
17	Anita Devi	1973-03-25	Female	9893361584	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
18	Venkatesh Rao	1968-03-26	Female	9903634942	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
19	Lakshmi Bai	1960-03-28	Male	9479915632	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
20	Mohan Das	2004-03-17	Male	9449556491	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
21	Kavitha Nair	1992-03-20	Male	9908513002	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
22	Ramesh Babu	1954-03-30	Female	9541839267	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
23	Sunita Patel	1961-03-28	Female	9643786082	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
24	Arun Verma	1978-03-24	Female	9404788539	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
25	Meena Kumari	1972-03-25	Male	9607774036	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
26	Srinivas Yadav	1991-03-21	Female	9479072322	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
27	Deepa Singh	1998-03-19	Female	9319385642	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
28	Kishore Kumar	1961-03-28	Male	9797757706	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
29	Bhavani Devi	1994-03-20	Female	9831364943	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
30	Ravi Shankar	1983-03-23	Female	9837528084	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
31	Pooja Gupta	2004-03-17	Male	9365648217	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
32	Naresh Naidu	1958-03-29	Female	9670083764	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
33	Sarala Devi	1963-03-28	Female	9388295398	\N				2026-03-12 02:35:04.306367	2026-03-12 02:35:04.306367	\N
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.payments (id, bill_id, amount_paid, payment_mode, reference_no, received_by, paid_at) FROM stdin;
\.


--
-- Data for Name: pharmacy_sale_items; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.pharmacy_sale_items (id, sale_id, medicine_id, medicine_name, quantity, unit_price, total_price) FROM stdin;
\.


--
-- Data for Name: pharmacy_sales; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.pharmacy_sales (id, patient_name, patient_phone, prescription_id, total_amount, discount, net_amount, payment_mode, staff_username, sold_at) FROM stdin;
\.


--
-- Data for Name: pharmacy_stock; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.pharmacy_stock (stock_id, medicine_id, medicine_name, batch_no, expiry_date, quantity, min_quantity, unit_price, sell_price, supplier, updated_at) FROM stdin;
1	3	Paracetamol 500mg	BATCH-P01	2027-12-31	500	50	2.50	5.00	Apollo Pharma	2026-03-10 20:52:54.35179
2	4	Cetirizine 10mg	BATCH-C01	2027-06-30	200	30	3.00	8.00	Sun Pharma	2026-03-10 20:52:54.35179
3	5	Metformin 500mg	BATCH-M01	2026-12-31	300	40	4.00	10.00	Cipla	2026-03-10 20:52:54.35179
4	6	Amoxicillin 250mg	BATCH-A01	2026-09-30	150	25	6.00	15.00	Abbott	2026-03-10 20:52:54.35179
5	7	Amoxicillin 500mg	AMX-2401	2027-09-01	350	50	6.00	14.00	Cipla Ltd	2026-03-10 21:46:12.742946
6	5	Metformin 500mg	MET-2402	2028-02-28	600	100	3.50	8.00	Sun Pharma	2026-03-10 21:46:12.742946
7	8	Amlodipine 5mg	AML-2401	2027-10-31	250	40	5.00	12.00	Dr. Reddy's	2026-03-10 21:46:12.742946
8	9	Omeprazole 20mg	OMP-2401	2027-07-03	400	60	8.00	18.00	Lupin Ltd	2026-03-10 21:46:12.742946
9	10	Azithromycin 250mg	AZT-2403	2027-03-10	180	30	18.00	35.00	Cipla Ltd	2026-03-10 21:46:12.742946
10	11	Pantoprazole 40mg	PAN-2401	2027-04-14	90	50	9.50	22.00	Torrent Pharma	2026-03-10 21:46:12.742946
11	12	Atorvastatin 10mg	ATV-2402	2027-07-23	200	40	12.00	28.00	Ranbaxy	2026-03-10 21:46:12.742946
12	13	Ibuprofen 400mg	IBU-2401	2028-03-09	500	80	4.00	10.00	Intas Pharma	2026-03-10 21:46:12.742946
13	14	Vitamin D3 60k IU	VID-2401	2027-01-04	12	30	25.00	55.00	Abbott India	2026-03-10 21:46:12.742946
14	15	Insulin Glargine 3ml	INS-2401	2026-09-06	5	20	180.00	350.00	Sanofi India	2026-03-10 21:46:12.742946
15	4	Cetirizine 10mg	CTZ-2402	2026-05-09	8	30	3.00	8.00	Sun Pharma	2026-03-10 21:46:12.742946
16	3	Paracetamol 500mg	PCM-2405	2026-04-24	60	50	2.50	5.00	Apollo Pharma	2026-03-10 21:46:12.742946
17	16	Paracetamol 500mg Tablet	BT0016	2027-12-31	200	20	5.00	8.00	Demo Pharma	2026-03-11 00:09:13.870813
18	17	Amoxicillin 250mg Cap	BT0017	2027-12-31	200	20	12.00	18.00	Demo Pharma	2026-03-11 00:09:13.870813
19	18	Pantoprazole 40mg Tab	BT0018	2027-12-31	200	20	8.50	15.00	Demo Pharma	2026-03-11 00:09:13.870813
20	19	Cetirizine 10mg Tab	BT0019	2027-12-31	200	20	3.50	6.00	Demo Pharma	2026-03-11 00:09:13.870813
21	20	Metformin 500mg Tab	BT0020	2027-12-31	200	20	6.00	10.00	Demo Pharma	2026-03-11 00:09:13.870813
22	21	Amlodipine 5mg Tab	BT0021	2027-12-31	200	20	9.00	14.00	Demo Pharma	2026-03-11 00:09:13.870813
23	22	Azithromycin 500mg Tab	BT0022	2027-12-31	200	20	45.00	70.00	Demo Pharma	2026-03-11 00:09:13.870813
24	23	Ibuprofen 400mg Tab	BT0023	2027-12-31	200	20	7.50	12.00	Demo Pharma	2026-03-11 00:09:13.870813
25	24	ORS Sachet	BT0024	2027-12-31	200	20	2.50	5.00	Demo Pharma	2026-03-11 00:09:13.870813
26	25	Vitamin D3 60K Cap	BT0025	2027-12-31	200	20	30.00	50.00	Demo Pharma	2026-03-11 00:09:13.870813
\.


--
-- Data for Name: prescription_items; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.prescription_items (item_id, prescription_id, medicine_name, dosage, frequency, duration, instructions, quantity, created_at, route, med_notes, notes) FROM stdin;
1	1	Paracetamol 500mg	1 tab	TDS	5 days		0	2026-03-10 18:45:01.757103	Oral		
2	2	Paracetamol 500mg	1 tab	TDS	5 days		0	2026-03-10 18:45:56.363502	Oral		
3	3	Paracetamol 500mg	1-0-1		5 days		0	2026-03-10 20:12:54.984781	Oral		
4	3	Cetirizine 10mg	0-0-1		3 days		0	2026-03-10 20:12:54.984781	Oral		
\.


--
-- Data for Name: prescription_medicines; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.prescription_medicines (id, prescription_id, medicine_name, dose, frequency, duration, route, notes, sort_order, created_at) FROM stdin;
1	1	Paracetamol 500mg	1 tab	TDS	5 days	Oral		0	2026-03-10 18:45:01.757103
2	2	Paracetamol 500mg	1 tab	TDS	5 days	Oral		0	2026-03-10 18:45:56.363502
3	3	Paracetamol 500mg	1-0-1		5 days	Oral		0	2026-03-10 20:12:54.984781
4	3	Cetirizine 10mg	0-0-1		3 days	Oral		1	2026-03-10 20:12:54.984781
\.


--
-- Data for Name: prescriptions; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.prescriptions (id, patient_name, patient_phone, doctor_username, doctor_name, diagnosis, medicines, notes, created_at, chief_complaint, symptoms, advice, diet_advice, follow_up_days, visit_id, patient_id, uhid, clinical_notes, bp, temperature, pulse, spo2, weight, special_instructions, follow_up_date, generated_pdf_path, created_by_doctor) FROM stdin;
1	E2E Test 139492	99000139492	star_hospital_doctor	Dr. General Physician	Viral fever	Paracetamol 500mg 1 tab TDS × 5 days		2026-03-10 18:45:01.757103	Fever 3 days			Light diet	5	6	\N			120/80	101	88	97	70		2026-03-15	\N	Dr. General Physician
2	E2E Test 139547	99000139547	star_hospital_doctor	Dr. General Physician	Viral fever	Paracetamol 500mg 1 tab TDS × 5 days		2026-03-10 18:45:56.363502	Fever 3 days			Light diet	5	8	\N			120/80	101	88	97	70		2026-03-15	\N	Dr. General Physician
3	E2E_v62_742620	9000742620	star_hospital_doctor	Dr. General Physician	Viral Fever (E2E test)	   × 5 days;    × 3 days	Rest advised	2026-03-10 20:12:54.984781					\N	\N	\N									\N	\N	Dr. General Physician
\.


--
-- Data for Name: procedure_charges; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.procedure_charges (id, procedure_name, category, default_price, gst_percent, description, is_active, created_at) FROM stdin;
1	OPD Consultation	Consultation	300.00	0.00		t	2026-03-10 18:02:19.00084
2	Specialist Consultation	Consultation	500.00	0.00		t	2026-03-10 18:02:19.00084
3	Dressing / Wound Care	Minor Procedure	200.00	0.00		t	2026-03-10 18:02:19.00084
4	Injection Administration	Minor Procedure	100.00	0.00		t	2026-03-10 18:02:19.00084
5	IV Cannula Insertion	Minor Procedure	150.00	0.00		t	2026-03-10 18:02:19.00084
6	ECG	Diagnostic	300.00	0.00		t	2026-03-10 18:02:19.00084
7	X-Ray Chest PA	Imaging	400.00	0.00		t	2026-03-10 18:02:19.00084
8	Ultrasound Abdomen	Imaging	700.00	0.00		t	2026-03-10 18:02:19.00084
9	MRI Brain	Imaging	4500.00	0.00		t	2026-03-10 18:02:19.00084
10	CT Scan Head	Imaging	3500.00	0.00		t	2026-03-10 18:02:19.00084
11	Complete Blood Count (CBC)	Lab	200.00	0.00		t	2026-03-10 18:02:19.00084
12	Blood Sugar Fasting	Lab	120.00	0.00		t	2026-03-10 18:02:19.00084
13	Urine Routine	Lab	100.00	0.00		t	2026-03-10 18:02:19.00084
14	Lipid Profile	Lab	500.00	0.00		t	2026-03-10 18:02:19.00084
15	Thyroid Profile (T3T4TSH)	Lab	800.00	0.00		t	2026-03-10 18:02:19.00084
16	Appendicectomy	Surgery	18000.00	0.00		t	2026-03-10 18:02:19.00084
17	Caesarean Section	Surgery	35000.00	0.00		t	2026-03-10 18:02:19.00084
18	Hernia Repair	Surgery	22000.00	0.00		t	2026-03-10 18:02:19.00084
19	Cataract Surgery	Surgery	15000.00	0.00		t	2026-03-10 18:02:19.00084
20	LSCS + Tubal Ligation	Surgery	40000.00	0.00		t	2026-03-10 18:02:19.00084
21	General Ward (per day)	Bed Charge	500.00	0.00		t	2026-03-10 18:02:19.00084
22	Semi-Private Ward (per day)	Bed Charge	1200.00	0.00		t	2026-03-10 18:02:19.00084
23	Private Ward (per day)	Bed Charge	2000.00	0.00		t	2026-03-10 18:02:19.00084
24	ICU (per day)	Bed Charge	3500.00	0.00		t	2026-03-10 18:02:19.00084
25	OPD Consultation	Consultation	300.00	0.00		t	2026-03-10 18:12:15.543291
26	Specialist Consultation	Consultation	500.00	0.00		t	2026-03-10 18:12:15.543291
27	Dressing / Wound Care	Minor Procedure	200.00	0.00		t	2026-03-10 18:12:15.543291
28	Injection Administration	Minor Procedure	100.00	0.00		t	2026-03-10 18:12:15.543291
29	IV Cannula Insertion	Minor Procedure	150.00	0.00		t	2026-03-10 18:12:15.543291
30	ECG	Diagnostic	300.00	0.00		t	2026-03-10 18:12:15.543291
31	X-Ray Chest PA	Imaging	400.00	0.00		t	2026-03-10 18:12:15.543291
32	Ultrasound Abdomen	Imaging	700.00	0.00		t	2026-03-10 18:12:15.543291
33	MRI Brain	Imaging	4500.00	0.00		t	2026-03-10 18:12:15.543291
34	CT Scan Head	Imaging	3500.00	0.00		t	2026-03-10 18:12:15.543291
35	Complete Blood Count (CBC)	Lab	200.00	0.00		t	2026-03-10 18:12:15.543291
36	Blood Sugar Fasting	Lab	120.00	0.00		t	2026-03-10 18:12:15.543291
37	Urine Routine	Lab	100.00	0.00		t	2026-03-10 18:12:15.543291
38	Lipid Profile	Lab	500.00	0.00		t	2026-03-10 18:12:15.543291
39	Thyroid Profile (T3T4TSH)	Lab	800.00	0.00		t	2026-03-10 18:12:15.543291
40	Appendicectomy	Surgery	18000.00	0.00		t	2026-03-10 18:12:15.543291
41	Caesarean Section	Surgery	35000.00	0.00		t	2026-03-10 18:12:15.543291
42	Hernia Repair	Surgery	22000.00	0.00		t	2026-03-10 18:12:15.543291
43	Cataract Surgery	Surgery	15000.00	0.00		t	2026-03-10 18:12:15.543291
44	LSCS + Tubal Ligation	Surgery	40000.00	0.00		t	2026-03-10 18:12:15.543291
45	General Ward (per day)	Bed Charge	500.00	0.00		t	2026-03-10 18:12:15.543291
46	Semi-Private Ward (per day)	Bed Charge	1200.00	0.00		t	2026-03-10 18:12:15.543291
47	Private Ward (per day)	Bed Charge	2000.00	0.00		t	2026-03-10 18:12:15.543291
48	ICU (per day)	Bed Charge	3500.00	0.00		t	2026-03-10 18:12:15.543291
\.


--
-- Data for Name: registrations; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.registrations (id, name, age, phone, aadhar, issue, doctor, appointment_time, status, source, created_at) FROM stdin;
1	Rajesh Kumar	35	9876543210		Fever & cold	Dr. Ramya Nadh	10:00 AM	confirmed	demo	2026-03-10 21:38:49.524001
3	Suresh Reddy	52	9100234567		Chest pain	Dr. Anitha Nair	09:00 AM	confirmed	demo	2026-03-10 21:38:49.524001
5	Mohammed Ali	62	9123456780		Knee pain	Dr. Ravi Shankar	03:30 PM	confirmed	demo	2026-03-10 21:38:49.524001
4	Lakshmi Devi	44	9988776655		Regular check	Dr. Kavitha Meena	02:00 PM	confirmed	demo	2026-03-10 21:38:49.524001
2	Priya Sharma	28	9876543211		Ear pain	Dr. Srinivas Rao	11:30 AM	cancelled	demo	2026-03-10 21:38:49.524001
\.


--
-- Data for Name: services_catalogue; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.services_catalogue (service_id, service_name, department, default_price, tax_percentage, active, created_at) FROM stdin;
1	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-10 18:27:56.807317
2	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-10 18:27:56.807317
3	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-10 18:27:56.807317
4	Dental Consultant	Dental	400.00	0.00	t	2026-03-10 18:27:56.807317
5	ENT Consultant	ENT	400.00	0.00	t	2026-03-10 18:27:56.807317
6	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-10 18:27:56.807317
7	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-10 18:27:56.807317
8	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-10 18:27:56.807317
9	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-10 18:27:56.807317
10	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-10 18:27:56.807317
11	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-10 18:33:44.130491
12	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-10 18:33:44.130491
13	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-10 18:33:44.130491
14	Dental Consultant	Dental	400.00	0.00	t	2026-03-10 18:33:44.130491
15	ENT Consultant	ENT	400.00	0.00	t	2026-03-10 18:33:44.130491
16	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-10 18:33:44.130491
17	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-10 18:33:44.130491
18	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-10 18:33:44.130491
19	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-10 18:33:44.130491
20	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-10 18:33:44.130491
21	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-10 18:37:21.233399
22	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-10 18:37:21.233399
23	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-10 18:37:21.233399
24	Dental Consultant	Dental	400.00	0.00	t	2026-03-10 18:37:21.233399
25	ENT Consultant	ENT	400.00	0.00	t	2026-03-10 18:37:21.233399
26	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-10 18:37:21.233399
27	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-10 18:37:21.233399
28	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-10 18:37:21.233399
29	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-10 18:37:21.233399
30	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-10 18:37:21.233399
31	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-10 18:44:40.260616
32	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-10 18:44:40.260616
33	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-10 18:44:40.260616
34	Dental Consultant	Dental	400.00	0.00	t	2026-03-10 18:44:40.260616
35	ENT Consultant	ENT	400.00	0.00	t	2026-03-10 18:44:40.260616
36	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-10 18:44:40.260616
37	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-10 18:44:40.260616
38	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-10 18:44:40.260616
39	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-10 18:44:40.260616
40	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-10 18:44:40.260616
41	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-10 20:03:21.284675
42	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-10 20:03:21.284675
43	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-10 20:03:21.284675
44	Dental Consultant	Dental	400.00	0.00	t	2026-03-10 20:03:21.284675
45	ENT Consultant	ENT	400.00	0.00	t	2026-03-10 20:03:21.284675
46	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-10 20:03:21.284675
47	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-10 20:03:21.284675
48	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-10 20:03:21.284675
49	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-10 20:03:21.284675
50	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-10 20:03:21.284675
51	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-10 21:06:37.492268
52	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-10 21:06:37.492268
53	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-10 21:06:37.492268
54	Dental Consultant	Dental	400.00	0.00	t	2026-03-10 21:06:37.492268
55	ENT Consultant	ENT	400.00	0.00	t	2026-03-10 21:06:37.492268
56	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-10 21:06:37.492268
57	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-10 21:06:37.492268
58	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-10 21:06:37.492268
59	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-10 21:06:37.492268
60	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-10 21:06:37.492268
61	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-10 21:10:53.680283
62	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-10 21:10:53.680283
63	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-10 21:10:53.680283
64	Dental Consultant	Dental	400.00	0.00	t	2026-03-10 21:10:53.680283
65	ENT Consultant	ENT	400.00	0.00	t	2026-03-10 21:10:53.680283
66	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-10 21:10:53.680283
67	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-10 21:10:53.680283
68	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-10 21:10:53.680283
69	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-10 21:10:53.680283
70	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-10 21:10:53.680283
71	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-10 21:39:46.449904
72	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-10 21:39:46.449904
73	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-10 21:39:46.449904
74	Dental Consultant	Dental	400.00	0.00	t	2026-03-10 21:39:46.449904
75	ENT Consultant	ENT	400.00	0.00	t	2026-03-10 21:39:46.449904
76	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-10 21:39:46.449904
77	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-10 21:39:46.449904
78	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-10 21:39:46.449904
79	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-10 21:39:46.449904
80	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-10 21:39:46.449904
81	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-10 21:52:56.863568
82	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-10 21:52:56.863568
83	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-10 21:52:56.863568
84	Dental Consultant	Dental	400.00	0.00	t	2026-03-10 21:52:56.863568
85	ENT Consultant	ENT	400.00	0.00	t	2026-03-10 21:52:56.863568
86	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-10 21:52:56.863568
87	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-10 21:52:56.863568
88	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-10 21:52:56.863568
89	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-10 21:52:56.863568
90	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-10 21:52:56.863568
91	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-10 23:04:33.93017
92	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-10 23:04:33.93017
93	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-10 23:04:33.93017
94	Dental Consultant	Dental	400.00	0.00	t	2026-03-10 23:04:33.93017
95	ENT Consultant	ENT	400.00	0.00	t	2026-03-10 23:04:33.93017
96	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-10 23:04:33.93017
97	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-10 23:04:33.93017
98	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-10 23:04:33.93017
99	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-10 23:04:33.93017
100	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-10 23:04:33.93017
101	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-11 00:15:25.272821
102	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-11 00:15:25.272821
103	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-11 00:15:25.272821
104	Dental Consultant	Dental	400.00	0.00	t	2026-03-11 00:15:25.272821
105	ENT Consultant	ENT	400.00	0.00	t	2026-03-11 00:15:25.272821
106	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-11 00:15:25.272821
107	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-11 00:15:25.272821
108	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-11 00:15:25.272821
109	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-11 00:15:25.272821
110	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-11 00:15:25.272821
111	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-11 00:19:02.057552
112	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-11 00:19:02.057552
113	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-11 00:19:02.057552
114	Dental Consultant	Dental	400.00	0.00	t	2026-03-11 00:19:02.057552
115	ENT Consultant	ENT	400.00	0.00	t	2026-03-11 00:19:02.057552
116	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-11 00:19:02.057552
117	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-11 00:19:02.057552
118	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-11 00:19:02.057552
119	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-11 00:19:02.057552
120	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-11 00:19:02.057552
121	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-11 00:23:58.300278
122	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-11 00:23:58.300278
123	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-11 00:23:58.300278
124	Dental Consultant	Dental	400.00	0.00	t	2026-03-11 00:23:58.300278
125	ENT Consultant	ENT	400.00	0.00	t	2026-03-11 00:23:58.300278
126	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-11 00:23:58.300278
127	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-11 00:23:58.300278
128	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-11 00:23:58.300278
129	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-11 00:23:58.300278
130	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-11 00:23:58.300278
131	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-11 00:32:19.139507
132	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-11 00:32:19.139507
133	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-11 00:32:19.139507
134	Dental Consultant	Dental	400.00	0.00	t	2026-03-11 00:32:19.139507
135	ENT Consultant	ENT	400.00	0.00	t	2026-03-11 00:32:19.139507
136	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-11 00:32:19.139507
137	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-11 00:32:19.139507
138	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-11 00:32:19.139507
139	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-11 00:32:19.139507
140	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-11 00:32:19.139507
141	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-11 07:24:11.377891
142	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-11 07:24:11.377891
143	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-11 07:24:11.377891
144	Dental Consultant	Dental	400.00	0.00	t	2026-03-11 07:24:11.377891
145	ENT Consultant	ENT	400.00	0.00	t	2026-03-11 07:24:11.377891
146	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-11 07:24:11.377891
147	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-11 07:24:11.377891
148	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-11 07:24:11.377891
149	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-11 07:24:11.377891
150	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-11 07:24:11.377891
151	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-11 07:24:31.446197
152	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-11 07:24:31.446197
153	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-11 07:24:31.446197
154	Dental Consultant	Dental	400.00	0.00	t	2026-03-11 07:24:31.446197
155	ENT Consultant	ENT	400.00	0.00	t	2026-03-11 07:24:31.446197
156	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-11 07:24:31.446197
157	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-11 07:24:31.446197
158	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-11 07:24:31.446197
159	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-11 07:24:31.446197
160	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-11 07:24:31.446197
161	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-11 07:35:33.836555
162	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-11 07:35:33.836555
163	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-11 07:35:33.836555
164	Dental Consultant	Dental	400.00	0.00	t	2026-03-11 07:35:33.836555
165	ENT Consultant	ENT	400.00	0.00	t	2026-03-11 07:35:33.836555
166	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-11 07:35:33.836555
167	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-11 07:35:33.836555
168	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-11 07:35:33.836555
169	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-11 07:35:33.836555
170	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-11 07:35:33.836555
171	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-11 08:09:07.196858
172	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-11 08:09:07.196858
173	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-11 08:09:07.196858
174	Dental Consultant	Dental	400.00	0.00	t	2026-03-11 08:09:07.196858
175	ENT Consultant	ENT	400.00	0.00	t	2026-03-11 08:09:07.196858
176	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-11 08:09:07.196858
177	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-11 08:09:07.196858
178	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-11 08:09:07.196858
179	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-11 08:09:07.196858
180	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-11 08:09:07.196858
181	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-11 08:24:40.4604
182	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-11 08:24:40.4604
183	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-11 08:24:40.4604
184	Dental Consultant	Dental	400.00	0.00	t	2026-03-11 08:24:40.4604
185	ENT Consultant	ENT	400.00	0.00	t	2026-03-11 08:24:40.4604
186	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-11 08:24:40.4604
187	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-11 08:24:40.4604
188	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-11 08:24:40.4604
189	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-11 08:24:40.4604
190	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-11 08:24:40.4604
191	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-11 08:32:00.807963
192	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-11 08:32:00.807963
193	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-11 08:32:00.807963
194	Dental Consultant	Dental	400.00	0.00	t	2026-03-11 08:32:00.807963
195	ENT Consultant	ENT	400.00	0.00	t	2026-03-11 08:32:00.807963
196	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-11 08:32:00.807963
197	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-11 08:32:00.807963
198	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-11 08:32:00.807963
199	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-11 08:32:00.807963
200	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-11 08:32:00.807963
201	OPD Consultation â€“ Orthopedics	Orthopedics	500.00	0.00	t	2026-03-11 08:48:45.274486
202	OPD Consultation â€“ General Physician	General Medicine	300.00	0.00	t	2026-03-11 08:48:45.274486
203	OPD Consultation â€“ General Surgery	General Surgery	500.00	0.00	t	2026-03-11 08:48:45.274486
204	Dental Consultant	Dental	400.00	0.00	t	2026-03-11 08:48:45.274486
205	ENT Consultant	ENT	400.00	0.00	t	2026-03-11 08:48:45.274486
206	Follow-up Consultation	General Medicine	150.00	0.00	t	2026-03-11 08:48:45.274486
207	Emergency Consultation	Emergency	500.00	0.00	t	2026-03-11 08:48:45.274486
208	Dressing / Wound Care	General Surgery	200.00	0.00	t	2026-03-11 08:48:45.274486
209	Fracture Reduction & Casting	Orthopedics	1500.00	0.00	t	2026-03-11 08:48:45.274486
210	Minor Surgical Procedure	General Surgery	1000.00	0.00	t	2026-03-11 08:48:45.274486
\.


--
-- Data for Name: staff_users; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.staff_users (id, username, password_hash, role, department, full_name, is_active, must_change_password, created_at) FROM stdin;
9	star_hospital_admin	$2b$12$Y/o.QfLoY7pVpDTUYnrYVe7fDMZSP87lfbSvALxK53Xq1YoUI6mMi	ADMIN	Administration	Hospital Administrator	t	f	2026-03-10 08:51:45.374748
10	star_hospital_doctor	$2b$12$z8ErAFChb7APuoYb5SIRD.vL7LWjZhHJ4F4C5H/S38QqF6npCVOt6	DOCTOR	General Medicine	Dr. General Physician	t	f	2026-03-10 08:51:45.374748
11	star_hospital_nurse	$2b$12$bycZ1JDrLNE0QSrWHOfemOiuIbxgRtqRis2v/6KDg0Oq4A1hzOaXq	NURSE	Nursing	Staff Nurse	t	f	2026-03-10 08:51:45.374748
12	star_hospital_lab	$2b$12$cGU5U6uKmMsIiK4CYh0JtOGnmP7Vk/cpxNtsrB.XnbIa.5daSTiVu	LAB	Pathology	Lab Technician	t	f	2026-03-10 08:51:45.374748
13	star_hospital_stock	$2b$12$PlgklCMBuTbwp9lzZqDSyeDqgnkZlrwNrbpxNJbVfFJE7hOHWsM.W	STOCK	Pharmacy	Pharmacy Staff	t	f	2026-03-10 08:51:45.374748
14	star_hospital_reception	$2b$12$lTLAY9kcWUGCHNw2q/0J0uKNseKmfzvbDHQeUVD.7JDy9S00pumh.	RECEPTION	OPD	Receptionist	t	f	2026-03-10 08:51:45.374748
2	founder	$2b$12$vKgpxDNDuCi3hQWbFB9AV.EVQkncMLn59dHV0kbRaKJyS55hNt4RS	FOUNDER	Platform	SRP Technologies Founder	t	f	2026-03-10 07:09:59.422305
\.


--
-- Data for Name: stock; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.stock (id, item_name, category, quantity, unit, min_quantity, updated_at) FROM stdin;
\.


--
-- Data for Name: surgery_records; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.surgery_records (id, admission_id, patient_name, patient_phone, surgeon_name, surgeon_username, surgery_type, anesthesia_type, estimated_cost, negotiated_cost, operation_date, duration_minutes, operation_notes, complications, status, created_by, created_at, updated_at) FROM stdin;
1	\N	Lakshmi Devi	9876543211	Dr. B. Ramachandra Nayak		Appendectomy	General Anaesthesia	18000.00	14500.00	2026-03-10 20:52:54.35179	0	Pre-op: nil by mouth 6hrs. IV antibiotics post-op.		scheduled		2026-03-10 20:52:54.35179	2026-03-10 20:52:54.35179
2	\N	Suresh Kumar	+91 9901000001	Dr. Surgeon	star_hospital_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	star_hospital_admin	2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839
3	\N	Lakshmi Devi	+91 9901000002	Dr. Surgeon	star_hospital_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	star_hospital_admin	2026-03-11 00:04:09.403839	2026-03-11 00:04:09.403839
4	\N	Suresh Kumar	+91 9901000001	Dr. Surgeon	star_hospital_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	star_hospital_admin	2026-03-11 00:09:14.00081	2026-03-11 00:09:14.00081
5	\N	Lakshmi Devi	+91 9901000002	Dr. Surgeon	star_hospital_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	star_hospital_admin	2026-03-11 00:09:14.00081	2026-03-11 00:09:14.00081
6	\N	Suresh Kumar	+91 9901000001	Dr. Surgeon	star_hospital_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	star_hospital_admin	2026-03-11 00:10:54.135292	2026-03-11 00:10:54.135292
7	\N	Lakshmi Devi	+91 9901000002	Dr. Surgeon	star_hospital_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	star_hospital_admin	2026-03-11 00:10:54.135292	2026-03-11 00:10:54.135292
8	\N	Suresh Kumar	+91 9901000001	Dr. Surgeon	star_hospital_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	star_hospital_admin	2026-03-11 00:12:31.614172	2026-03-11 00:12:31.614172
9	\N	Lakshmi Devi	+91 9901000002	Dr. Surgeon	star_hospital_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	star_hospital_admin	2026-03-11 00:12:31.614172	2026-03-11 00:12:31.614172
\.


--
-- Data for Name: system_logs; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.system_logs (id, username, role, action, details, ip_address, logged_at) FROM stdin;
1	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 07:07:10.68192
2	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 07:07:18.128783
3	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 07:07:57.181682
4	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 07:12:28.84251
5	founder	FOUNDER	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 08:52:36.370044
6	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 08:52:37.394131
7	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 08:52:38.091077
8	founder	FOUNDER	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 08:52:38.712074
9	founder	FOUNDER	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 08:52:47.958173
10	founder	FOUNDER	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 08:52:59.574542
11	founder	FOUNDER	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 08:54:19.733249
12	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 09:02:59.525483
13	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 09:03:00.167918
14	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 09:03:06.72515
15	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 09:03:07.257041
16	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 11:56:55.801827
17	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:10:52.881663
18	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:11:04.429098
19	star_hospital_nurse	NURSE	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:11:05.323645
20	star_hospital_lab	LAB	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:11:06.04644
21	star_hospital_stock	STOCK	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:11:06.943062
22	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:11:07.743521
23	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:12:49.60778
24	star_hospital_nurse	NURSE	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:12:50.273485
25	star_hospital_lab	LAB	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:12:50.926677
26	star_hospital_stock	STOCK	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:12:51.66468
27	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:12:52.286723
28	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:13:02.647682
29	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:13:08.588377
30	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:13:14.547552
31	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:13:58.945968
32	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:13:59.563404
33	star_hospital_nurse	NURSE	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:14:00.12563
34	star_hospital_lab	LAB	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:14:00.642727
35	star_hospital_stock	STOCK	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:14:01.209021
36	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:14:01.760004
37	admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:51:39.469127
38	admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:51:44.036029
39	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:51:49.361916
40	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:56:31.945797
41	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:57:22.637061
42	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:59:08.332909
43	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:59:11.525514
44	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:59:15.517354
45	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:59:44.726301
46	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:59:48.570113
47	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:59:52.404861
48	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:59:56.199038
49	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 14:59:59.503712
50	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:00:03.221714
51	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:00:06.553927
52	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:00:36.817951
53	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:00:56.653034
54	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:01:31.341273
55	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:01:35.192078
56	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:01:39.957553
57	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:02:08.817945
58	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:02:11.852345
59	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:02:15.471212
60	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:02:18.75698
61	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:02:22.656356
62	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:02:26.415187
63	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:02:30.245486
64	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:03:36.7113
65	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:03:39.699503
66	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:03:45.07221
67	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:04:13.493227
68	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:04:16.500125
69	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:04:21.464504
70	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:04:25.1056
71	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:04:28.694866
72	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:04:31.760152
73	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:04:34.995809
74	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:06:32.163703
75	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:06:59.033458
76	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:08:37.67802
77	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:08:40.651117
78	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:08:45.379029
79	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:09:13.776141
80	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:09:16.868402
81	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:09:21.771982
82	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:09:25.726381
83	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:09:29.409438
84	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:09:32.668995
85	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:09:36.285491
86	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:10:46.291066
87	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:10:49.570511
88	ghost	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:10:54.045291
89	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:11:13.685044
90	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:11:16.812206
91	ghost	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:11:21.575586
92	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:18:28.43482
93	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:18:32.131081
94	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:18:37.476621
95	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:19:07.148325
96	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:19:10.282646
97	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:19:14.401436
98	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:19:17.497261
99	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:19:21.001759
100	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:19:24.590332
101	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:19:28.015333
102	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:22:37.597228
103	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:22:41.286704
104	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:22:46.821594
105	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:23:16.818263
106	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:23:20.518561
107	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:23:25.258448
108	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:23:28.80415
109	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:23:32.665575
110	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:23:36.20878
111	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:23:40.273496
112	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:00.839236
113	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:04.657485
114	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:08.764097
115	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:39.040258
116	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:42.761433
117	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:47.383577
118	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:50.818283
119	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:54.777638
120	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:28:58.423819
121	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:29:02.003391
122	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:40:11.981623
123	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:40:14.90421
124	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:40:20.124926
125	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:40:51.365468
126	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:40:55.013894
127	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:40:58.717721
128	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:41:01.828236
129	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:41:05.333511
130	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:41:08.301071
131	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:41:11.420048
132	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:46:22.436204
133	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:46:25.720826
134	ghost_user_xyz	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:46:31.144807
135	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:47:02.379826
136	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:47:05.627637
137	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:47:09.326169
138	star_hospital_lab	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:47:12.419848
139	star_hospital_nurse	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:47:15.622105
140	star_hospital_reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:47:18.844116
141	star_hospital_stock	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:47:21.950444
142	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:48:00.80511
143	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 15:48:16.999464
144	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 16:05:27.179317
145	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 16:05:45.295629
146	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 16:07:35.709649
147	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 16:08:20.086926
148	reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:29:59.814803
149	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:30:07.466649
150	reception	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:30:11.642779
151	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:32:39.42664
152	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:32:39.917869
153	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:37:35.670215
154	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:40:25.119005
155	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:40:31.986421
156	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:40:40.866133
157	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:40:45.804066
158	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:41:42.755204
159	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:41:49.619099
160	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:41:58.555095
161	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:42:03.538827
162	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:44:52.913572
163	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:44:59.6546
164	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:45:47.453598
165	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:45:54.259752
166	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:46:05.340574
167	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 18:46:11.053374
168	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:17:50.201663
169	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:28:00.915402
170	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:28:04.908233
171	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:29:06.916271
172	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:29:07.528762
173	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:29:11.089948
174	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:29:20.462423
175	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:30:06.629675
176	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 19:30:36.465985
177	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 20:03:59.38923
178	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 20:12:31.770846
179	star_hospital_reception	RECEPTION	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 20:12:42.251549
180	star_hospital_doctor	DOCTOR	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 20:12:52.81278
181	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 20:42:05.4447
182	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 21:06:59.491999
183	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 21:07:16.141004
184	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 21:07:40.926495
185	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 21:11:05.678073
186	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 21:11:13.049962
187	star_hospital_admin	ADMIN	ipd_discharge	admission_id=2	127.0.0.1	2026-03-10 21:17:13.437334
188	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 21:40:02.177418
189	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 22:24:49.688801
190	founder	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 22:25:10.74596
191	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 22:26:44.804672
192	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:07:29.878803
193	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:19:15.764529
194	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:27:58.948535
195	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:28:03.137049
196	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:32:53.69845
197	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:36:45.431902
198	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:40:38.429321
199	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:41:03.705178
200	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:52:07.897731
201	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=sai_care	127.0.0.1	2026-03-10 23:52:09.313155
202	city_medical_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-10 23:52:10.769689
203	apollo_warangal_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-10 23:52:14.529663
204	green_cross_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=green_cross	127.0.0.1	2026-03-10 23:52:17.542765
205	star_hospital_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:52:22.396741
206	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=sai_care	127.0.0.1	2026-03-10 23:52:27.980733
207	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-10 23:56:32.448709
208	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=sai_care	127.0.0.1	2026-03-10 23:56:33.887003
209	city_medical_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-10 23:56:34.890989
210	city_medical_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-10 23:56:36.009867
211	apollo_warangal_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-10 23:56:37.172341
212	green_cross_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=green_cross	127.0.0.1	2026-03-10 23:56:38.208487
213	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:19:25.167761
214	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:20:58.224384
215	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=sai_care	127.0.0.1	2026-03-11 00:21:41.289301
216	city_medical_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 00:21:45.084386
217	apollo_warangal_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 00:21:48.380873
218	green_cross_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=green_cross	127.0.0.1	2026-03-11 00:21:51.71895
219	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:21:56.25819
220	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=sai_care	127.0.0.1	2026-03-11 00:22:01.85502
221	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=sai_care	127.0.0.1	2026-03-11 00:22:22.383182
222	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:24:15.769032
223	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=sai_care	127.0.0.1	2026-03-11 00:24:59.690866
224	city_medical_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 00:25:02.989607
225	apollo_warangal_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 00:25:06.206964
226	green_cross_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=green_cross	127.0.0.1	2026-03-11 00:25:09.349236
227	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:25:13.960951
228	sai_care_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=sai_care	127.0.0.1	2026-03-11 00:25:19.362587
229	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:33:01.864427
230	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:38:18.205783
231	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:40:30.918801
232	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:43:57.593064
233	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:44:09.429051
234	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 00:47:41.956828
235	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:11:22.199447
236	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:13:40.734541
237	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:17:16.496346
238	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:17:29.412381
239	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:21:05.040304
240	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:21:19.189573
241	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:24:55.076916
242	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:25:09.244983
243	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:28:42.008431
244	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:28:54.649332
245	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:32:28.349018
246	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 06:44:24.235847
247	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 08:25:14.423002
248	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 08:32:52.362254
249	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 08:33:03.281129
250	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 08:49:19.723317
251	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 08:49:26.451483
252	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 08:49:52.924691
253	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 10:36:41.067012
254	star_hospital_doctor	UNKNOWN	login_failed	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 10:54:49.895799
255	star_hospital_admin	ADMIN	login_success	ip=127.0.0.1 tenant=star_hospital	127.0.0.1	2026-03-11 12:10:29.553384
\.


--
-- Data for Name: visit_records; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.visit_records (id, patient_name, patient_phone, doctor_username, doctor_name, department, chief_complaint, examination, diagnosis, treatment_plan, follow_up_date, visit_date, created_at) FROM stdin;
\.


--
-- Data for Name: vitals; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.vitals (id, patient_name, patient_phone, nurse_username, bp, pulse, temperature, spo2, weight, notes, recorded_at) FROM stdin;
\.


--
-- Data for Name: wards; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.wards (id, ward_name, ward_type, total_beds, floor, is_active, created_at) FROM stdin;
1	General Male	General	10	Ground	t	2026-03-10 18:02:19.00084
2	General Female	General	10	Ground	t	2026-03-10 18:02:19.00084
3	Private	Private	5	First	t	2026-03-10 18:02:19.00084
4	ICU	ICU	4	Ground	t	2026-03-10 18:02:19.00084
5	Maternity	Maternity	6	First	t	2026-03-10 18:02:19.00084
6	Paediatrics	Paediatrics	5	Second	t	2026-03-10 18:02:19.00084
\.


--
-- Name: appointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.appointments_id_seq', 53, true);


--
-- Name: attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.attendance_id_seq', 69, true);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 255, true);


--
-- Name: bed_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.bed_assignments_id_seq', 1, false);


--
-- Name: beds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.beds_id_seq', 1, false);


--
-- Name: bill_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.bill_items_id_seq', 1, false);


--
-- Name: billing_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.billing_accounts_id_seq', 1, false);


--
-- Name: billing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.billing_id_seq', 33, true);


--
-- Name: clients_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.clients_client_id_seq', 45, true);


--
-- Name: daily_rounds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.daily_rounds_id_seq', 1, false);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.departments_id_seq', 225, true);


--
-- Name: discharge_summaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.discharge_summaries_id_seq', 1, true);


--
-- Name: doctor_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.doctor_attendance_id_seq', 1, false);


--
-- Name: doctor_notes_note_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.doctor_notes_note_id_seq', 1, false);


--
-- Name: doctor_rounds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.doctor_rounds_id_seq', 1, false);


--
-- Name: doctors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.doctors_id_seq', 11, true);


--
-- Name: hospital_expenses_expense_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.hospital_expenses_expense_id_seq', 12, true);


--
-- Name: imaging_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.imaging_orders_id_seq', 1, false);


--
-- Name: imaging_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.imaging_reports_id_seq', 1, false);


--
-- Name: imaging_tests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.imaging_tests_id_seq', 1, false);


--
-- Name: inventory_stock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.inventory_stock_id_seq', 5, true);


--
-- Name: lab_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.lab_orders_id_seq', 41, true);


--
-- Name: lab_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.lab_reports_id_seq', 3, true);


--
-- Name: lab_results_result_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.lab_results_result_id_seq', 1, false);


--
-- Name: lab_tests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.lab_tests_id_seq', 1, false);


--
-- Name: medicines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.medicines_id_seq', 25, true);


--
-- Name: notification_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.notification_logs_id_seq', 1, false);


--
-- Name: notification_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.notification_settings_id_seq', 47, true);


--
-- Name: notification_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.notification_templates_id_seq', 6, true);


--
-- Name: nurse_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.nurse_assignments_id_seq', 1, false);


--
-- Name: op_tickets_ticket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.op_tickets_ticket_id_seq', 10, true);


--
-- Name: patient_admissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.patient_admissions_id_seq', 13, true);


--
-- Name: patient_visits_visit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.patient_visits_visit_id_seq', 10, true);


--
-- Name: patients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.patients_id_seq', 33, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- Name: pharmacy_sale_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.pharmacy_sale_items_id_seq', 1, false);


--
-- Name: pharmacy_sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.pharmacy_sales_id_seq', 1, false);


--
-- Name: pharmacy_stock_stock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.pharmacy_stock_stock_id_seq', 26, true);


--
-- Name: prescription_items_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.prescription_items_item_id_seq', 4, true);


--
-- Name: prescription_medicines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.prescription_medicines_id_seq', 4, true);


--
-- Name: prescriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.prescriptions_id_seq', 3, true);


--
-- Name: procedure_charges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.procedure_charges_id_seq', 48, true);


--
-- Name: registrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.registrations_id_seq', 5, true);


--
-- Name: services_catalogue_service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.services_catalogue_service_id_seq', 210, true);


--
-- Name: staff_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.staff_users_id_seq', 44, true);


--
-- Name: stock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.stock_id_seq', 1, false);


--
-- Name: surgery_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.surgery_records_id_seq', 9, true);


--
-- Name: system_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.system_logs_id_seq', 255, true);


--
-- Name: visit_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.visit_records_id_seq', 1, false);


--
-- Name: vitals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.vitals_id_seq', 1, false);


--
-- Name: wards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.wards_id_seq', 12, true);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: attendance attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: bed_assignments bed_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bed_assignments
    ADD CONSTRAINT bed_assignments_pkey PRIMARY KEY (id);


--
-- Name: beds beds_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.beds
    ADD CONSTRAINT beds_pkey PRIMARY KEY (id);


--
-- Name: beds beds_ward_id_bed_number_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.beds
    ADD CONSTRAINT beds_ward_id_bed_number_key UNIQUE (ward_id, bed_number);


--
-- Name: bill_items bill_items_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bill_items
    ADD CONSTRAINT bill_items_pkey PRIMARY KEY (id);


--
-- Name: billing_accounts billing_accounts_client_id_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.billing_accounts
    ADD CONSTRAINT billing_accounts_client_id_key UNIQUE (client_id);


--
-- Name: billing_accounts billing_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.billing_accounts
    ADD CONSTRAINT billing_accounts_pkey PRIMARY KEY (id);


--
-- Name: billing billing_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.billing
    ADD CONSTRAINT billing_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (client_id);


--
-- Name: clients clients_slug_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_slug_key UNIQUE (slug);


--
-- Name: daily_rounds daily_rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.daily_rounds
    ADD CONSTRAINT daily_rounds_pkey PRIMARY KEY (id);


--
-- Name: departments departments_name_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_name_key UNIQUE (name);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: discharge_summaries discharge_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.discharge_summaries
    ADD CONSTRAINT discharge_summaries_pkey PRIMARY KEY (id);


--
-- Name: doctor_attendance doctor_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_attendance
    ADD CONSTRAINT doctor_attendance_pkey PRIMARY KEY (id);


--
-- Name: doctor_notes doctor_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_notes
    ADD CONSTRAINT doctor_notes_pkey PRIMARY KEY (note_id);


--
-- Name: doctor_rounds doctor_rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_rounds
    ADD CONSTRAINT doctor_rounds_pkey PRIMARY KEY (id);


--
-- Name: doctors doctors_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_pkey PRIMARY KEY (id);


--
-- Name: hospital_expenses hospital_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.hospital_expenses
    ADD CONSTRAINT hospital_expenses_pkey PRIMARY KEY (expense_id);


--
-- Name: imaging_orders imaging_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_orders
    ADD CONSTRAINT imaging_orders_pkey PRIMARY KEY (id);


--
-- Name: imaging_reports imaging_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_reports
    ADD CONSTRAINT imaging_reports_pkey PRIMARY KEY (id);


--
-- Name: imaging_tests imaging_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_tests
    ADD CONSTRAINT imaging_tests_pkey PRIMARY KEY (id);


--
-- Name: imaging_tests imaging_tests_test_code_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_tests
    ADD CONSTRAINT imaging_tests_test_code_key UNIQUE (test_code);


--
-- Name: inventory_stock inventory_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.inventory_stock
    ADD CONSTRAINT inventory_stock_pkey PRIMARY KEY (id);


--
-- Name: lab_orders lab_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_orders
    ADD CONSTRAINT lab_orders_pkey PRIMARY KEY (id);


--
-- Name: lab_reports lab_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_reports
    ADD CONSTRAINT lab_reports_pkey PRIMARY KEY (id);


--
-- Name: lab_results lab_results_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_results
    ADD CONSTRAINT lab_results_pkey PRIMARY KEY (result_id);


--
-- Name: lab_tests lab_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_tests
    ADD CONSTRAINT lab_tests_pkey PRIMARY KEY (id);


--
-- Name: lab_tests lab_tests_test_code_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_tests
    ADD CONSTRAINT lab_tests_test_code_key UNIQUE (test_code);


--
-- Name: medicines medicines_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.medicines
    ADD CONSTRAINT medicines_pkey PRIMARY KEY (id);


--
-- Name: notification_logs notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_tenant_slug_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_tenant_slug_setting_key_key UNIQUE (tenant_slug, setting_key);


--
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_tenant_slug_template_key_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_tenant_slug_template_key_key UNIQUE (tenant_slug, template_key);


--
-- Name: nurse_assignments nurse_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.nurse_assignments
    ADD CONSTRAINT nurse_assignments_pkey PRIMARY KEY (id);


--
-- Name: op_tickets op_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.op_tickets
    ADD CONSTRAINT op_tickets_pkey PRIMARY KEY (ticket_id);


--
-- Name: op_tickets op_tickets_ticket_no_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.op_tickets
    ADD CONSTRAINT op_tickets_ticket_no_key UNIQUE (ticket_no);


--
-- Name: patient_admissions patient_admissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patient_admissions
    ADD CONSTRAINT patient_admissions_pkey PRIMARY KEY (id);


--
-- Name: patient_visits patient_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patient_visits
    ADD CONSTRAINT patient_visits_pkey PRIMARY KEY (visit_id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: pharmacy_sale_items pharmacy_sale_items_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sale_items
    ADD CONSTRAINT pharmacy_sale_items_pkey PRIMARY KEY (id);


--
-- Name: pharmacy_sales pharmacy_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sales
    ADD CONSTRAINT pharmacy_sales_pkey PRIMARY KEY (id);


--
-- Name: pharmacy_stock pharmacy_stock_medicine_id_batch_no_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_stock
    ADD CONSTRAINT pharmacy_stock_medicine_id_batch_no_key UNIQUE (medicine_id, batch_no);


--
-- Name: pharmacy_stock pharmacy_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_stock
    ADD CONSTRAINT pharmacy_stock_pkey PRIMARY KEY (stock_id);


--
-- Name: prescription_items prescription_items_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_items
    ADD CONSTRAINT prescription_items_pkey PRIMARY KEY (item_id);


--
-- Name: prescription_medicines prescription_medicines_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_medicines
    ADD CONSTRAINT prescription_medicines_pkey PRIMARY KEY (id);


--
-- Name: prescriptions prescriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_pkey PRIMARY KEY (id);


--
-- Name: procedure_charges procedure_charges_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.procedure_charges
    ADD CONSTRAINT procedure_charges_pkey PRIMARY KEY (id);


--
-- Name: registrations registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.registrations
    ADD CONSTRAINT registrations_pkey PRIMARY KEY (id);


--
-- Name: services_catalogue services_catalogue_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.services_catalogue
    ADD CONSTRAINT services_catalogue_pkey PRIMARY KEY (service_id);


--
-- Name: staff_users staff_users_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.staff_users
    ADD CONSTRAINT staff_users_pkey PRIMARY KEY (id);


--
-- Name: staff_users staff_users_username_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.staff_users
    ADD CONSTRAINT staff_users_username_key UNIQUE (username);


--
-- Name: stock stock_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT stock_pkey PRIMARY KEY (id);


--
-- Name: surgery_records surgery_records_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.surgery_records
    ADD CONSTRAINT surgery_records_pkey PRIMARY KEY (id);


--
-- Name: system_logs system_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.system_logs
    ADD CONSTRAINT system_logs_pkey PRIMARY KEY (id);


--
-- Name: visit_records visit_records_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.visit_records
    ADD CONSTRAINT visit_records_pkey PRIMARY KEY (id);


--
-- Name: vitals vitals_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.vitals
    ADD CONSTRAINT vitals_pkey PRIMARY KEY (id);


--
-- Name: wards wards_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.wards
    ADD CONSTRAINT wards_pkey PRIMARY KEY (id);


--
-- Name: wards wards_ward_name_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.wards
    ADD CONSTRAINT wards_ward_name_key UNIQUE (ward_name);


--
-- Name: idx_audit_log_client_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_audit_log_client_id ON public.audit_log USING btree (client_id, created_at DESC);


--
-- Name: idx_audit_log_created_at; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_audit_log_created_at ON public.audit_log USING btree (created_at DESC);


--
-- Name: idx_dn_doctor; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_dn_doctor ON public.doctor_notes USING btree (doctor_username);


--
-- Name: idx_dn_patient_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_dn_patient_id ON public.doctor_notes USING btree (patient_id);


--
-- Name: idx_lo_patient_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_lo_patient_id ON public.lab_orders USING btree (patient_id);


--
-- Name: idx_lo_prescription_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_lo_prescription_id ON public.lab_orders USING btree (prescription_id);


--
-- Name: idx_lo_visit_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_lo_visit_id ON public.lab_orders USING btree (visit_id);


--
-- Name: idx_lr_order_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_lr_order_id ON public.lab_results USING btree (order_id);


--
-- Name: idx_lr_patient_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_lr_patient_id ON public.lab_results USING btree (patient_id);


--
-- Name: idx_nl_created_at; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_nl_created_at ON public.notification_logs USING btree (created_at DESC);


--
-- Name: idx_nl_event; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_nl_event ON public.notification_logs USING btree (event_type);


--
-- Name: idx_nl_tenant; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_nl_tenant ON public.notification_logs USING btree (tenant_slug);


--
-- Name: idx_ns_tenant_key; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_ns_tenant_key ON public.notification_settings USING btree (tenant_slug, setting_key);


--
-- Name: idx_patients_uhid; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE UNIQUE INDEX idx_patients_uhid ON public.patients USING btree (uhid) WHERE (uhid IS NOT NULL);


--
-- Name: idx_pi_prescription; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_pi_prescription ON public.prescription_items USING btree (prescription_id);


--
-- Name: idx_pm_presc_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_pm_presc_id ON public.prescription_medicines USING btree (prescription_id);


--
-- Name: idx_pm_prescription_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_pm_prescription_id ON public.prescription_medicines USING btree (prescription_id);


--
-- Name: idx_presc_doctor_user; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_presc_doctor_user ON public.prescriptions USING btree (doctor_username);


--
-- Name: idx_presc_patient_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_presc_patient_id ON public.prescriptions USING btree (patient_id);


--
-- Name: idx_presc_visit_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_presc_visit_id ON public.prescriptions USING btree (visit_id);


--
-- Name: idx_ps_expiry; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_ps_expiry ON public.pharmacy_stock USING btree (expiry_date);


--
-- Name: idx_ps_medicine_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_ps_medicine_id ON public.pharmacy_stock USING btree (medicine_id);


--
-- Name: idx_pv_patient_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_pv_patient_id ON public.patient_visits USING btree (patient_id);


--
-- Name: idx_pv_visit_date; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_pv_visit_date ON public.patient_visits USING btree (visit_date DESC);


--
-- Name: appointments appointments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE SET NULL;


--
-- Name: bed_assignments bed_assignments_bed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bed_assignments
    ADD CONSTRAINT bed_assignments_bed_id_fkey FOREIGN KEY (bed_id) REFERENCES public.beds(id) ON DELETE SET NULL;


--
-- Name: beds beds_ward_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.beds
    ADD CONSTRAINT beds_ward_id_fkey FOREIGN KEY (ward_id) REFERENCES public.wards(id) ON DELETE CASCADE;


--
-- Name: bill_items bill_items_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bill_items
    ADD CONSTRAINT bill_items_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.billing(id) ON DELETE CASCADE;


--
-- Name: daily_rounds daily_rounds_admission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.daily_rounds
    ADD CONSTRAINT daily_rounds_admission_id_fkey FOREIGN KEY (admission_id) REFERENCES public.patient_admissions(id) ON DELETE CASCADE;


--
-- Name: discharge_summaries discharge_summaries_admission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.discharge_summaries
    ADD CONSTRAINT discharge_summaries_admission_id_fkey FOREIGN KEY (admission_id) REFERENCES public.patient_admissions(id) ON DELETE CASCADE;


--
-- Name: discharge_summaries discharge_summaries_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.discharge_summaries
    ADD CONSTRAINT discharge_summaries_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.billing(id) ON DELETE SET NULL;


--
-- Name: doctor_notes doctor_notes_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_notes
    ADD CONSTRAINT doctor_notes_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: doctor_notes doctor_notes_visit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_notes
    ADD CONSTRAINT doctor_notes_visit_id_fkey FOREIGN KEY (visit_id) REFERENCES public.patient_visits(visit_id) ON DELETE SET NULL;


--
-- Name: discharge_summaries fk_ds_billing; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.discharge_summaries
    ADD CONSTRAINT fk_ds_billing FOREIGN KEY (bill_id) REFERENCES public.billing(id) ON DELETE SET NULL;


--
-- Name: imaging_reports imaging_reports_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_reports
    ADD CONSTRAINT imaging_reports_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.imaging_orders(id) ON DELETE SET NULL;


--
-- Name: inventory_stock inventory_stock_medicine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.inventory_stock
    ADD CONSTRAINT inventory_stock_medicine_id_fkey FOREIGN KEY (medicine_id) REFERENCES public.medicines(id) ON DELETE CASCADE;


--
-- Name: lab_orders lab_orders_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_orders
    ADD CONSTRAINT lab_orders_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE SET NULL;


--
-- Name: lab_orders lab_orders_prescription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_orders
    ADD CONSTRAINT lab_orders_prescription_id_fkey FOREIGN KEY (prescription_id) REFERENCES public.prescriptions(id) ON DELETE SET NULL;


--
-- Name: lab_orders lab_orders_visit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_orders
    ADD CONSTRAINT lab_orders_visit_id_fkey FOREIGN KEY (visit_id) REFERENCES public.patient_visits(visit_id) ON DELETE SET NULL;


--
-- Name: lab_reports lab_reports_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_reports
    ADD CONSTRAINT lab_reports_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.lab_orders(id) ON DELETE SET NULL;


--
-- Name: lab_results lab_results_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_results
    ADD CONSTRAINT lab_results_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.lab_orders(id) ON DELETE SET NULL;


--
-- Name: lab_results lab_results_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_results
    ADD CONSTRAINT lab_results_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE SET NULL;


--
-- Name: op_tickets op_tickets_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.op_tickets
    ADD CONSTRAINT op_tickets_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: op_tickets op_tickets_visit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.op_tickets
    ADD CONSTRAINT op_tickets_visit_id_fkey FOREIGN KEY (visit_id) REFERENCES public.patient_visits(visit_id) ON DELETE SET NULL;


--
-- Name: patient_visits patient_visits_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patient_visits
    ADD CONSTRAINT patient_visits_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: payments payments_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.billing(id) ON DELETE CASCADE;


--
-- Name: pharmacy_sale_items pharmacy_sale_items_medicine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sale_items
    ADD CONSTRAINT pharmacy_sale_items_medicine_id_fkey FOREIGN KEY (medicine_id) REFERENCES public.medicines(id) ON DELETE SET NULL;


--
-- Name: pharmacy_sale_items pharmacy_sale_items_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sale_items
    ADD CONSTRAINT pharmacy_sale_items_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.pharmacy_sales(id) ON DELETE CASCADE;


--
-- Name: pharmacy_sales pharmacy_sales_prescription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sales
    ADD CONSTRAINT pharmacy_sales_prescription_id_fkey FOREIGN KEY (prescription_id) REFERENCES public.prescriptions(id) ON DELETE SET NULL;


--
-- Name: pharmacy_stock pharmacy_stock_medicine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_stock
    ADD CONSTRAINT pharmacy_stock_medicine_id_fkey FOREIGN KEY (medicine_id) REFERENCES public.medicines(id) ON DELETE CASCADE;


--
-- Name: prescription_items prescription_items_prescription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_items
    ADD CONSTRAINT prescription_items_prescription_id_fkey FOREIGN KEY (prescription_id) REFERENCES public.prescriptions(id) ON DELETE CASCADE;


--
-- Name: prescription_medicines prescription_medicines_prescription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_medicines
    ADD CONSTRAINT prescription_medicines_prescription_id_fkey FOREIGN KEY (prescription_id) REFERENCES public.prescriptions(id) ON DELETE CASCADE;


--
-- Name: prescriptions prescriptions_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE SET NULL;


--
-- Name: surgery_records surgery_records_admission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.surgery_records
    ADD CONSTRAINT surgery_records_admission_id_fkey FOREIGN KEY (admission_id) REFERENCES public.patient_admissions(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict wEFKh0iGlqsaaLw4Euju8mL9VyQgyZ3pMtSNJMUDjgIMEiInWl1uTUBkslv4IUq

