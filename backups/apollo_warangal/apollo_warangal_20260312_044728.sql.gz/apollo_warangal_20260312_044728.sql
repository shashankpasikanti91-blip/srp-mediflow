--
-- PostgreSQL database dump
--

\restrict biKlQqeBj4JLaLSsGPnuL2cffa8j08mxocL1ZWvfkoHafCjgSKlvuWYr6tSy2Ig

-- Dumped from database version 17.8
-- Dumped by pg_dump version 17.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointments; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.appointments (
    id integer NOT NULL,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    patient_aadhar character varying(20) DEFAULT ''::character varying,
    age character varying(10) DEFAULT ''::character varying,
    issue text DEFAULT ''::text,
    doctor_name character varying(150) DEFAULT ''::character varying,
    department character varying(100) DEFAULT ''::character varying,
    appointment_date date,
    appointment_time character varying(20) DEFAULT ''::character varying,
    status character varying(30) DEFAULT 'pending'::character varying,
    source character varying(30) DEFAULT 'chatbot'::character varying,
    notes text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.appointments OWNER TO ats_user;

--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.appointments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointments_id_seq OWNER TO ats_user;

--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.appointments_id_seq OWNED BY public.appointments.id;


--
-- Name: attendance; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.attendance (
    id integer NOT NULL,
    staff_name character varying(150) NOT NULL,
    action character varying(20) NOT NULL,
    notes text DEFAULT ''::text,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attendance OWNER TO ats_user;

--
-- Name: attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attendance_id_seq OWNER TO ats_user;

--
-- Name: attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.attendance_id_seq OWNED BY public.attendance.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    client_id integer,
    username character varying(80) DEFAULT 'system'::character varying,
    role character varying(20) DEFAULT ''::character varying,
    action character varying(200) NOT NULL,
    details text DEFAULT ''::text,
    ip_address character varying(45) DEFAULT ''::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_log OWNER TO ats_user;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO ats_user;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: bed_assignments; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.bed_assignments (
    id integer NOT NULL,
    bed_id integer,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    admitted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    discharged_at timestamp without time zone,
    notes text DEFAULT ''::text
);


ALTER TABLE public.bed_assignments OWNER TO ats_user;

--
-- Name: bed_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.bed_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bed_assignments_id_seq OWNER TO ats_user;

--
-- Name: bed_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.bed_assignments_id_seq OWNED BY public.bed_assignments.id;


--
-- Name: beds; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.beds (
    id integer NOT NULL,
    ward_id integer,
    bed_number character varying(20) NOT NULL,
    bed_type character varying(50) DEFAULT 'General'::character varying,
    status character varying(20) DEFAULT 'available'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.beds OWNER TO ats_user;

--
-- Name: beds_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.beds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.beds_id_seq OWNER TO ats_user;

--
-- Name: beds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.beds_id_seq OWNED BY public.beds.id;


--
-- Name: bill_items; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.bill_items (
    id integer NOT NULL,
    bill_id integer,
    item_type character varying(50) DEFAULT 'consultation'::character varying,
    item_name character varying(200) NOT NULL,
    item_price numeric(10,2) DEFAULT 0,
    quantity integer DEFAULT 1,
    actual_price numeric(10,2) DEFAULT 0,
    negotiated_price numeric(10,2) DEFAULT 0,
    tax_percent numeric(5,2) DEFAULT 0,
    tax_amount numeric(10,2) DEFAULT 0,
    total_amount numeric(10,2) DEFAULT 0,
    notes text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.bill_items OWNER TO ats_user;

--
-- Name: bill_items_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.bill_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bill_items_id_seq OWNER TO ats_user;

--
-- Name: bill_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.bill_items_id_seq OWNED BY public.bill_items.id;


--
-- Name: billing; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.billing (
    id integer NOT NULL,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    bill_type character varying(20) DEFAULT 'OPD'::character varying,
    admission_id integer,
    consultation_fee numeric(10,2) DEFAULT 0,
    lab_charges numeric(10,2) DEFAULT 0,
    imaging_charges numeric(10,2) DEFAULT 0,
    pharmacy_charges numeric(10,2) DEFAULT 0,
    bed_charges numeric(10,2) DEFAULT 0,
    surgery_charges numeric(10,2) DEFAULT 0,
    procedure_charges numeric(10,2) DEFAULT 0,
    misc_charges numeric(10,2) DEFAULT 0,
    total_amount numeric(10,2) DEFAULT 0,
    tax_amount numeric(10,2) DEFAULT 0,
    discount numeric(10,2) DEFAULT 0,
    net_amount numeric(10,2) DEFAULT 0,
    status character varying(20) DEFAULT 'unpaid'::character varying,
    notes text DEFAULT ''::text,
    created_by character varying(80),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing OWNER TO ats_user;

--
-- Name: billing_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.billing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.billing_id_seq OWNER TO ats_user;

--
-- Name: billing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.billing_id_seq OWNED BY public.billing.id;


--
-- Name: daily_rounds; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.daily_rounds (
    id integer NOT NULL,
    admission_id integer,
    patient_name character varying(150) NOT NULL,
    doctor_name character varying(150) DEFAULT ''::character varying,
    doctor_username character varying(80) DEFAULT ''::character varying,
    round_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    bp character varying(20) DEFAULT ''::character varying,
    pulse character varying(10) DEFAULT ''::character varying,
    temperature character varying(10) DEFAULT ''::character varying,
    spo2 character varying(10) DEFAULT ''::character varying,
    clinical_notes text DEFAULT ''::text,
    treatment_change text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.daily_rounds OWNER TO ats_user;

--
-- Name: daily_rounds_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.daily_rounds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.daily_rounds_id_seq OWNER TO ats_user;

--
-- Name: daily_rounds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.daily_rounds_id_seq OWNED BY public.daily_rounds.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text DEFAULT ''::text,
    head_doctor character varying(150) DEFAULT ''::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.departments OWNER TO ats_user;

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.departments_id_seq OWNER TO ats_user;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: discharge_summaries; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.discharge_summaries (
    id integer NOT NULL,
    admission_id integer,
    patient_name character varying(150) NOT NULL,
    discharge_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    final_diagnosis text DEFAULT ''::text,
    treatment_given text DEFAULT ''::text,
    discharge_medicines text DEFAULT ''::text,
    follow_up_date date,
    follow_up_notes text DEFAULT ''::text,
    diet_advice text DEFAULT ''::text,
    activity_advice text DEFAULT ''::text,
    doctor_name character varying(150) DEFAULT ''::character varying,
    doctor_username character varying(80) DEFAULT ''::character varying,
    bill_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.discharge_summaries OWNER TO ats_user;

--
-- Name: discharge_summaries_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.discharge_summaries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.discharge_summaries_id_seq OWNER TO ats_user;

--
-- Name: discharge_summaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.discharge_summaries_id_seq OWNED BY public.discharge_summaries.id;


--
-- Name: doctor_attendance; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.doctor_attendance (
    id integer NOT NULL,
    doctor_name character varying(150) NOT NULL,
    action character varying(20) NOT NULL,
    shift character varying(20) DEFAULT 'Morning'::character varying,
    notes text DEFAULT ''::text,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.doctor_attendance OWNER TO ats_user;

--
-- Name: doctor_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.doctor_attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctor_attendance_id_seq OWNER TO ats_user;

--
-- Name: doctor_attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.doctor_attendance_id_seq OWNED BY public.doctor_attendance.id;


--
-- Name: doctor_notes; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.doctor_notes (
    note_id integer NOT NULL,
    patient_id integer,
    visit_id integer,
    doctor_username character varying(80) NOT NULL,
    doctor_name character varying(150) DEFAULT ''::character varying,
    note_type character varying(50) DEFAULT 'clinical'::character varying,
    note_text text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.doctor_notes OWNER TO ats_user;

--
-- Name: doctor_notes_note_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.doctor_notes_note_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctor_notes_note_id_seq OWNER TO ats_user;

--
-- Name: doctor_notes_note_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.doctor_notes_note_id_seq OWNED BY public.doctor_notes.note_id;


--
-- Name: doctor_rounds; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.doctor_rounds (
    id integer NOT NULL,
    doctor_name character varying(150) NOT NULL,
    ward character varying(80) DEFAULT ''::character varying,
    round_time character varying(20) DEFAULT ''::character varying,
    status character varying(20) DEFAULT 'pending'::character varying,
    notes text DEFAULT ''::text,
    scheduled_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone
);


ALTER TABLE public.doctor_rounds OWNER TO ats_user;

--
-- Name: doctor_rounds_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.doctor_rounds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctor_rounds_id_seq OWNER TO ats_user;

--
-- Name: doctor_rounds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.doctor_rounds_id_seq OWNED BY public.doctor_rounds.id;


--
-- Name: doctors; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.doctors (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    department character varying(100) DEFAULT ''::character varying,
    specialization character varying(200) DEFAULT ''::character varying,
    phone character varying(20) DEFAULT ''::character varying,
    status character varying(20) DEFAULT 'available'::character varying,
    on_duty boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.doctors OWNER TO ats_user;

--
-- Name: doctors_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.doctors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctors_id_seq OWNER TO ats_user;

--
-- Name: doctors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.doctors_id_seq OWNED BY public.doctors.id;


--
-- Name: hospital_expenses; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.hospital_expenses (
    expense_id integer NOT NULL,
    expense_date date DEFAULT CURRENT_DATE NOT NULL,
    category character varying(80) NOT NULL,
    sub_category character varying(120) DEFAULT ''::character varying,
    description character varying(300) DEFAULT ''::character varying,
    amount numeric(12,2) DEFAULT 0 NOT NULL,
    payment_mode character varying(40) DEFAULT 'Cash'::character varying,
    vendor character varying(150) DEFAULT ''::character varying,
    invoice_ref character varying(80) DEFAULT ''::character varying,
    recurring boolean DEFAULT false,
    created_by character varying(60) DEFAULT 'admin'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.hospital_expenses OWNER TO ats_user;

--
-- Name: hospital_expenses_expense_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.hospital_expenses_expense_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hospital_expenses_expense_id_seq OWNER TO ats_user;

--
-- Name: hospital_expenses_expense_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.hospital_expenses_expense_id_seq OWNED BY public.hospital_expenses.expense_id;


--
-- Name: imaging_orders; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.imaging_orders (
    id integer NOT NULL,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    doctor_username character varying(80),
    modality character varying(50) DEFAULT 'X-Ray'::character varying,
    body_part character varying(100) DEFAULT ''::character varying,
    clinical_notes text DEFAULT ''::text,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone
);


ALTER TABLE public.imaging_orders OWNER TO ats_user;

--
-- Name: imaging_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.imaging_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.imaging_orders_id_seq OWNER TO ats_user;

--
-- Name: imaging_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.imaging_orders_id_seq OWNED BY public.imaging_orders.id;


--
-- Name: imaging_reports; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.imaging_reports (
    id integer NOT NULL,
    order_id integer,
    patient_name character varying(150),
    modality character varying(50) DEFAULT 'X-Ray'::character varying,
    findings text DEFAULT ''::text,
    impression text DEFAULT ''::text,
    report_file_path text DEFAULT ''::text,
    radiologist character varying(150) DEFAULT ''::character varying,
    reported_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.imaging_reports OWNER TO ats_user;

--
-- Name: imaging_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.imaging_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.imaging_reports_id_seq OWNER TO ats_user;

--
-- Name: imaging_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.imaging_reports_id_seq OWNED BY public.imaging_reports.id;


--
-- Name: imaging_tests; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.imaging_tests (
    id integer NOT NULL,
    test_code character varying(20) NOT NULL,
    test_name character varying(200) NOT NULL,
    modality character varying(50) DEFAULT 'X-Ray'::character varying,
    body_part character varying(100) DEFAULT ''::character varying,
    price numeric(10,2) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.imaging_tests OWNER TO ats_user;

--
-- Name: imaging_tests_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.imaging_tests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.imaging_tests_id_seq OWNER TO ats_user;

--
-- Name: imaging_tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.imaging_tests_id_seq OWNED BY public.imaging_tests.id;


--
-- Name: inventory_stock; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.inventory_stock (
    id integer NOT NULL,
    medicine_id integer,
    batch_no character varying(50) DEFAULT ''::character varying,
    batch_number character varying(50) DEFAULT ''::character varying,
    expiry_date date,
    quantity integer DEFAULT 0,
    min_quantity integer DEFAULT 10,
    purchase_price numeric(10,2) DEFAULT 0,
    sell_price numeric(10,2) DEFAULT 0,
    supplier character varying(150) DEFAULT ''::character varying,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.inventory_stock OWNER TO ats_user;

--
-- Name: inventory_stock_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.inventory_stock_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_stock_id_seq OWNER TO ats_user;

--
-- Name: inventory_stock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.inventory_stock_id_seq OWNED BY public.inventory_stock.id;


--
-- Name: lab_orders; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.lab_orders (
    id integer NOT NULL,
    patient_name character varying(150),
    patient_phone character varying(20) DEFAULT ''::character varying,
    doctor_username character varying(80),
    test_type character varying(30) DEFAULT 'LAB'::character varying,
    test_name character varying(200),
    status character varying(20) DEFAULT 'PENDING'::character varying,
    result_text text DEFAULT ''::text,
    result_file text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone,
    patient_id integer,
    visit_id integer,
    prescription_id integer,
    urgency character varying(20) DEFAULT 'routine'::character varying,
    lab_notes text DEFAULT ''::text
);


ALTER TABLE public.lab_orders OWNER TO ats_user;

--
-- Name: lab_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.lab_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lab_orders_id_seq OWNER TO ats_user;

--
-- Name: lab_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.lab_orders_id_seq OWNED BY public.lab_orders.id;


--
-- Name: lab_reports; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.lab_reports (
    id integer NOT NULL,
    order_id integer,
    patient_name character varying(150),
    patient_phone character varying(20) DEFAULT ''::character varying,
    test_name character varying(200),
    result_text text DEFAULT ''::text,
    result_file_path text DEFAULT ''::text,
    remarks text DEFAULT ''::text,
    lab_username character varying(80),
    reported_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.lab_reports OWNER TO ats_user;

--
-- Name: lab_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.lab_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lab_reports_id_seq OWNER TO ats_user;

--
-- Name: lab_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.lab_reports_id_seq OWNED BY public.lab_reports.id;


--
-- Name: lab_results; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.lab_results (
    result_id integer NOT NULL,
    order_id integer,
    patient_id integer,
    patient_name character varying(150) DEFAULT ''::character varying,
    test_name character varying(200) DEFAULT ''::character varying,
    result_value text DEFAULT ''::text,
    reference_range character varying(100) DEFAULT ''::character varying,
    unit character varying(30) DEFAULT ''::character varying,
    is_abnormal boolean DEFAULT false,
    remarks text DEFAULT ''::text,
    lab_username character varying(80) DEFAULT ''::character varying,
    reported_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.lab_results OWNER TO ats_user;

--
-- Name: lab_results_result_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.lab_results_result_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lab_results_result_id_seq OWNER TO ats_user;

--
-- Name: lab_results_result_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.lab_results_result_id_seq OWNED BY public.lab_results.result_id;


--
-- Name: lab_tests; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.lab_tests (
    id integer NOT NULL,
    test_code character varying(20) NOT NULL,
    test_name character varying(200) NOT NULL,
    category character varying(80) DEFAULT 'Pathology'::character varying,
    normal_range character varying(100) DEFAULT ''::character varying,
    unit character varying(30) DEFAULT ''::character varying,
    price numeric(10,2) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.lab_tests OWNER TO ats_user;

--
-- Name: lab_tests_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.lab_tests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lab_tests_id_seq OWNER TO ats_user;

--
-- Name: lab_tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.lab_tests_id_seq OWNED BY public.lab_tests.id;


--
-- Name: medicines; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.medicines (
    id integer NOT NULL,
    medicine_name character varying(200) NOT NULL,
    generic_name character varying(200) DEFAULT ''::character varying,
    category character varying(80) DEFAULT 'Tablet'::character varying,
    manufacturer character varying(150) DEFAULT ''::character varying,
    unit character varying(30) DEFAULT 'Strip'::character varying,
    unit_price numeric(10,2) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.medicines OWNER TO ats_user;

--
-- Name: medicines_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.medicines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.medicines_id_seq OWNER TO ats_user;

--
-- Name: medicines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.medicines_id_seq OWNED BY public.medicines.id;


--
-- Name: notification_logs; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.notification_logs (
    id integer NOT NULL,
    tenant_slug character varying(80) DEFAULT ''::character varying,
    channel character varying(30) DEFAULT 'telegram'::character varying,
    event_type character varying(80) DEFAULT ''::character varying,
    recipient character varying(150) DEFAULT ''::character varying,
    message text DEFAULT ''::text,
    status character varying(20) DEFAULT 'sent'::character varying,
    error_msg text DEFAULT ''::text,
    sent_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_logs OWNER TO ats_user;

--
-- Name: notification_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.notification_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_logs_id_seq OWNER TO ats_user;

--
-- Name: notification_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.notification_logs_id_seq OWNED BY public.notification_logs.id;


--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.notification_settings (
    id integer NOT NULL,
    tenant_slug character varying(80) NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value text DEFAULT ''::text,
    updated_by character varying(80) DEFAULT 'system'::character varying,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_settings OWNER TO ats_user;

--
-- Name: notification_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.notification_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_settings_id_seq OWNER TO ats_user;

--
-- Name: notification_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.notification_settings_id_seq OWNED BY public.notification_settings.id;


--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.notification_templates (
    id integer NOT NULL,
    tenant_slug character varying(80) DEFAULT 'default'::character varying,
    event_type character varying(80) NOT NULL,
    channel character varying(30) DEFAULT 'telegram'::character varying,
    template text NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_templates OWNER TO ats_user;

--
-- Name: notification_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.notification_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_templates_id_seq OWNER TO ats_user;

--
-- Name: notification_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.notification_templates_id_seq OWNED BY public.notification_templates.id;


--
-- Name: nurse_assignments; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.nurse_assignments (
    id integer NOT NULL,
    nurse_username character varying(80) NOT NULL,
    patient_name character varying(150),
    patient_phone character varying(20) DEFAULT ''::character varying,
    ward character varying(80) DEFAULT ''::character varying,
    bed_number character varying(20) DEFAULT ''::character varying,
    shift character varying(20) DEFAULT 'Morning'::character varying,
    assigned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    discharged_at timestamp without time zone
);


ALTER TABLE public.nurse_assignments OWNER TO ats_user;

--
-- Name: nurse_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.nurse_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nurse_assignments_id_seq OWNER TO ats_user;

--
-- Name: nurse_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.nurse_assignments_id_seq OWNED BY public.nurse_assignments.id;


--
-- Name: patient_admissions; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.patient_admissions (
    id integer NOT NULL,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    patient_aadhar character varying(20) DEFAULT ''::character varying,
    age character varying(10) DEFAULT ''::character varying,
    gender character varying(10) DEFAULT 'Unknown'::character varying,
    blood_group character varying(5) DEFAULT ''::character varying,
    address text DEFAULT ''::text,
    admission_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    discharge_date timestamp without time zone,
    ward_name character varying(100) DEFAULT ''::character varying,
    bed_number character varying(20) DEFAULT ''::character varying,
    admitting_doctor character varying(150) DEFAULT ''::character varying,
    department character varying(100) DEFAULT ''::character varying,
    diagnosis text DEFAULT ''::text,
    admission_notes text DEFAULT ''::text,
    status character varying(20) DEFAULT 'admitted'::character varying,
    created_by character varying(80) DEFAULT 'reception'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.patient_admissions OWNER TO ats_user;

--
-- Name: patient_admissions_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.patient_admissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patient_admissions_id_seq OWNER TO ats_user;

--
-- Name: patient_admissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.patient_admissions_id_seq OWNED BY public.patient_admissions.id;


--
-- Name: patient_visits; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.patient_visits (
    visit_id integer NOT NULL,
    patient_id integer,
    visit_type character varying(10) DEFAULT 'OP'::character varying,
    doctor_assigned character varying(150) DEFAULT ''::character varying,
    doctor_username character varying(80) DEFAULT ''::character varying,
    department character varying(100) DEFAULT ''::character varying,
    visit_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    chief_complaint text DEFAULT ''::text,
    diagnosis text DEFAULT ''::text,
    notes text DEFAULT ''::text,
    status character varying(30) DEFAULT 'active'::character varying,
    op_ticket_no character varying(30) DEFAULT ''::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.patient_visits OWNER TO ats_user;

--
-- Name: patients; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.patients (
    id integer NOT NULL,
    full_name character varying(150) NOT NULL,
    dob date,
    gender character varying(10) DEFAULT 'Unknown'::character varying,
    phone character varying(20),
    aadhar character varying(20),
    address text DEFAULT ''::text,
    blood_group character varying(5) DEFAULT ''::character varying,
    allergies text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    uhid character varying(20) DEFAULT NULL::character varying
);


ALTER TABLE public.patients OWNER TO ats_user;

--
-- Name: prescriptions; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.prescriptions (
    id integer NOT NULL,
    patient_name character varying(150),
    patient_phone character varying(20) DEFAULT ''::character varying,
    doctor_username character varying(80),
    doctor_name character varying(150),
    diagnosis text,
    medicines text,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    chief_complaint text DEFAULT ''::text,
    bp character varying(20) DEFAULT ''::character varying,
    pulse character varying(10) DEFAULT ''::character varying,
    spo2 character varying(10) DEFAULT ''::character varying,
    follow_up_days integer,
    patient_id integer,
    visit_id integer,
    uhid character varying(20) DEFAULT ''::character varying,
    created_by_doctor character varying(150) DEFAULT ''::character varying,
    symptoms text DEFAULT ''::text,
    clinical_notes text DEFAULT ''::text,
    temperature character varying(10) DEFAULT ''::character varying,
    weight character varying(10) DEFAULT ''::character varying,
    diet_advice text DEFAULT ''::text,
    special_instructions text DEFAULT ''::text,
    follow_up_date date
);


ALTER TABLE public.prescriptions OWNER TO ats_user;

--
-- Name: patient_timeline; Type: VIEW; Schema: public; Owner: ats_user
--

CREATE VIEW public.patient_timeline AS
 SELECT p.id AS patient_id,
    p.full_name AS patient_name,
    p.uhid,
    'visit'::text AS event_type,
    v.visit_id AS event_id,
    v.visit_date AS event_date,
    v.chief_complaint AS summary,
    v.doctor_assigned AS actor,
    v.status AS event_status
   FROM (public.patients p
     JOIN public.patient_visits v ON ((v.patient_id = p.id)))
UNION ALL
 SELECT p.id AS patient_id,
    p.full_name AS patient_name,
    p.uhid,
    'prescription'::text AS event_type,
    rx.id AS event_id,
    rx.created_at AS event_date,
    rx.diagnosis AS summary,
    rx.doctor_name AS actor,
    'saved'::character varying AS event_status
   FROM (public.patients p
     JOIN public.prescriptions rx ON ((rx.patient_id = p.id)))
UNION ALL
 SELECT p.id AS patient_id,
    p.full_name AS patient_name,
    p.uhid,
    'lab_order'::text AS event_type,
    lo.id AS event_id,
    lo.created_at AS event_date,
    lo.test_name AS summary,
    lo.doctor_username AS actor,
    lo.status AS event_status
   FROM (public.patients p
     JOIN public.lab_orders lo ON ((lo.patient_id = p.id)));


ALTER VIEW public.patient_timeline OWNER TO ats_user;

--
-- Name: patient_visits_visit_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.patient_visits_visit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patient_visits_visit_id_seq OWNER TO ats_user;

--
-- Name: patient_visits_visit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.patient_visits_visit_id_seq OWNED BY public.patient_visits.visit_id;


--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.patients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patients_id_seq OWNER TO ats_user;

--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.patients_id_seq OWNED BY public.patients.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    bill_id integer,
    amount_paid numeric(10,2) DEFAULT 0,
    payment_mode character varying(30) DEFAULT 'Cash'::character varying,
    reference_no character varying(100) DEFAULT ''::character varying,
    received_by character varying(80),
    paid_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.payments OWNER TO ats_user;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO ats_user;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: pharmacy_sale_items; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.pharmacy_sale_items (
    id integer NOT NULL,
    sale_id integer,
    medicine_id integer,
    medicine_name character varying(200),
    quantity integer DEFAULT 1,
    unit_price numeric(10,2) DEFAULT 0,
    total_price numeric(10,2) DEFAULT 0
);


ALTER TABLE public.pharmacy_sale_items OWNER TO ats_user;

--
-- Name: pharmacy_sale_items_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.pharmacy_sale_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pharmacy_sale_items_id_seq OWNER TO ats_user;

--
-- Name: pharmacy_sale_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.pharmacy_sale_items_id_seq OWNED BY public.pharmacy_sale_items.id;


--
-- Name: pharmacy_sales; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.pharmacy_sales (
    id integer NOT NULL,
    patient_name character varying(150) DEFAULT 'Walk-in'::character varying,
    patient_phone character varying(20) DEFAULT ''::character varying,
    prescription_id integer,
    total_amount numeric(10,2) DEFAULT 0,
    discount numeric(10,2) DEFAULT 0,
    net_amount numeric(10,2) DEFAULT 0,
    payment_mode character varying(30) DEFAULT 'Cash'::character varying,
    staff_username character varying(80),
    sold_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.pharmacy_sales OWNER TO ats_user;

--
-- Name: pharmacy_sales_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.pharmacy_sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pharmacy_sales_id_seq OWNER TO ats_user;

--
-- Name: pharmacy_sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.pharmacy_sales_id_seq OWNED BY public.pharmacy_sales.id;


--
-- Name: prescription_items; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.prescription_items (
    item_id integer NOT NULL,
    prescription_id integer,
    medicine_name character varying(200) NOT NULL,
    dosage character varying(100) DEFAULT ''::character varying,
    frequency character varying(100) DEFAULT ''::character varying,
    duration character varying(50) DEFAULT ''::character varying,
    instructions text DEFAULT ''::text,
    quantity integer DEFAULT 0,
    route character varying(80) DEFAULT 'Oral'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.prescription_items OWNER TO ats_user;

--
-- Name: prescription_items_item_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.prescription_items_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prescription_items_item_id_seq OWNER TO ats_user;

--
-- Name: prescription_items_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.prescription_items_item_id_seq OWNED BY public.prescription_items.item_id;


--
-- Name: prescription_medicines; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.prescription_medicines (
    id integer NOT NULL,
    prescription_id integer NOT NULL,
    medicine_name character varying(200) NOT NULL,
    dose character varying(100) DEFAULT ''::character varying,
    frequency character varying(100) DEFAULT ''::character varying,
    duration character varying(50) DEFAULT ''::character varying,
    route character varying(80) DEFAULT 'Oral'::character varying,
    notes text DEFAULT ''::text,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.prescription_medicines OWNER TO ats_user;

--
-- Name: prescription_medicines_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.prescription_medicines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prescription_medicines_id_seq OWNER TO ats_user;

--
-- Name: prescription_medicines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.prescription_medicines_id_seq OWNED BY public.prescription_medicines.id;


--
-- Name: prescriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.prescriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prescriptions_id_seq OWNER TO ats_user;

--
-- Name: prescriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.prescriptions_id_seq OWNED BY public.prescriptions.id;


--
-- Name: procedure_charges; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.procedure_charges (
    id integer NOT NULL,
    procedure_name character varying(200) NOT NULL,
    category character varying(80) DEFAULT 'General'::character varying,
    default_price numeric(10,2) DEFAULT 0,
    gst_percent numeric(5,2) DEFAULT 0,
    description text DEFAULT ''::text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.procedure_charges OWNER TO ats_user;

--
-- Name: procedure_charges_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.procedure_charges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procedure_charges_id_seq OWNER TO ats_user;

--
-- Name: procedure_charges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.procedure_charges_id_seq OWNED BY public.procedure_charges.id;


--
-- Name: registrations; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.registrations (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    age character varying(10) DEFAULT ''::character varying,
    phone character varying(20) DEFAULT ''::character varying,
    aadhar character varying(20) DEFAULT ''::character varying,
    issue text DEFAULT ''::text,
    doctor character varying(150) DEFAULT ''::character varying,
    appointment_time character varying(50) DEFAULT ''::character varying,
    status character varying(20) DEFAULT 'pending'::character varying,
    source character varying(30) DEFAULT 'chatbot'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.registrations OWNER TO ats_user;

--
-- Name: registrations_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.registrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.registrations_id_seq OWNER TO ats_user;

--
-- Name: registrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.registrations_id_seq OWNED BY public.registrations.id;


--
-- Name: services_catalogue; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.services_catalogue (
    service_id integer NOT NULL,
    service_name character varying(200) NOT NULL,
    department character varying(100) DEFAULT ''::character varying,
    default_price numeric(10,2) DEFAULT 0,
    tax_percentage numeric(5,2) DEFAULT 0,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.services_catalogue OWNER TO ats_user;

--
-- Name: services_catalogue_service_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.services_catalogue_service_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.services_catalogue_service_id_seq OWNER TO ats_user;

--
-- Name: services_catalogue_service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.services_catalogue_service_id_seq OWNED BY public.services_catalogue.service_id;


--
-- Name: staff_users; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.staff_users (
    id integer NOT NULL,
    username character varying(80) NOT NULL,
    password_hash text NOT NULL,
    role character varying(20) DEFAULT 'RECEPTION'::character varying NOT NULL,
    department character varying(100) DEFAULT ''::character varying,
    full_name character varying(150) DEFAULT ''::character varying,
    is_active boolean DEFAULT true,
    must_change_password boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.staff_users OWNER TO ats_user;

--
-- Name: staff_users_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.staff_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.staff_users_id_seq OWNER TO ats_user;

--
-- Name: staff_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.staff_users_id_seq OWNED BY public.staff_users.id;


--
-- Name: surgery_records; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.surgery_records (
    id integer NOT NULL,
    admission_id integer,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    surgeon_name character varying(150) DEFAULT ''::character varying,
    surgeon_username character varying(80) DEFAULT ''::character varying,
    surgery_type character varying(200) NOT NULL,
    anesthesia_type character varying(100) DEFAULT 'General'::character varying,
    estimated_cost numeric(10,2) DEFAULT 0,
    negotiated_cost numeric(10,2) DEFAULT 0,
    operation_date timestamp without time zone,
    duration_minutes integer DEFAULT 0,
    operation_notes text DEFAULT ''::text,
    complications text DEFAULT ''::text,
    status character varying(30) DEFAULT 'scheduled'::character varying,
    created_by character varying(80) DEFAULT ''::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.surgery_records OWNER TO ats_user;

--
-- Name: surgery_records_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.surgery_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.surgery_records_id_seq OWNER TO ats_user;

--
-- Name: surgery_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.surgery_records_id_seq OWNED BY public.surgery_records.id;


--
-- Name: system_logs; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.system_logs (
    id integer NOT NULL,
    username character varying(80) DEFAULT 'system'::character varying,
    role character varying(20) DEFAULT ''::character varying,
    action character varying(200) NOT NULL,
    details text DEFAULT ''::text,
    ip_address character varying(45) DEFAULT ''::character varying,
    logged_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_logs OWNER TO ats_user;

--
-- Name: system_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.system_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_logs_id_seq OWNER TO ats_user;

--
-- Name: system_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.system_logs_id_seq OWNED BY public.system_logs.id;


--
-- Name: visit_records; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.visit_records (
    id integer NOT NULL,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    doctor_username character varying(80),
    doctor_name character varying(150) DEFAULT ''::character varying,
    department character varying(100) DEFAULT ''::character varying,
    chief_complaint text DEFAULT ''::text,
    examination text DEFAULT ''::text,
    diagnosis text DEFAULT ''::text,
    treatment_plan text DEFAULT ''::text,
    follow_up_date date,
    visit_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.visit_records OWNER TO ats_user;

--
-- Name: visit_records_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.visit_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.visit_records_id_seq OWNER TO ats_user;

--
-- Name: visit_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.visit_records_id_seq OWNED BY public.visit_records.id;


--
-- Name: vitals; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.vitals (
    id integer NOT NULL,
    patient_name character varying(150),
    patient_phone character varying(20) DEFAULT ''::character varying,
    nurse_username character varying(80),
    bp character varying(20) DEFAULT ''::character varying,
    pulse character varying(10) DEFAULT ''::character varying,
    temperature character varying(10) DEFAULT ''::character varying,
    spo2 character varying(10) DEFAULT ''::character varying,
    weight character varying(10) DEFAULT ''::character varying,
    notes text DEFAULT ''::text,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.vitals OWNER TO ats_user;

--
-- Name: vitals_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.vitals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vitals_id_seq OWNER TO ats_user;

--
-- Name: vitals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.vitals_id_seq OWNED BY public.vitals.id;


--
-- Name: wards; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.wards (
    id integer NOT NULL,
    ward_name character varying(100) NOT NULL,
    ward_type character varying(50) DEFAULT 'General'::character varying,
    total_beds integer DEFAULT 0,
    floor character varying(20) DEFAULT 'Ground'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.wards OWNER TO ats_user;

--
-- Name: wards_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.wards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wards_id_seq OWNER TO ats_user;

--
-- Name: wards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.wards_id_seq OWNED BY public.wards.id;


--
-- Name: appointments id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.appointments ALTER COLUMN id SET DEFAULT nextval('public.appointments_id_seq'::regclass);


--
-- Name: attendance id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.attendance ALTER COLUMN id SET DEFAULT nextval('public.attendance_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: bed_assignments id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bed_assignments ALTER COLUMN id SET DEFAULT nextval('public.bed_assignments_id_seq'::regclass);


--
-- Name: beds id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.beds ALTER COLUMN id SET DEFAULT nextval('public.beds_id_seq'::regclass);


--
-- Name: bill_items id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bill_items ALTER COLUMN id SET DEFAULT nextval('public.bill_items_id_seq'::regclass);


--
-- Name: billing id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.billing ALTER COLUMN id SET DEFAULT nextval('public.billing_id_seq'::regclass);


--
-- Name: daily_rounds id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.daily_rounds ALTER COLUMN id SET DEFAULT nextval('public.daily_rounds_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: discharge_summaries id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.discharge_summaries ALTER COLUMN id SET DEFAULT nextval('public.discharge_summaries_id_seq'::regclass);


--
-- Name: doctor_attendance id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_attendance ALTER COLUMN id SET DEFAULT nextval('public.doctor_attendance_id_seq'::regclass);


--
-- Name: doctor_notes note_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_notes ALTER COLUMN note_id SET DEFAULT nextval('public.doctor_notes_note_id_seq'::regclass);


--
-- Name: doctor_rounds id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_rounds ALTER COLUMN id SET DEFAULT nextval('public.doctor_rounds_id_seq'::regclass);


--
-- Name: doctors id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctors ALTER COLUMN id SET DEFAULT nextval('public.doctors_id_seq'::regclass);


--
-- Name: hospital_expenses expense_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.hospital_expenses ALTER COLUMN expense_id SET DEFAULT nextval('public.hospital_expenses_expense_id_seq'::regclass);


--
-- Name: imaging_orders id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_orders ALTER COLUMN id SET DEFAULT nextval('public.imaging_orders_id_seq'::regclass);


--
-- Name: imaging_reports id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_reports ALTER COLUMN id SET DEFAULT nextval('public.imaging_reports_id_seq'::regclass);


--
-- Name: imaging_tests id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_tests ALTER COLUMN id SET DEFAULT nextval('public.imaging_tests_id_seq'::regclass);


--
-- Name: inventory_stock id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.inventory_stock ALTER COLUMN id SET DEFAULT nextval('public.inventory_stock_id_seq'::regclass);


--
-- Name: lab_orders id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_orders ALTER COLUMN id SET DEFAULT nextval('public.lab_orders_id_seq'::regclass);


--
-- Name: lab_reports id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_reports ALTER COLUMN id SET DEFAULT nextval('public.lab_reports_id_seq'::regclass);


--
-- Name: lab_results result_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_results ALTER COLUMN result_id SET DEFAULT nextval('public.lab_results_result_id_seq'::regclass);


--
-- Name: lab_tests id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_tests ALTER COLUMN id SET DEFAULT nextval('public.lab_tests_id_seq'::regclass);


--
-- Name: medicines id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.medicines ALTER COLUMN id SET DEFAULT nextval('public.medicines_id_seq'::regclass);


--
-- Name: notification_logs id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_logs ALTER COLUMN id SET DEFAULT nextval('public.notification_logs_id_seq'::regclass);


--
-- Name: notification_settings id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_settings ALTER COLUMN id SET DEFAULT nextval('public.notification_settings_id_seq'::regclass);


--
-- Name: notification_templates id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_templates ALTER COLUMN id SET DEFAULT nextval('public.notification_templates_id_seq'::regclass);


--
-- Name: nurse_assignments id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.nurse_assignments ALTER COLUMN id SET DEFAULT nextval('public.nurse_assignments_id_seq'::regclass);


--
-- Name: patient_admissions id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patient_admissions ALTER COLUMN id SET DEFAULT nextval('public.patient_admissions_id_seq'::regclass);


--
-- Name: patient_visits visit_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patient_visits ALTER COLUMN visit_id SET DEFAULT nextval('public.patient_visits_visit_id_seq'::regclass);


--
-- Name: patients id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patients ALTER COLUMN id SET DEFAULT nextval('public.patients_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: pharmacy_sale_items id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sale_items ALTER COLUMN id SET DEFAULT nextval('public.pharmacy_sale_items_id_seq'::regclass);


--
-- Name: pharmacy_sales id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sales ALTER COLUMN id SET DEFAULT nextval('public.pharmacy_sales_id_seq'::regclass);


--
-- Name: prescription_items item_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_items ALTER COLUMN item_id SET DEFAULT nextval('public.prescription_items_item_id_seq'::regclass);


--
-- Name: prescription_medicines id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_medicines ALTER COLUMN id SET DEFAULT nextval('public.prescription_medicines_id_seq'::regclass);


--
-- Name: prescriptions id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescriptions ALTER COLUMN id SET DEFAULT nextval('public.prescriptions_id_seq'::regclass);


--
-- Name: procedure_charges id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.procedure_charges ALTER COLUMN id SET DEFAULT nextval('public.procedure_charges_id_seq'::regclass);


--
-- Name: registrations id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.registrations ALTER COLUMN id SET DEFAULT nextval('public.registrations_id_seq'::regclass);


--
-- Name: services_catalogue service_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.services_catalogue ALTER COLUMN service_id SET DEFAULT nextval('public.services_catalogue_service_id_seq'::regclass);


--
-- Name: staff_users id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.staff_users ALTER COLUMN id SET DEFAULT nextval('public.staff_users_id_seq'::regclass);


--
-- Name: surgery_records id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.surgery_records ALTER COLUMN id SET DEFAULT nextval('public.surgery_records_id_seq'::regclass);


--
-- Name: system_logs id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.system_logs ALTER COLUMN id SET DEFAULT nextval('public.system_logs_id_seq'::regclass);


--
-- Name: visit_records id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.visit_records ALTER COLUMN id SET DEFAULT nextval('public.visit_records_id_seq'::regclass);


--
-- Name: vitals id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.vitals ALTER COLUMN id SET DEFAULT nextval('public.vitals_id_seq'::regclass);


--
-- Name: wards id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.wards ALTER COLUMN id SET DEFAULT nextval('public.wards_id_seq'::regclass);


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.appointments (id, patient_name, patient_phone, patient_aadhar, age, issue, doctor_name, department, appointment_date, appointment_time, status, source, notes, created_at, updated_at) FROM stdin;
4	Srinivasa Rao	+91 9904000001	400100000001	61	Routine check-up	Dr. Srinivas Rao	General Medicine	2026-03-12	10:00 AM	scheduled	chatbot		2026-03-11 07:23:54.233734	2026-03-11 07:23:54.233734
5	Kavitha Devi	+91 9904000002	400100000002	39	Routine check-up	Dr. Kavya Lakshmi	Gynaecology	2026-03-13	11:00 AM	scheduled	chatbot		2026-03-11 07:23:54.235821	2026-03-11 07:23:54.235821
6	Ramulu	+91 9904000003	400100000003	71	Routine check-up	Dr. Prasad Kumar	Orthopaedics	2026-03-14	12:00 AM	scheduled	chatbot		2026-03-11 07:23:54.236961	2026-03-11 07:23:54.236961
7	Srinivas Yadav	9608035829		41	Fever	Dr. Suresh Reddy		2026-03-08	14:00	pending	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
8	Bhavani	+91 9904000004		65	Fever	Dr. Ravi Kumar		2026-03-12	11:00	pending	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
9	Bhavani	+91 9904000004		47	Skin Rash	Dr. Priya Nair		2026-02-13	11:00	completed	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
10	Mohan Das	9407455412		26	Cough	Dr. Priya Nair		2026-03-04	15:00	completed	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
11	Lakshmi Bai	9478084725		44	Joint Pain	Dr. Ravi Kumar		2026-02-19	12:00	pending	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
12	Bhavani	+91 9904000004		45	Hypertension	Dr. Ravi Kumar		2026-02-26	10:00	completed	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
13	Arun Verma	9422913284		48	Cough	Dr. Priya Nair		2026-02-10	09:00	completed	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
14	Kavitha Nair	9582281372		42	Hypertension	Dr. Suresh Reddy		2026-02-12	15:00	cancelled	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
15	Mohan Das	9407455412		38	Fever	Dr. Ravi Kumar		2026-03-06	11:00	completed	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
16	Ramesh Babu	9914104075		65	Hypertension	Dr. Priya Nair		2026-02-21	13:00	cancelled	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
17	Deepa Singh	9919100680		29	Headache	Dr. Suresh Reddy		2026-02-10	14:00	completed	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
18	Arun Verma	9422913284		32	Hypertension	Dr. Suresh Reddy		2026-02-10	10:00	completed	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
19	Santosh Kumar	+91 9904000005		23	Hypertension	Dr. Anitha Sharma		2026-03-06	09:00	pending	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
20	Santosh Kumar	+91 9904000005		52	Skin Rash	Dr. Anitha Sharma		2026-03-05	12:00	cancelled	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
21	Srinivasa Rao	+91 9904000001		61	Headache	Dr. Ravi Kumar		2026-03-08	09:00	completed	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
22	Sunita Patel	9591741158		37	Diabetes Check	Dr. Suresh Reddy		2026-03-05	11:00	pending	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
23	Meena Kumari	9312111096		55	Joint Pain	Dr. Suresh Reddy		2026-02-18	15:00	completed	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
24	Venkatesh Rao	9152517661		62	Skin Rash	Dr. Suresh Reddy		2026-03-08	10:00	completed	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
25	Meena Kumari	9312111096		34	Back Pain	Dr. Anitha Sharma		2026-03-08	09:00	cancelled	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
26	Ramulu	+91 9904000003		47	Eye Check	Dr. Ravi Kumar		2026-02-25	14:00	cancelled	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
27	Suresh Reddy	9908052358		65	Diabetes Check	Dr. Suresh Reddy		2026-02-24	16:00	cancelled	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
28	Kishore Kumar	9983545068		68	Eye Check	Dr. Ravi Kumar		2026-03-01	09:00	completed	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
29	Lakshmi Bai	9478084725		59	Skin Rash	Dr. Priya Nair		2026-03-12	09:00	cancelled	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
30	Bhavani	+91 9904000004		33	Diabetes Check	Dr. Priya Nair		2026-03-10	09:00	completed	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
31	Suresh Reddy	9908052358		42	Chest Pain	Dr. Priya Nair		2026-02-15	12:00	pending	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
32	Bhavani	+91 9904000004		49	Diabetes Check	Dr. Anitha Sharma		2026-02-26	16:00	pending	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
33	Deepa Singh	9919100680		35	Cough	Dr. Ravi Kumar		2026-02-27	14:00	completed	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
34	Santosh Kumar	+91 9904000005		68	Headache	Dr. Suresh Reddy		2026-02-26	11:00	cancelled	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
35	Anita Devi	9393441188		34	Diabetes Check	Dr. Anitha Sharma		2026-03-12	17:00	cancelled	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
36	Kishore Kumar	9983545068		31	Hypertension	Dr. Anitha Sharma		2026-02-19	14:00	completed	chatbot		2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046
\.


--
-- Data for Name: attendance; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.attendance (id, staff_name, action, notes, recorded_at) FROM stdin;
1	apollo_warangal_admin	check-in	On duty	2026-03-11 00:04:10.179171
2	apollo_warangal_doctor	check-in	On duty	2026-03-11 00:04:10.179171
3	apollo_warangal_nurse	check-in	On duty	2026-03-11 00:04:10.179171
4	apollo_warangal_admin	check-in	On duty	2026-03-11 00:10:54.784967
5	apollo_warangal_doctor	check-in	On duty	2026-03-11 00:10:54.784967
6	apollo_warangal_nurse	check-in	On duty	2026-03-11 00:10:54.784967
7	apollo_warangal_lab	check-in	On duty	2026-03-11 00:10:54.784967
8	apollo_warangal_reception	check-in	On duty	2026-03-11 00:10:54.784967
9	apollo_warangal_admin	check-in	On duty	2026-03-11 00:12:32.242128
10	apollo_warangal_doctor	check-in	On duty	2026-03-11 00:12:32.242128
11	apollo_warangal_nurse	check-in	On duty	2026-03-11 00:12:32.242128
12	apollo_warangal_lab	check-in	On duty	2026-03-11 00:12:32.242128
13	apollo_warangal_reception	check-in	On duty	2026-03-11 00:12:32.242128
14	Sita Devi	check-in	Role: Nurse	2026-03-12 08:43:00
15	Sita Devi	check-out	Role: Nurse	2026-03-12 17:35:00
16	Ramesh Babu	check-in	Role: Receptionist	2026-03-12 09:38:00
17	Ramesh Babu	check-out	Role: Receptionist	2026-03-12 18:08:00
18	Kavitha	check-in	Role: Lab Technician	2026-03-12 09:48:00
19	Kavitha	check-out	Role: Lab Technician	2026-03-12 17:44:00
20	Mohan Kumar	check-in	Role: Pharmacist	2026-03-12 09:53:00
21	Mohan Kumar	check-out	Role: Pharmacist	2026-03-12 17:12:00
22	Priya G	check-in	Role: Nurse	2026-03-12 09:42:00
23	Priya G	check-out	Role: Nurse	2026-03-12 17:00:00
24	Sita Devi	check-in	Role: Nurse	2026-03-11 09:12:00
25	Sita Devi	check-out	Role: Nurse	2026-03-11 18:55:00
26	Ramesh Babu	check-in	Role: Receptionist	2026-03-11 09:09:00
27	Ramesh Babu	check-out	Role: Receptionist	2026-03-11 18:14:00
28	Kavitha	check-in	Role: Lab Technician	2026-03-11 08:51:00
29	Kavitha	check-out	Role: Lab Technician	2026-03-11 17:06:00
30	Mohan Kumar	check-in	Role: Pharmacist	2026-03-11 08:57:00
31	Mohan Kumar	check-out	Role: Pharmacist	2026-03-11 17:20:00
32	Priya G	check-in	Role: Nurse	2026-03-11 08:29:00
33	Priya G	check-out	Role: Nurse	2026-03-11 17:46:00
34	Sita Devi	check-in	Role: Nurse	2026-03-10 09:49:00
35	Sita Devi	check-out	Role: Nurse	2026-03-10 17:29:00
36	Ramesh Babu	check-in	Role: Receptionist	2026-03-10 09:59:00
37	Ramesh Babu	check-out	Role: Receptionist	2026-03-10 17:17:00
38	Kavitha	check-in	Role: Lab Technician	2026-03-10 09:42:00
39	Kavitha	check-out	Role: Lab Technician	2026-03-10 17:52:00
40	Mohan Kumar	check-in	Role: Pharmacist	2026-03-10 08:21:00
41	Mohan Kumar	check-out	Role: Pharmacist	2026-03-10 17:47:00
42	Priya G	check-in	Role: Nurse	2026-03-10 08:41:00
43	Priya G	check-out	Role: Nurse	2026-03-10 17:37:00
44	Sita Devi	check-in	Role: Nurse	2026-03-09 09:50:00
45	Sita Devi	check-out	Role: Nurse	2026-03-09 18:18:00
46	Ramesh Babu	check-in	Role: Receptionist	2026-03-09 08:08:00
47	Ramesh Babu	check-out	Role: Receptionist	2026-03-09 17:24:00
48	Kavitha	check-in	Role: Lab Technician	2026-03-09 09:07:00
49	Kavitha	check-out	Role: Lab Technician	2026-03-09 17:58:00
50	Mohan Kumar	check-in	Role: Pharmacist	2026-03-09 09:23:00
51	Mohan Kumar	check-out	Role: Pharmacist	2026-03-09 17:08:00
52	Priya G	check-in	Role: Nurse	2026-03-09 09:10:00
53	Priya G	check-out	Role: Nurse	2026-03-09 18:36:00
54	Sita Devi	check-in	Role: Nurse	2026-03-08 09:26:00
55	Sita Devi	check-out	Role: Nurse	2026-03-08 17:34:00
56	Ramesh Babu	check-in	Role: Receptionist	2026-03-08 08:22:00
57	Ramesh Babu	check-out	Role: Receptionist	2026-03-08 17:23:00
58	Kavitha	check-in	Role: Lab Technician	2026-03-08 09:14:00
59	Kavitha	check-out	Role: Lab Technician	2026-03-08 18:57:00
60	Mohan Kumar	check-in	Role: Pharmacist	2026-03-08 09:58:00
61	Mohan Kumar	check-out	Role: Pharmacist	2026-03-08 18:38:00
62	Priya G	check-in	Role: Nurse	2026-03-08 09:55:00
63	Priya G	check-out	Role: Nurse	2026-03-08 18:43:00
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.audit_log (id, client_id, username, role, action, details, ip_address, created_at) FROM stdin;
1	\N	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 00:35:19.925364
2	\N	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 00:40:26.794154
3	\N	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 00:42:34.644546
4	\N	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 00:46:15.549816
5	\N	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 06:13:29.62925
6	\N	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 06:15:48.545517
7	\N	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 06:19:36.939042
8	\N	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 06:23:27.288239
9	\N	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 06:27:16.128987
10	\N	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 06:31:01.642125
11	\N	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 07:24:54.978158
12	\N	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 07:30:13.180777
13	\N	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 07:36:26.194408
14	\N	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 08:32:55.726782
15	\N	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 08:49:23.490217
16	\N	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 08:49:56.007236
\.


--
-- Data for Name: bed_assignments; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.bed_assignments (id, bed_id, patient_name, patient_phone, admitted_at, discharged_at, notes) FROM stdin;
\.


--
-- Data for Name: beds; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.beds (id, ward_id, bed_number, bed_type, status, created_at) FROM stdin;
\.


--
-- Data for Name: bill_items; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.bill_items (id, bill_id, item_type, item_name, item_price, quantity, actual_price, negotiated_price, tax_percent, tax_amount, total_amount, notes, created_at) FROM stdin;
\.


--
-- Data for Name: billing; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.billing (id, patient_name, patient_phone, bill_type, admission_id, consultation_fee, lab_charges, imaging_charges, pharmacy_charges, bed_charges, surgery_charges, procedure_charges, misc_charges, total_amount, tax_amount, discount, net_amount, status, notes, created_by, created_at, updated_at) FROM stdin;
15	Srinivasa Rao	+91 9904000001	OPD	\N	500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	500.00	0.00	0.00	500.00	paid		admin	2026-03-11 07:23:54.425639	2026-03-11 07:23:54.425639
16	Kavitha Devi	+91 9904000002	OPD	\N	750.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	750.00	0.00	0.00	750.00	paid		admin	2026-03-11 07:23:54.427608	2026-03-11 07:23:54.427608
17	Ramulu	+91 9904000003	OPD	\N	1000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1000.00	0.00	0.00	1000.00	paid		admin	2026-03-11 07:23:54.428695	2026-03-11 07:23:54.428695
18	Suresh Reddy	9908052358	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1883.00	0.00	0.00	1883.00	paid		\N	2026-02-23 00:00:00	2026-03-12 02:35:05.481046
19	Venkatesh Rao	9152517661	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	4717.00	0.00	0.00	4717.00	paid		\N	2026-02-10 00:00:00	2026-03-12 02:35:05.481046
20	Lakshmi Bai	9478084725	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	2037.00	0.00	0.00	2037.00	partial		\N	2026-02-27 00:00:00	2026-03-12 02:35:05.481046
21	Bhavani	+91 9904000004	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	5142.00	0.00	0.00	5142.00	paid		\N	2026-02-18 00:00:00	2026-03-12 02:35:05.481046
22	Ramulu	+91 9904000003	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	8794.00	0.00	0.00	8794.00	unpaid		\N	2026-02-21 00:00:00	2026-03-12 02:35:05.481046
23	Anita Devi	9393441188	Pharmacy	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	9766.00	0.00	0.00	9766.00	paid		\N	2026-02-16 00:00:00	2026-03-12 02:35:05.481046
24	Venkatesh Rao	9152517661	Pharmacy	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	775.00	0.00	0.00	775.00	partial		\N	2026-02-11 00:00:00	2026-03-12 02:35:05.481046
25	Srinivas Yadav	9608035829	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	8986.00	0.00	0.00	8986.00	partial		\N	2026-03-11 00:00:00	2026-03-12 02:35:05.481046
26	Kavitha Devi	+91 9904000002	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	8738.00	0.00	0.00	8738.00	partial		\N	2026-02-15 00:00:00	2026-03-12 02:35:05.481046
27	Kishore Kumar	9983545068	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1744.00	0.00	0.00	1744.00	paid		\N	2026-03-08 00:00:00	2026-03-12 02:35:05.481046
28	Sunita Patel	9591741158	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	11590.00	0.00	0.00	11590.00	partial		\N	2026-02-16 00:00:00	2026-03-12 02:35:05.481046
29	Sunita Patel	9591741158	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	11908.00	0.00	0.00	11908.00	paid		\N	2026-02-17 00:00:00	2026-03-12 02:35:05.481046
30	Ramesh Babu	9914104075	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	10960.00	0.00	0.00	10960.00	paid		\N	2026-02-10 00:00:00	2026-03-12 02:35:05.481046
31	Mohan Das	9407455412	IPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	6341.00	0.00	0.00	6341.00	paid		\N	2026-02-14 00:00:00	2026-03-12 02:35:05.481046
32	Kavitha Nair	9582281372	Pharmacy	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	9618.00	0.00	0.00	9618.00	unpaid		\N	2026-02-28 00:00:00	2026-03-12 02:35:05.481046
\.


--
-- Data for Name: daily_rounds; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.daily_rounds (id, admission_id, patient_name, doctor_name, doctor_username, round_date, bp, pulse, temperature, spo2, clinical_notes, treatment_change, created_at) FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.departments (id, name, description, head_doctor, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: discharge_summaries; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.discharge_summaries (id, admission_id, patient_name, discharge_date, final_diagnosis, treatment_given, discharge_medicines, follow_up_date, follow_up_notes, diet_advice, activity_advice, doctor_name, doctor_username, bill_id, created_at) FROM stdin;
\.


--
-- Data for Name: doctor_attendance; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.doctor_attendance (id, doctor_name, action, shift, notes, recorded_at) FROM stdin;
\.


--
-- Data for Name: doctor_notes; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.doctor_notes (note_id, patient_id, visit_id, doctor_username, doctor_name, note_type, note_text, created_at) FROM stdin;
\.


--
-- Data for Name: doctor_rounds; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.doctor_rounds (id, doctor_name, ward, round_time, status, notes, scheduled_at, completed_at) FROM stdin;
\.


--
-- Data for Name: doctors; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.doctors (id, name, department, specialization, phone, status, on_duty, created_at) FROM stdin;
4	Dr. Srinivas Rao	General Medicine	MBBS	+91 9800400001	active	t	2026-03-11 07:23:53.898847
5	Dr. Kavya Lakshmi	Gynaecology	MBBS MS	+91 9800400002	active	t	2026-03-11 07:23:53.898847
6	Dr. Prasad Kumar	Orthopaedics	MBBS MS	+91 9800400003	active	t	2026-03-11 07:23:53.898847
7	Dr. Narayana Murthy	ENT	MBBS DLO	+91 9800400004	active	t	2026-03-11 07:23:53.898847
\.


--
-- Data for Name: hospital_expenses; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.hospital_expenses (expense_id, expense_date, category, sub_category, description, amount, payment_mode, vendor, invoice_ref, recurring, created_by, created_at) FROM stdin;
1	2026-03-01	Rent & Premises		Monthly hospital rent	85000.00	Bank Transfer			t	admin	2026-03-12 02:35:05.481046
2	2026-03-01	Staff Salaries		Monthly payroll	320000.00	Bank Transfer			t	admin	2026-03-12 02:35:05.481046
3	2026-03-01	Electricity & Power		Electricity bill - APSPDCL	28000.00	Bank Transfer			t	admin	2026-03-12 02:35:05.481046
4	2026-03-01	Water & Utilities		Municipal water charges	4500.00	Bank Transfer			t	admin	2026-03-12 02:35:05.481046
5	2026-03-01	Internet & Communication		Broadband + CCTV plan	3000.00	Bank Transfer			t	admin	2026-03-12 02:35:05.481046
6	2026-03-01	Medical Equipment		ECG machine EMI	45000.00	Bank Transfer			f	admin	2026-03-12 02:35:05.481046
7	2026-03-01	Medicines & Consumables		Monthly pharmacy stock	38000.00	Bank Transfer			f	admin	2026-03-12 02:35:05.481046
8	2026-03-01	Insurance		Hospital liability insurance	12000.00	Bank Transfer			t	admin	2026-03-12 02:35:05.481046
9	2026-03-01	Maintenance & Repairs		Generator service	8500.00	Bank Transfer			f	admin	2026-03-12 02:35:05.481046
10	2026-03-01	Marketing & Advertising		Google Ads + pamphlets	6000.00	Bank Transfer			f	admin	2026-03-12 02:35:05.481046
11	2026-03-01	Lab Supplies		Lab reagents & consumables	14000.00	Bank Transfer			f	admin	2026-03-12 02:35:05.481046
12	2026-03-01	Housekeeping		Cleaning & sanitisation	9500.00	Bank Transfer			t	admin	2026-03-12 02:35:05.481046
\.


--
-- Data for Name: imaging_orders; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.imaging_orders (id, patient_name, patient_phone, doctor_username, modality, body_part, clinical_notes, status, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: imaging_reports; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.imaging_reports (id, order_id, patient_name, modality, findings, impression, report_file_path, radiologist, reported_at) FROM stdin;
\.


--
-- Data for Name: imaging_tests; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.imaging_tests (id, test_code, test_name, modality, body_part, price, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: inventory_stock; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.inventory_stock (id, medicine_id, batch_no, batch_number, expiry_date, quantity, min_quantity, purchase_price, sell_price, supplier, updated_at) FROM stdin;
\.


--
-- Data for Name: lab_orders; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.lab_orders (id, patient_name, patient_phone, doctor_username, test_type, test_name, status, result_text, result_file, created_at, completed_at, patient_id, visit_id, prescription_id, urgency, lab_notes) FROM stdin;
35	Srinivasa Rao	+91 9904000001	Dr. Srinivas Rao	Pathology	CBC	pending			2026-03-11 07:23:54.62841	\N	\N	\N	\N	routine	
36	Srinivasa Rao	+91 9904000001	Dr. Srinivas Rao	Pathology	LFT	pending			2026-03-11 07:23:54.629654	\N	\N	\N	\N	routine	
37	Kavitha Devi	+91 9904000002	Dr. Kavya Lakshmi	Pathology	CBC	pending			2026-03-11 07:23:54.630533	\N	\N	\N	\N	routine	
38	Kavitha Devi	+91 9904000002	Dr. Kavya Lakshmi	Pathology	LFT	pending			2026-03-11 07:23:54.631417	\N	\N	\N	\N	routine	
\.


--
-- Data for Name: lab_reports; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.lab_reports (id, order_id, patient_name, patient_phone, test_name, result_text, result_file_path, remarks, lab_username, reported_at) FROM stdin;
1	\N	Kavitha Devi	+91 9904000002	Complete Blood Count	Hemoglobin: 13.5 g/dL, WBC: 7200, Platelets: 2.8 lakhs – All Normal			\N	2026-03-12 00:00:00
2	\N	Ramulu	+91 9904000003	Blood Sugar Fasting	FBS: 98 mg/dL – Normal (ref: 70–100)			\N	2026-03-09 00:00:00
3	\N	Kishore Kumar	9983545068	Urine Routine	Colour: Pale yellow, Pus Cells: 2-4, No sugar, No albumin – Normal			\N	2026-03-06 00:00:00
\.


--
-- Data for Name: lab_results; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.lab_results (result_id, order_id, patient_id, patient_name, test_name, result_value, reference_range, unit, is_abnormal, remarks, lab_username, reported_at) FROM stdin;
\.


--
-- Data for Name: lab_tests; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.lab_tests (id, test_code, test_name, category, normal_range, unit, price, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: medicines; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.medicines (id, medicine_name, generic_name, category, manufacturer, unit, unit_price, is_active, created_at) FROM stdin;
21	Apollo-Atorvastatin 10mg	Apollo-Atorvastatin 10mg	Statin	Ranbaxy	Tablet	35.00	t	2026-03-11 07:23:54.038012
22	Apollo-Ramipril 5mg	Apollo-Ramipril 5mg	ACE Inhibitor	Cipla	Tablet	40.00	t	2026-03-11 07:23:54.040979
23	Apollo-Losartan 50mg	Apollo-Losartan 50mg	ARB	Sun Pharma	Tablet	28.00	t	2026-03-11 07:23:54.041957
24	Apollo-Glipizide 5mg	Apollo-Glipizide 5mg	Antidiabetic	Pfizer	Tablet	22.00	t	2026-03-11 07:23:54.043058
25	Apollo-Alendronate 70mg	Apollo-Alendronate 70mg	Bisphosphonate	Merck	Tablet	150.00	t	2026-03-11 07:23:54.043987
\.


--
-- Data for Name: notification_logs; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.notification_logs (id, tenant_slug, channel, event_type, recipient, message, status, error_msg, sent_at) FROM stdin;
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.notification_settings (id, tenant_slug, setting_key, setting_value, updated_by, updated_at) FROM stdin;
1	apollo_warangal	whatsapp_enabled	false	apollo_warangal_admin	2026-03-11 00:04:10.179171
2	apollo_warangal	email_enabled	false	apollo_warangal_admin	2026-03-11 00:04:10.179171
3	apollo_warangal	sms_enabled	false	apollo_warangal_admin	2026-03-11 00:04:10.179171
4	apollo_warangal	notify_on_appointment	true	apollo_warangal_admin	2026-03-11 00:04:10.179171
\.


--
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.notification_templates (id, tenant_slug, event_type, channel, template, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: nurse_assignments; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.nurse_assignments (id, nurse_username, patient_name, patient_phone, ward, bed_number, shift, assigned_at, discharged_at) FROM stdin;
\.


--
-- Data for Name: patient_admissions; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.patient_admissions (id, patient_name, patient_phone, patient_aadhar, age, gender, blood_group, address, admission_date, discharge_date, ward_name, bed_number, admitting_doctor, department, diagnosis, admission_notes, status, created_by, created_at, updated_at) FROM stdin;
1	Srinivasa Rao	+91 9904000001		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	apollo_warangal_doctor	General Medicine	Fever observation		admitted	apollo_warangal_admin	2026-03-11 00:04:10.179171	2026-03-11 00:04:10.179171
2	Kavitha Devi	+91 9904000002		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	apollo_warangal_doctor	General Medicine	Fever observation		admitted	apollo_warangal_admin	2026-03-11 00:04:10.179171	2026-03-11 00:04:10.179171
3	Srinivasa Rao	+91 9904000001		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	apollo_warangal_doctor	General Medicine	Fever observation		admitted	apollo_warangal_admin	2026-03-11 00:10:54.784967	2026-03-11 00:10:54.784967
4	Kavitha Devi	+91 9904000002		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	apollo_warangal_doctor	General Medicine	Fever observation		admitted	apollo_warangal_admin	2026-03-11 00:10:54.784967	2026-03-11 00:10:54.784967
5	Ramulu	+91 9904000003		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	apollo_warangal_doctor	General Medicine	Fever observation		admitted	apollo_warangal_admin	2026-03-11 00:10:54.784967	2026-03-11 00:10:54.784967
6	Srinivasa Rao	+91 9904000001		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	apollo_warangal_doctor	General Medicine	Fever observation		admitted	apollo_warangal_admin	2026-03-11 00:12:32.242128	2026-03-11 00:12:32.242128
7	Kavitha Devi	+91 9904000002		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	apollo_warangal_doctor	General Medicine	Fever observation		admitted	apollo_warangal_admin	2026-03-11 00:12:32.242128	2026-03-11 00:12:32.242128
8	Ramulu	+91 9904000003		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	apollo_warangal_doctor	General Medicine	Fever observation		admitted	apollo_warangal_admin	2026-03-11 00:12:32.242128	2026-03-11 00:12:32.242128
\.


--
-- Data for Name: patient_visits; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.patient_visits (visit_id, patient_id, visit_type, doctor_assigned, doctor_username, department, visit_date, chief_complaint, diagnosis, notes, status, op_ticket_no, created_at) FROM stdin;
\.


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.patients (id, full_name, dob, gender, phone, aadhar, address, blood_group, allergies, created_at, updated_at, uhid) FROM stdin;
12	Srinivasa Rao	1965-11-04	Male	+91 9904000001	400100000001				2026-03-11 07:23:53.967599	2026-03-11 07:23:53.967599	APO001001
13	Kavitha Devi	1987-05-20	Female	+91 9904000002	400100000002				2026-03-11 07:23:53.970727	2026-03-11 07:23:53.970727	APO001002
14	Ramulu	1955-07-30	Male	+91 9904000003	400100000003				2026-03-11 07:23:53.972072	2026-03-11 07:23:53.972072	APO001003
15	Bhavani	1978-09-13	Female	+91 9904000004	400100000004				2026-03-11 07:23:53.972951	2026-03-11 07:23:53.972951	APO001004
16	Santosh Kumar	1992-01-25	Male	+91 9904000005	400100000005				2026-03-11 07:23:53.973878	2026-03-11 07:23:53.973878	APO001005
17	Rajesh Kumar	1991-03-21	Male	9898932618	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
18	Priya Sharma	1992-03-20	Female	9800090545	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
19	Suresh Reddy	1974-03-25	Female	9908052358	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
20	Anita Devi	1986-03-22	Female	9393441188	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
21	Venkatesh Rao	1976-03-24	Male	9152517661	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
22	Lakshmi Bai	1991-03-21	Female	9478084725	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
23	Mohan Das	1986-03-22	Female	9407455412	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
24	Kavitha Nair	1971-03-26	Female	9582281372	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
25	Ramesh Babu	1976-03-24	Male	9914104075	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
26	Sunita Patel	1975-03-25	Female	9591741158	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
27	Arun Verma	1993-03-20	Male	9422913284	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
28	Meena Kumari	1978-03-24	Male	9312111096	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
29	Srinivas Yadav	1954-03-30	Female	9608035829	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
30	Deepa Singh	1969-03-26	Female	9919100680	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
31	Kishore Kumar	1957-03-29	Female	9983545068	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
32	Bhavani Devi	1984-03-22	Male	9691769853	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
33	Ravi Shankar	1981-03-23	Male	9390356558	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
34	Pooja Gupta	1988-03-21	Female	9495996297	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
35	Naresh Naidu	1965-03-27	Male	9576980568	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
36	Sarala Devi	1981-03-23	Male	9350741762	\N				2026-03-12 02:35:05.481046	2026-03-12 02:35:05.481046	\N
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.payments (id, bill_id, amount_paid, payment_mode, reference_no, received_by, paid_at) FROM stdin;
\.


--
-- Data for Name: pharmacy_sale_items; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.pharmacy_sale_items (id, sale_id, medicine_id, medicine_name, quantity, unit_price, total_price) FROM stdin;
\.


--
-- Data for Name: pharmacy_sales; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.pharmacy_sales (id, patient_name, patient_phone, prescription_id, total_amount, discount, net_amount, payment_mode, staff_username, sold_at) FROM stdin;
\.


--
-- Data for Name: prescription_items; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.prescription_items (item_id, prescription_id, medicine_name, dosage, frequency, duration, instructions, quantity, route, created_at) FROM stdin;
\.


--
-- Data for Name: prescription_medicines; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.prescription_medicines (id, prescription_id, medicine_name, dose, frequency, duration, route, notes, sort_order, created_at) FROM stdin;
\.


--
-- Data for Name: prescriptions; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.prescriptions (id, patient_name, patient_phone, doctor_username, doctor_name, diagnosis, medicines, notes, created_at, chief_complaint, bp, pulse, spo2, follow_up_days, patient_id, visit_id, uhid, created_by_doctor, symptoms, clinical_notes, temperature, weight, diet_advice, special_instructions, follow_up_date) FROM stdin;
\.


--
-- Data for Name: procedure_charges; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.procedure_charges (id, procedure_name, category, default_price, gst_percent, description, is_active, created_at) FROM stdin;
1	OPD Consultation	Consultation	300.00	0.00		t	2026-03-10 18:12:19.181767
2	Specialist Consultation	Consultation	500.00	0.00		t	2026-03-10 18:12:19.181767
3	Dressing / Wound Care	Minor Procedure	200.00	0.00		t	2026-03-10 18:12:19.181767
4	Injection Administration	Minor Procedure	100.00	0.00		t	2026-03-10 18:12:19.181767
5	IV Cannula Insertion	Minor Procedure	150.00	0.00		t	2026-03-10 18:12:19.181767
6	ECG	Diagnostic	300.00	0.00		t	2026-03-10 18:12:19.181767
7	X-Ray Chest PA	Imaging	400.00	0.00		t	2026-03-10 18:12:19.181767
8	Ultrasound Abdomen	Imaging	700.00	0.00		t	2026-03-10 18:12:19.181767
9	MRI Brain	Imaging	4500.00	0.00		t	2026-03-10 18:12:19.181767
10	CT Scan Head	Imaging	3500.00	0.00		t	2026-03-10 18:12:19.181767
11	Complete Blood Count (CBC)	Lab	200.00	0.00		t	2026-03-10 18:12:19.181767
12	Blood Sugar Fasting	Lab	120.00	0.00		t	2026-03-10 18:12:19.181767
13	Urine Routine	Lab	100.00	0.00		t	2026-03-10 18:12:19.181767
14	Lipid Profile	Lab	500.00	0.00		t	2026-03-10 18:12:19.181767
15	Thyroid Profile (T3T4TSH)	Lab	800.00	0.00		t	2026-03-10 18:12:19.181767
16	Appendicectomy	Surgery	18000.00	0.00		t	2026-03-10 18:12:19.181767
17	Caesarean Section	Surgery	35000.00	0.00		t	2026-03-10 18:12:19.181767
18	Hernia Repair	Surgery	22000.00	0.00		t	2026-03-10 18:12:19.181767
19	Cataract Surgery	Surgery	15000.00	0.00		t	2026-03-10 18:12:19.181767
20	LSCS + Tubal Ligation	Surgery	40000.00	0.00		t	2026-03-10 18:12:19.181767
21	General Ward (per day)	Bed Charge	500.00	0.00		t	2026-03-10 18:12:19.181767
22	Semi-Private Ward (per day)	Bed Charge	1200.00	0.00		t	2026-03-10 18:12:19.181767
23	Private Ward (per day)	Bed Charge	2000.00	0.00		t	2026-03-10 18:12:19.181767
24	ICU (per day)	Bed Charge	3500.00	0.00		t	2026-03-10 18:12:19.181767
\.


--
-- Data for Name: registrations; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.registrations (id, name, age, phone, aadhar, issue, doctor, appointment_time, status, source, created_at, updated_at) FROM stdin;
1	Srilatha Devi	42	9600333111		Headache	Dr. Narayana	10:30 AM	pending	demo	2026-03-10 22:14:31.99026	2026-03-10 22:14:31.99026
2	Ramesh Babu	60	9600333112		Heart check	Dr. Narayana	01:00 PM	pending	demo	2026-03-10 22:14:31.99026	2026-03-10 22:14:31.99026
3	Pallavi Rao	33	9600333113		Pregnancy scan	Dr. Sudha	04:00 PM	pending	demo	2026-03-10 22:14:31.99026	2026-03-10 22:14:31.99026
\.


--
-- Data for Name: services_catalogue; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.services_catalogue (service_id, service_name, department, default_price, tax_percentage, active, created_at) FROM stdin;
\.


--
-- Data for Name: staff_users; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.staff_users (id, username, password_hash, role, department, full_name, is_active, must_change_password, created_at) FROM stdin;
1	apollo_warangal_admin	$2b$12$Sp7iVdgrdinKTW89ts8rzOXGe7Pelm0LT5Z2jMMSxMQV046U3e8Zm	ADMIN	Administration	Hospital Administrator	t	f	2026-03-10 22:13:52.373558
2	apollo_warangal_doctor	$2b$12$b8v071FkURFQUmG6o9iNLeeVo88Kyjgif7voovEz8eh3sPcavGYpK	DOCTOR	General Medicine	Dr. General Physician	t	f	2026-03-10 22:13:52.373558
3	apollo_warangal_nurse	$2b$12$.pjhzIb7BWh3ugOqx2Wz5uIoAxdCQOYjch3b3rDCTILg.lo4hTjiu	NURSE	Nursing	Staff Nurse	t	f	2026-03-10 22:13:52.373558
4	apollo_warangal_lab	$2b$12$3EAXLtn1CeYoxqsbE.d9AexyKDdIKBsEoXSoJaJ8JGPltqNULJbWm	LAB	Pathology	Lab Technician	t	f	2026-03-10 22:13:52.373558
5	apollo_warangal_stock	$2b$12$HiKPkLSaVaQJ2l2vH5jK9urslUcUyujmOulCfZC/3aMqkZ5l/wwp2	STOCK	Pharmacy	Pharmacy Staff	t	f	2026-03-10 22:13:52.373558
6	apollo_warangal_reception	$2b$12$yXZdrHKLdW6DAknMFGDZZeM9Tr0mM0/sIrMToMP4EPx0xEuM0/.W6	RECEPTION	OPD	Receptionist	t	f	2026-03-10 22:13:52.373558
\.


--
-- Data for Name: surgery_records; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.surgery_records (id, admission_id, patient_name, patient_phone, surgeon_name, surgeon_username, surgery_type, anesthesia_type, estimated_cost, negotiated_cost, operation_date, duration_minutes, operation_notes, complications, status, created_by, created_at, updated_at) FROM stdin;
1	\N	Srilatha Devi	9100003331	Dr. Prasad Naidu		Appendectomy	General	0.00	0.00	2026-03-09 22:51:24.071702	0			completed		2026-03-10 22:51:24.070566	2026-03-10 22:51:24.070566
2	\N	Ramesh Babu	9100003332	Dr. Leela Devi		Knee Arthroscopy	General	0.00	0.00	2026-03-08 22:51:24.077207	0			completed		2026-03-10 22:51:24.070566	2026-03-10 22:51:24.070566
3	\N	Srinivasa Rao	+91 9904000001	Dr. Surgeon	apollo_warangal_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	apollo_warangal_admin	2026-03-11 00:04:10.179171	2026-03-11 00:04:10.179171
4	\N	Kavitha Devi	+91 9904000002	Dr. Surgeon	apollo_warangal_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	apollo_warangal_admin	2026-03-11 00:04:10.179171	2026-03-11 00:04:10.179171
5	\N	Srinivasa Rao	+91 9904000001	Dr. Surgeon	apollo_warangal_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	apollo_warangal_admin	2026-03-11 00:10:54.784967	2026-03-11 00:10:54.784967
6	\N	Kavitha Devi	+91 9904000002	Dr. Surgeon	apollo_warangal_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	apollo_warangal_admin	2026-03-11 00:10:54.784967	2026-03-11 00:10:54.784967
7	\N	Srinivasa Rao	+91 9904000001	Dr. Surgeon	apollo_warangal_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	apollo_warangal_admin	2026-03-11 00:12:32.242128	2026-03-11 00:12:32.242128
8	\N	Kavitha Devi	+91 9904000002	Dr. Surgeon	apollo_warangal_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	apollo_warangal_admin	2026-03-11 00:12:32.242128	2026-03-11 00:12:32.242128
\.


--
-- Data for Name: system_logs; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.system_logs (id, username, role, action, details, ip_address, logged_at) FROM stdin;
1	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 00:35:19.925364
2	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 00:40:26.794154
3	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 00:42:34.644546
4	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 00:46:15.549816
5	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 06:13:29.62925
6	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 06:15:48.545517
7	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 06:19:36.939042
8	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 06:23:27.288239
9	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 06:27:16.128987
10	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 06:31:01.642125
11	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 07:24:54.978158
12	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 07:30:13.180777
13	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 07:36:26.194408
14	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 08:32:55.726782
15	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 08:49:23.490217
16	apollo_warangal_admin	ADMIN	login_success	ip=127.0.0.1 tenant=apollo_warangal	127.0.0.1	2026-03-11 08:49:56.007236
\.


--
-- Data for Name: visit_records; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.visit_records (id, patient_name, patient_phone, doctor_username, doctor_name, department, chief_complaint, examination, diagnosis, treatment_plan, follow_up_date, visit_date, created_at) FROM stdin;
\.


--
-- Data for Name: vitals; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.vitals (id, patient_name, patient_phone, nurse_username, bp, pulse, temperature, spo2, weight, notes, recorded_at) FROM stdin;
\.


--
-- Data for Name: wards; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.wards (id, ward_name, ward_type, total_beds, floor, is_active, created_at) FROM stdin;
1	General Male	General	10	Ground	t	2026-03-10 18:12:19.18442
2	General Female	General	10	Ground	t	2026-03-10 18:12:19.18442
3	Private	Private	5	First	t	2026-03-10 18:12:19.18442
4	ICU	ICU	4	Ground	t	2026-03-10 18:12:19.18442
5	Maternity	Maternity	6	First	t	2026-03-10 18:12:19.18442
6	Paediatrics	Paediatrics	5	Second	t	2026-03-10 18:12:19.18442
\.


--
-- Name: appointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.appointments_id_seq', 36, true);


--
-- Name: attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.attendance_id_seq', 63, true);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 16, true);


--
-- Name: bed_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.bed_assignments_id_seq', 1, false);


--
-- Name: beds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.beds_id_seq', 1, false);


--
-- Name: bill_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.bill_items_id_seq', 1, false);


--
-- Name: billing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.billing_id_seq', 32, true);


--
-- Name: daily_rounds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.daily_rounds_id_seq', 1, false);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.departments_id_seq', 1, false);


--
-- Name: discharge_summaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.discharge_summaries_id_seq', 1, false);


--
-- Name: doctor_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.doctor_attendance_id_seq', 1, false);


--
-- Name: doctor_notes_note_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.doctor_notes_note_id_seq', 1, false);


--
-- Name: doctor_rounds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.doctor_rounds_id_seq', 1, false);


--
-- Name: doctors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.doctors_id_seq', 7, true);


--
-- Name: hospital_expenses_expense_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.hospital_expenses_expense_id_seq', 12, true);


--
-- Name: imaging_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.imaging_orders_id_seq', 1, false);


--
-- Name: imaging_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.imaging_reports_id_seq', 1, false);


--
-- Name: imaging_tests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.imaging_tests_id_seq', 1, false);


--
-- Name: inventory_stock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.inventory_stock_id_seq', 10, true);


--
-- Name: lab_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.lab_orders_id_seq', 38, true);


--
-- Name: lab_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.lab_reports_id_seq', 3, true);


--
-- Name: lab_results_result_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.lab_results_result_id_seq', 1, false);


--
-- Name: lab_tests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.lab_tests_id_seq', 1, false);


--
-- Name: medicines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.medicines_id_seq', 25, true);


--
-- Name: notification_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.notification_logs_id_seq', 1, false);


--
-- Name: notification_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.notification_settings_id_seq', 12, true);


--
-- Name: notification_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.notification_templates_id_seq', 1, false);


--
-- Name: nurse_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.nurse_assignments_id_seq', 1, false);


--
-- Name: patient_admissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.patient_admissions_id_seq', 8, true);


--
-- Name: patient_visits_visit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.patient_visits_visit_id_seq', 1, false);


--
-- Name: patients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.patients_id_seq', 36, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- Name: pharmacy_sale_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.pharmacy_sale_items_id_seq', 1, false);


--
-- Name: pharmacy_sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.pharmacy_sales_id_seq', 1, false);


--
-- Name: prescription_items_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.prescription_items_item_id_seq', 1, false);


--
-- Name: prescription_medicines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.prescription_medicines_id_seq', 1, false);


--
-- Name: prescriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.prescriptions_id_seq', 1, false);


--
-- Name: procedure_charges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.procedure_charges_id_seq', 48, true);


--
-- Name: registrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.registrations_id_seq', 3, true);


--
-- Name: services_catalogue_service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.services_catalogue_service_id_seq', 1, false);


--
-- Name: staff_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.staff_users_id_seq', 30, true);


--
-- Name: surgery_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.surgery_records_id_seq', 8, true);


--
-- Name: system_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.system_logs_id_seq', 16, true);


--
-- Name: visit_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.visit_records_id_seq', 1, false);


--
-- Name: vitals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.vitals_id_seq', 1, false);


--
-- Name: wards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.wards_id_seq', 12, true);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: attendance attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: bed_assignments bed_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bed_assignments
    ADD CONSTRAINT bed_assignments_pkey PRIMARY KEY (id);


--
-- Name: beds beds_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.beds
    ADD CONSTRAINT beds_pkey PRIMARY KEY (id);


--
-- Name: beds beds_ward_id_bed_number_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.beds
    ADD CONSTRAINT beds_ward_id_bed_number_key UNIQUE (ward_id, bed_number);


--
-- Name: bill_items bill_items_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bill_items
    ADD CONSTRAINT bill_items_pkey PRIMARY KEY (id);


--
-- Name: billing billing_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.billing
    ADD CONSTRAINT billing_pkey PRIMARY KEY (id);


--
-- Name: daily_rounds daily_rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.daily_rounds
    ADD CONSTRAINT daily_rounds_pkey PRIMARY KEY (id);


--
-- Name: departments departments_name_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_name_key UNIQUE (name);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: discharge_summaries discharge_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.discharge_summaries
    ADD CONSTRAINT discharge_summaries_pkey PRIMARY KEY (id);


--
-- Name: doctor_attendance doctor_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_attendance
    ADD CONSTRAINT doctor_attendance_pkey PRIMARY KEY (id);


--
-- Name: doctor_notes doctor_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_notes
    ADD CONSTRAINT doctor_notes_pkey PRIMARY KEY (note_id);


--
-- Name: doctor_rounds doctor_rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_rounds
    ADD CONSTRAINT doctor_rounds_pkey PRIMARY KEY (id);


--
-- Name: doctors doctors_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_pkey PRIMARY KEY (id);


--
-- Name: hospital_expenses hospital_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.hospital_expenses
    ADD CONSTRAINT hospital_expenses_pkey PRIMARY KEY (expense_id);


--
-- Name: imaging_orders imaging_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_orders
    ADD CONSTRAINT imaging_orders_pkey PRIMARY KEY (id);


--
-- Name: imaging_reports imaging_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_reports
    ADD CONSTRAINT imaging_reports_pkey PRIMARY KEY (id);


--
-- Name: imaging_tests imaging_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_tests
    ADD CONSTRAINT imaging_tests_pkey PRIMARY KEY (id);


--
-- Name: imaging_tests imaging_tests_test_code_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_tests
    ADD CONSTRAINT imaging_tests_test_code_key UNIQUE (test_code);


--
-- Name: inventory_stock inventory_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.inventory_stock
    ADD CONSTRAINT inventory_stock_pkey PRIMARY KEY (id);


--
-- Name: lab_orders lab_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_orders
    ADD CONSTRAINT lab_orders_pkey PRIMARY KEY (id);


--
-- Name: lab_reports lab_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_reports
    ADD CONSTRAINT lab_reports_pkey PRIMARY KEY (id);


--
-- Name: lab_results lab_results_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_results
    ADD CONSTRAINT lab_results_pkey PRIMARY KEY (result_id);


--
-- Name: lab_tests lab_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_tests
    ADD CONSTRAINT lab_tests_pkey PRIMARY KEY (id);


--
-- Name: lab_tests lab_tests_test_code_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_tests
    ADD CONSTRAINT lab_tests_test_code_key UNIQUE (test_code);


--
-- Name: medicines medicines_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.medicines
    ADD CONSTRAINT medicines_pkey PRIMARY KEY (id);


--
-- Name: notification_logs notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_tenant_slug_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_tenant_slug_setting_key_key UNIQUE (tenant_slug, setting_key);


--
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_tenant_slug_event_type_channel_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_tenant_slug_event_type_channel_key UNIQUE (tenant_slug, event_type, channel);


--
-- Name: nurse_assignments nurse_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.nurse_assignments
    ADD CONSTRAINT nurse_assignments_pkey PRIMARY KEY (id);


--
-- Name: patient_admissions patient_admissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patient_admissions
    ADD CONSTRAINT patient_admissions_pkey PRIMARY KEY (id);


--
-- Name: patient_visits patient_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patient_visits
    ADD CONSTRAINT patient_visits_pkey PRIMARY KEY (visit_id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: pharmacy_sale_items pharmacy_sale_items_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sale_items
    ADD CONSTRAINT pharmacy_sale_items_pkey PRIMARY KEY (id);


--
-- Name: pharmacy_sales pharmacy_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sales
    ADD CONSTRAINT pharmacy_sales_pkey PRIMARY KEY (id);


--
-- Name: prescription_items prescription_items_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_items
    ADD CONSTRAINT prescription_items_pkey PRIMARY KEY (item_id);


--
-- Name: prescription_medicines prescription_medicines_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_medicines
    ADD CONSTRAINT prescription_medicines_pkey PRIMARY KEY (id);


--
-- Name: prescriptions prescriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_pkey PRIMARY KEY (id);


--
-- Name: procedure_charges procedure_charges_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.procedure_charges
    ADD CONSTRAINT procedure_charges_pkey PRIMARY KEY (id);


--
-- Name: registrations registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.registrations
    ADD CONSTRAINT registrations_pkey PRIMARY KEY (id);


--
-- Name: services_catalogue services_catalogue_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.services_catalogue
    ADD CONSTRAINT services_catalogue_pkey PRIMARY KEY (service_id);


--
-- Name: staff_users staff_users_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.staff_users
    ADD CONSTRAINT staff_users_pkey PRIMARY KEY (id);


--
-- Name: staff_users staff_users_username_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.staff_users
    ADD CONSTRAINT staff_users_username_key UNIQUE (username);


--
-- Name: surgery_records surgery_records_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.surgery_records
    ADD CONSTRAINT surgery_records_pkey PRIMARY KEY (id);


--
-- Name: system_logs system_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.system_logs
    ADD CONSTRAINT system_logs_pkey PRIMARY KEY (id);


--
-- Name: visit_records visit_records_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.visit_records
    ADD CONSTRAINT visit_records_pkey PRIMARY KEY (id);


--
-- Name: vitals vitals_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.vitals
    ADD CONSTRAINT vitals_pkey PRIMARY KEY (id);


--
-- Name: wards wards_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.wards
    ADD CONSTRAINT wards_pkey PRIMARY KEY (id);


--
-- Name: wards wards_ward_name_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.wards
    ADD CONSTRAINT wards_ward_name_key UNIQUE (ward_name);


--
-- Name: idx_audit_log_created_at; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_audit_log_created_at ON public.audit_log USING btree (created_at DESC);


--
-- Name: idx_dn_patient_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_dn_patient_id ON public.doctor_notes USING btree (patient_id);


--
-- Name: idx_lr_patient_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_lr_patient_id ON public.lab_results USING btree (patient_id);


--
-- Name: idx_patients_uhid; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE UNIQUE INDEX idx_patients_uhid ON public.patients USING btree (uhid) WHERE (uhid IS NOT NULL);


--
-- Name: idx_pi_prescription; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_pi_prescription ON public.prescription_items USING btree (prescription_id);


--
-- Name: idx_pm_presc_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_pm_presc_id ON public.prescription_medicines USING btree (prescription_id);


--
-- Name: idx_pv_patient_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_pv_patient_id ON public.patient_visits USING btree (patient_id);


--
-- Name: idx_pv_visit_date; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_pv_visit_date ON public.patient_visits USING btree (visit_date DESC);


--
-- Name: bed_assignments bed_assignments_bed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bed_assignments
    ADD CONSTRAINT bed_assignments_bed_id_fkey FOREIGN KEY (bed_id) REFERENCES public.beds(id) ON DELETE SET NULL;


--
-- Name: beds beds_ward_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.beds
    ADD CONSTRAINT beds_ward_id_fkey FOREIGN KEY (ward_id) REFERENCES public.wards(id) ON DELETE CASCADE;


--
-- Name: bill_items bill_items_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bill_items
    ADD CONSTRAINT bill_items_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.billing(id) ON DELETE CASCADE;


--
-- Name: daily_rounds daily_rounds_admission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.daily_rounds
    ADD CONSTRAINT daily_rounds_admission_id_fkey FOREIGN KEY (admission_id) REFERENCES public.patient_admissions(id) ON DELETE CASCADE;


--
-- Name: discharge_summaries discharge_summaries_admission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.discharge_summaries
    ADD CONSTRAINT discharge_summaries_admission_id_fkey FOREIGN KEY (admission_id) REFERENCES public.patient_admissions(id) ON DELETE CASCADE;


--
-- Name: doctor_notes doctor_notes_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_notes
    ADD CONSTRAINT doctor_notes_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: doctor_notes doctor_notes_visit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_notes
    ADD CONSTRAINT doctor_notes_visit_id_fkey FOREIGN KEY (visit_id) REFERENCES public.patient_visits(visit_id) ON DELETE SET NULL;


--
-- Name: discharge_summaries fk_ds_billing; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.discharge_summaries
    ADD CONSTRAINT fk_ds_billing FOREIGN KEY (bill_id) REFERENCES public.billing(id) ON DELETE SET NULL;


--
-- Name: imaging_reports imaging_reports_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_reports
    ADD CONSTRAINT imaging_reports_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.imaging_orders(id) ON DELETE SET NULL;


--
-- Name: inventory_stock inventory_stock_medicine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.inventory_stock
    ADD CONSTRAINT inventory_stock_medicine_id_fkey FOREIGN KEY (medicine_id) REFERENCES public.medicines(id) ON DELETE CASCADE;


--
-- Name: lab_reports lab_reports_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_reports
    ADD CONSTRAINT lab_reports_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.lab_orders(id) ON DELETE SET NULL;


--
-- Name: lab_results lab_results_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_results
    ADD CONSTRAINT lab_results_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.lab_orders(id) ON DELETE SET NULL;


--
-- Name: lab_results lab_results_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_results
    ADD CONSTRAINT lab_results_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE SET NULL;


--
-- Name: patient_visits patient_visits_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patient_visits
    ADD CONSTRAINT patient_visits_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: payments payments_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.billing(id) ON DELETE CASCADE;


--
-- Name: pharmacy_sale_items pharmacy_sale_items_medicine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sale_items
    ADD CONSTRAINT pharmacy_sale_items_medicine_id_fkey FOREIGN KEY (medicine_id) REFERENCES public.medicines(id) ON DELETE SET NULL;


--
-- Name: pharmacy_sale_items pharmacy_sale_items_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sale_items
    ADD CONSTRAINT pharmacy_sale_items_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.pharmacy_sales(id) ON DELETE CASCADE;


--
-- Name: pharmacy_sales pharmacy_sales_prescription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sales
    ADD CONSTRAINT pharmacy_sales_prescription_id_fkey FOREIGN KEY (prescription_id) REFERENCES public.prescriptions(id) ON DELETE SET NULL;


--
-- Name: prescription_items prescription_items_prescription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_items
    ADD CONSTRAINT prescription_items_prescription_id_fkey FOREIGN KEY (prescription_id) REFERENCES public.prescriptions(id) ON DELETE CASCADE;


--
-- Name: prescription_medicines prescription_medicines_prescription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_medicines
    ADD CONSTRAINT prescription_medicines_prescription_id_fkey FOREIGN KEY (prescription_id) REFERENCES public.prescriptions(id) ON DELETE CASCADE;


--
-- Name: surgery_records surgery_records_admission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.surgery_records
    ADD CONSTRAINT surgery_records_admission_id_fkey FOREIGN KEY (admission_id) REFERENCES public.patient_admissions(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict biKlQqeBj4JLaLSsGPnuL2cffa8j08mxocL1ZWvfkoHafCjgSKlvuWYr6tSy2Ig

