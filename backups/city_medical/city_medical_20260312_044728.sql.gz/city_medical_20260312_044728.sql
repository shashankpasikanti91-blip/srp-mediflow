--
-- PostgreSQL database dump
--

\restrict yBaxLgKKZhtPFB2N91MNuLgogbbUm12Pu2kgUClm0Mn5eCPtPztf0Pt7xUFaLaq

-- Dumped from database version 17.8
-- Dumped by pg_dump version 17.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointments; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.appointments (
    id integer NOT NULL,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    patient_aadhar character varying(20) DEFAULT ''::character varying,
    age character varying(10) DEFAULT ''::character varying,
    issue text DEFAULT ''::text,
    doctor_name character varying(150) DEFAULT ''::character varying,
    department character varying(100) DEFAULT ''::character varying,
    appointment_date date,
    appointment_time character varying(20) DEFAULT ''::character varying,
    status character varying(30) DEFAULT 'pending'::character varying,
    source character varying(30) DEFAULT 'chatbot'::character varying,
    notes text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.appointments OWNER TO ats_user;

--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.appointments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointments_id_seq OWNER TO ats_user;

--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.appointments_id_seq OWNED BY public.appointments.id;


--
-- Name: attendance; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.attendance (
    id integer NOT NULL,
    staff_name character varying(150) NOT NULL,
    action character varying(20) NOT NULL,
    notes text DEFAULT ''::text,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attendance OWNER TO ats_user;

--
-- Name: attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attendance_id_seq OWNER TO ats_user;

--
-- Name: attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.attendance_id_seq OWNED BY public.attendance.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    client_id integer,
    username character varying(80) DEFAULT 'system'::character varying,
    role character varying(20) DEFAULT ''::character varying,
    action character varying(200) NOT NULL,
    details text DEFAULT ''::text,
    ip_address character varying(45) DEFAULT ''::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_log OWNER TO ats_user;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO ats_user;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: bed_assignments; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.bed_assignments (
    id integer NOT NULL,
    bed_id integer,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    admitted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    discharged_at timestamp without time zone,
    notes text DEFAULT ''::text
);


ALTER TABLE public.bed_assignments OWNER TO ats_user;

--
-- Name: bed_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.bed_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bed_assignments_id_seq OWNER TO ats_user;

--
-- Name: bed_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.bed_assignments_id_seq OWNED BY public.bed_assignments.id;


--
-- Name: beds; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.beds (
    id integer NOT NULL,
    ward_id integer,
    bed_number character varying(20) NOT NULL,
    bed_type character varying(50) DEFAULT 'General'::character varying,
    status character varying(20) DEFAULT 'available'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.beds OWNER TO ats_user;

--
-- Name: beds_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.beds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.beds_id_seq OWNER TO ats_user;

--
-- Name: beds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.beds_id_seq OWNED BY public.beds.id;


--
-- Name: bill_items; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.bill_items (
    id integer NOT NULL,
    bill_id integer,
    item_type character varying(50) DEFAULT 'consultation'::character varying,
    item_name character varying(200) NOT NULL,
    item_price numeric(10,2) DEFAULT 0,
    quantity integer DEFAULT 1,
    actual_price numeric(10,2) DEFAULT 0,
    negotiated_price numeric(10,2) DEFAULT 0,
    tax_percent numeric(5,2) DEFAULT 0,
    tax_amount numeric(10,2) DEFAULT 0,
    total_amount numeric(10,2) DEFAULT 0,
    notes text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.bill_items OWNER TO ats_user;

--
-- Name: bill_items_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.bill_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bill_items_id_seq OWNER TO ats_user;

--
-- Name: bill_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.bill_items_id_seq OWNED BY public.bill_items.id;


--
-- Name: billing; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.billing (
    id integer NOT NULL,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    bill_type character varying(20) DEFAULT 'OPD'::character varying,
    admission_id integer,
    consultation_fee numeric(10,2) DEFAULT 0,
    lab_charges numeric(10,2) DEFAULT 0,
    imaging_charges numeric(10,2) DEFAULT 0,
    pharmacy_charges numeric(10,2) DEFAULT 0,
    bed_charges numeric(10,2) DEFAULT 0,
    surgery_charges numeric(10,2) DEFAULT 0,
    procedure_charges numeric(10,2) DEFAULT 0,
    misc_charges numeric(10,2) DEFAULT 0,
    total_amount numeric(10,2) DEFAULT 0,
    tax_amount numeric(10,2) DEFAULT 0,
    discount numeric(10,2) DEFAULT 0,
    net_amount numeric(10,2) DEFAULT 0,
    status character varying(20) DEFAULT 'unpaid'::character varying,
    notes text DEFAULT ''::text,
    created_by character varying(80),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing OWNER TO ats_user;

--
-- Name: billing_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.billing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.billing_id_seq OWNER TO ats_user;

--
-- Name: billing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.billing_id_seq OWNED BY public.billing.id;


--
-- Name: daily_rounds; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.daily_rounds (
    id integer NOT NULL,
    admission_id integer,
    patient_name character varying(150) NOT NULL,
    doctor_name character varying(150) DEFAULT ''::character varying,
    doctor_username character varying(80) DEFAULT ''::character varying,
    round_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    bp character varying(20) DEFAULT ''::character varying,
    pulse character varying(10) DEFAULT ''::character varying,
    temperature character varying(10) DEFAULT ''::character varying,
    spo2 character varying(10) DEFAULT ''::character varying,
    clinical_notes text DEFAULT ''::text,
    treatment_change text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.daily_rounds OWNER TO ats_user;

--
-- Name: daily_rounds_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.daily_rounds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.daily_rounds_id_seq OWNER TO ats_user;

--
-- Name: daily_rounds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.daily_rounds_id_seq OWNED BY public.daily_rounds.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text DEFAULT ''::text,
    head_doctor character varying(150) DEFAULT ''::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.departments OWNER TO ats_user;

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.departments_id_seq OWNER TO ats_user;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: discharge_summaries; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.discharge_summaries (
    id integer NOT NULL,
    admission_id integer,
    patient_name character varying(150) NOT NULL,
    discharge_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    final_diagnosis text DEFAULT ''::text,
    treatment_given text DEFAULT ''::text,
    discharge_medicines text DEFAULT ''::text,
    follow_up_date date,
    follow_up_notes text DEFAULT ''::text,
    diet_advice text DEFAULT ''::text,
    activity_advice text DEFAULT ''::text,
    doctor_name character varying(150) DEFAULT ''::character varying,
    doctor_username character varying(80) DEFAULT ''::character varying,
    bill_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.discharge_summaries OWNER TO ats_user;

--
-- Name: discharge_summaries_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.discharge_summaries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.discharge_summaries_id_seq OWNER TO ats_user;

--
-- Name: discharge_summaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.discharge_summaries_id_seq OWNED BY public.discharge_summaries.id;


--
-- Name: doctor_attendance; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.doctor_attendance (
    id integer NOT NULL,
    doctor_name character varying(150) NOT NULL,
    action character varying(20) NOT NULL,
    shift character varying(20) DEFAULT 'Morning'::character varying,
    notes text DEFAULT ''::text,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.doctor_attendance OWNER TO ats_user;

--
-- Name: doctor_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.doctor_attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctor_attendance_id_seq OWNER TO ats_user;

--
-- Name: doctor_attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.doctor_attendance_id_seq OWNED BY public.doctor_attendance.id;


--
-- Name: doctor_notes; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.doctor_notes (
    note_id integer NOT NULL,
    patient_id integer,
    visit_id integer,
    doctor_username character varying(80) NOT NULL,
    doctor_name character varying(150) DEFAULT ''::character varying,
    note_type character varying(50) DEFAULT 'clinical'::character varying,
    note_text text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.doctor_notes OWNER TO ats_user;

--
-- Name: doctor_notes_note_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.doctor_notes_note_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctor_notes_note_id_seq OWNER TO ats_user;

--
-- Name: doctor_notes_note_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.doctor_notes_note_id_seq OWNED BY public.doctor_notes.note_id;


--
-- Name: doctor_rounds; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.doctor_rounds (
    id integer NOT NULL,
    doctor_name character varying(150) NOT NULL,
    ward character varying(80) DEFAULT ''::character varying,
    round_time character varying(20) DEFAULT ''::character varying,
    status character varying(20) DEFAULT 'pending'::character varying,
    notes text DEFAULT ''::text,
    scheduled_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone
);


ALTER TABLE public.doctor_rounds OWNER TO ats_user;

--
-- Name: doctor_rounds_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.doctor_rounds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctor_rounds_id_seq OWNER TO ats_user;

--
-- Name: doctor_rounds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.doctor_rounds_id_seq OWNED BY public.doctor_rounds.id;


--
-- Name: doctors; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.doctors (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    department character varying(100) DEFAULT ''::character varying,
    specialization character varying(200) DEFAULT ''::character varying,
    phone character varying(20) DEFAULT ''::character varying,
    status character varying(20) DEFAULT 'available'::character varying,
    on_duty boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.doctors OWNER TO ats_user;

--
-- Name: doctors_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.doctors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctors_id_seq OWNER TO ats_user;

--
-- Name: doctors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.doctors_id_seq OWNED BY public.doctors.id;


--
-- Name: hospital_expenses; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.hospital_expenses (
    expense_id integer NOT NULL,
    expense_date date DEFAULT CURRENT_DATE NOT NULL,
    category character varying(80) NOT NULL,
    sub_category character varying(120) DEFAULT ''::character varying,
    description character varying(300) DEFAULT ''::character varying,
    amount numeric(12,2) DEFAULT 0 NOT NULL,
    payment_mode character varying(40) DEFAULT 'Cash'::character varying,
    vendor character varying(150) DEFAULT ''::character varying,
    invoice_ref character varying(80) DEFAULT ''::character varying,
    recurring boolean DEFAULT false,
    created_by character varying(60) DEFAULT 'admin'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.hospital_expenses OWNER TO ats_user;

--
-- Name: hospital_expenses_expense_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.hospital_expenses_expense_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hospital_expenses_expense_id_seq OWNER TO ats_user;

--
-- Name: hospital_expenses_expense_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.hospital_expenses_expense_id_seq OWNED BY public.hospital_expenses.expense_id;


--
-- Name: imaging_orders; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.imaging_orders (
    id integer NOT NULL,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    doctor_username character varying(80),
    modality character varying(50) DEFAULT 'X-Ray'::character varying,
    body_part character varying(100) DEFAULT ''::character varying,
    clinical_notes text DEFAULT ''::text,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone
);


ALTER TABLE public.imaging_orders OWNER TO ats_user;

--
-- Name: imaging_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.imaging_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.imaging_orders_id_seq OWNER TO ats_user;

--
-- Name: imaging_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.imaging_orders_id_seq OWNED BY public.imaging_orders.id;


--
-- Name: imaging_reports; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.imaging_reports (
    id integer NOT NULL,
    order_id integer,
    patient_name character varying(150),
    modality character varying(50) DEFAULT 'X-Ray'::character varying,
    findings text DEFAULT ''::text,
    impression text DEFAULT ''::text,
    report_file_path text DEFAULT ''::text,
    radiologist character varying(150) DEFAULT ''::character varying,
    reported_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.imaging_reports OWNER TO ats_user;

--
-- Name: imaging_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.imaging_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.imaging_reports_id_seq OWNER TO ats_user;

--
-- Name: imaging_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.imaging_reports_id_seq OWNED BY public.imaging_reports.id;


--
-- Name: imaging_tests; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.imaging_tests (
    id integer NOT NULL,
    test_code character varying(20) NOT NULL,
    test_name character varying(200) NOT NULL,
    modality character varying(50) DEFAULT 'X-Ray'::character varying,
    body_part character varying(100) DEFAULT ''::character varying,
    price numeric(10,2) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.imaging_tests OWNER TO ats_user;

--
-- Name: imaging_tests_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.imaging_tests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.imaging_tests_id_seq OWNER TO ats_user;

--
-- Name: imaging_tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.imaging_tests_id_seq OWNED BY public.imaging_tests.id;


--
-- Name: inventory_stock; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.inventory_stock (
    id integer NOT NULL,
    medicine_id integer,
    batch_no character varying(50) DEFAULT ''::character varying,
    batch_number character varying(50) DEFAULT ''::character varying,
    expiry_date date,
    quantity integer DEFAULT 0,
    min_quantity integer DEFAULT 10,
    purchase_price numeric(10,2) DEFAULT 0,
    sell_price numeric(10,2) DEFAULT 0,
    supplier character varying(150) DEFAULT ''::character varying,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.inventory_stock OWNER TO ats_user;

--
-- Name: inventory_stock_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.inventory_stock_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_stock_id_seq OWNER TO ats_user;

--
-- Name: inventory_stock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.inventory_stock_id_seq OWNED BY public.inventory_stock.id;


--
-- Name: lab_orders; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.lab_orders (
    id integer NOT NULL,
    patient_name character varying(150),
    patient_phone character varying(20) DEFAULT ''::character varying,
    doctor_username character varying(80),
    test_type character varying(30) DEFAULT 'LAB'::character varying,
    test_name character varying(200),
    status character varying(20) DEFAULT 'PENDING'::character varying,
    result_text text DEFAULT ''::text,
    result_file text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone,
    patient_id integer,
    visit_id integer,
    prescription_id integer,
    urgency character varying(20) DEFAULT 'routine'::character varying,
    lab_notes text DEFAULT ''::text
);


ALTER TABLE public.lab_orders OWNER TO ats_user;

--
-- Name: lab_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.lab_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lab_orders_id_seq OWNER TO ats_user;

--
-- Name: lab_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.lab_orders_id_seq OWNED BY public.lab_orders.id;


--
-- Name: lab_reports; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.lab_reports (
    id integer NOT NULL,
    order_id integer,
    patient_name character varying(150),
    patient_phone character varying(20) DEFAULT ''::character varying,
    test_name character varying(200),
    result_text text DEFAULT ''::text,
    result_file_path text DEFAULT ''::text,
    remarks text DEFAULT ''::text,
    lab_username character varying(80),
    reported_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.lab_reports OWNER TO ats_user;

--
-- Name: lab_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.lab_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lab_reports_id_seq OWNER TO ats_user;

--
-- Name: lab_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.lab_reports_id_seq OWNED BY public.lab_reports.id;


--
-- Name: lab_results; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.lab_results (
    result_id integer NOT NULL,
    order_id integer,
    patient_id integer,
    patient_name character varying(150) DEFAULT ''::character varying,
    test_name character varying(200) DEFAULT ''::character varying,
    result_value text DEFAULT ''::text,
    reference_range character varying(100) DEFAULT ''::character varying,
    unit character varying(30) DEFAULT ''::character varying,
    is_abnormal boolean DEFAULT false,
    remarks text DEFAULT ''::text,
    lab_username character varying(80) DEFAULT ''::character varying,
    reported_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.lab_results OWNER TO ats_user;

--
-- Name: lab_results_result_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.lab_results_result_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lab_results_result_id_seq OWNER TO ats_user;

--
-- Name: lab_results_result_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.lab_results_result_id_seq OWNED BY public.lab_results.result_id;


--
-- Name: lab_tests; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.lab_tests (
    id integer NOT NULL,
    test_code character varying(20) NOT NULL,
    test_name character varying(200) NOT NULL,
    category character varying(80) DEFAULT 'Pathology'::character varying,
    normal_range character varying(100) DEFAULT ''::character varying,
    unit character varying(30) DEFAULT ''::character varying,
    price numeric(10,2) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.lab_tests OWNER TO ats_user;

--
-- Name: lab_tests_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.lab_tests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lab_tests_id_seq OWNER TO ats_user;

--
-- Name: lab_tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.lab_tests_id_seq OWNED BY public.lab_tests.id;


--
-- Name: medicines; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.medicines (
    id integer NOT NULL,
    medicine_name character varying(200) NOT NULL,
    generic_name character varying(200) DEFAULT ''::character varying,
    category character varying(80) DEFAULT 'Tablet'::character varying,
    manufacturer character varying(150) DEFAULT ''::character varying,
    unit character varying(30) DEFAULT 'Strip'::character varying,
    unit_price numeric(10,2) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.medicines OWNER TO ats_user;

--
-- Name: medicines_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.medicines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.medicines_id_seq OWNER TO ats_user;

--
-- Name: medicines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.medicines_id_seq OWNED BY public.medicines.id;


--
-- Name: notification_logs; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.notification_logs (
    id integer NOT NULL,
    tenant_slug character varying(80) DEFAULT ''::character varying,
    channel character varying(30) DEFAULT 'telegram'::character varying,
    event_type character varying(80) DEFAULT ''::character varying,
    recipient character varying(150) DEFAULT ''::character varying,
    message text DEFAULT ''::text,
    status character varying(20) DEFAULT 'sent'::character varying,
    error_msg text DEFAULT ''::text,
    sent_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_logs OWNER TO ats_user;

--
-- Name: notification_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.notification_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_logs_id_seq OWNER TO ats_user;

--
-- Name: notification_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.notification_logs_id_seq OWNED BY public.notification_logs.id;


--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.notification_settings (
    id integer NOT NULL,
    tenant_slug character varying(80) NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value text DEFAULT ''::text,
    updated_by character varying(80) DEFAULT 'system'::character varying,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_settings OWNER TO ats_user;

--
-- Name: notification_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.notification_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_settings_id_seq OWNER TO ats_user;

--
-- Name: notification_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.notification_settings_id_seq OWNED BY public.notification_settings.id;


--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.notification_templates (
    id integer NOT NULL,
    tenant_slug character varying(80) DEFAULT 'default'::character varying,
    event_type character varying(80) NOT NULL,
    channel character varying(30) DEFAULT 'telegram'::character varying,
    template text NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_templates OWNER TO ats_user;

--
-- Name: notification_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.notification_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_templates_id_seq OWNER TO ats_user;

--
-- Name: notification_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.notification_templates_id_seq OWNED BY public.notification_templates.id;


--
-- Name: nurse_assignments; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.nurse_assignments (
    id integer NOT NULL,
    nurse_username character varying(80) NOT NULL,
    patient_name character varying(150),
    patient_phone character varying(20) DEFAULT ''::character varying,
    ward character varying(80) DEFAULT ''::character varying,
    bed_number character varying(20) DEFAULT ''::character varying,
    shift character varying(20) DEFAULT 'Morning'::character varying,
    assigned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    discharged_at timestamp without time zone
);


ALTER TABLE public.nurse_assignments OWNER TO ats_user;

--
-- Name: nurse_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.nurse_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nurse_assignments_id_seq OWNER TO ats_user;

--
-- Name: nurse_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.nurse_assignments_id_seq OWNED BY public.nurse_assignments.id;


--
-- Name: patient_admissions; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.patient_admissions (
    id integer NOT NULL,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    patient_aadhar character varying(20) DEFAULT ''::character varying,
    age character varying(10) DEFAULT ''::character varying,
    gender character varying(10) DEFAULT 'Unknown'::character varying,
    blood_group character varying(5) DEFAULT ''::character varying,
    address text DEFAULT ''::text,
    admission_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    discharge_date timestamp without time zone,
    ward_name character varying(100) DEFAULT ''::character varying,
    bed_number character varying(20) DEFAULT ''::character varying,
    admitting_doctor character varying(150) DEFAULT ''::character varying,
    department character varying(100) DEFAULT ''::character varying,
    diagnosis text DEFAULT ''::text,
    admission_notes text DEFAULT ''::text,
    status character varying(20) DEFAULT 'admitted'::character varying,
    created_by character varying(80) DEFAULT 'reception'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.patient_admissions OWNER TO ats_user;

--
-- Name: patient_admissions_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.patient_admissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patient_admissions_id_seq OWNER TO ats_user;

--
-- Name: patient_admissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.patient_admissions_id_seq OWNED BY public.patient_admissions.id;


--
-- Name: patient_visits; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.patient_visits (
    visit_id integer NOT NULL,
    patient_id integer,
    visit_type character varying(10) DEFAULT 'OP'::character varying,
    doctor_assigned character varying(150) DEFAULT ''::character varying,
    doctor_username character varying(80) DEFAULT ''::character varying,
    department character varying(100) DEFAULT ''::character varying,
    visit_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    chief_complaint text DEFAULT ''::text,
    diagnosis text DEFAULT ''::text,
    notes text DEFAULT ''::text,
    status character varying(30) DEFAULT 'active'::character varying,
    op_ticket_no character varying(30) DEFAULT ''::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.patient_visits OWNER TO ats_user;

--
-- Name: patients; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.patients (
    id integer NOT NULL,
    full_name character varying(150) NOT NULL,
    dob date,
    gender character varying(10) DEFAULT 'Unknown'::character varying,
    phone character varying(20),
    aadhar character varying(20),
    address text DEFAULT ''::text,
    blood_group character varying(5) DEFAULT ''::character varying,
    allergies text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    uhid character varying(20) DEFAULT NULL::character varying
);


ALTER TABLE public.patients OWNER TO ats_user;

--
-- Name: prescriptions; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.prescriptions (
    id integer NOT NULL,
    patient_name character varying(150),
    patient_phone character varying(20) DEFAULT ''::character varying,
    doctor_username character varying(80),
    doctor_name character varying(150),
    diagnosis text,
    medicines text,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    chief_complaint text DEFAULT ''::text,
    bp character varying(20) DEFAULT ''::character varying,
    pulse character varying(10) DEFAULT ''::character varying,
    spo2 character varying(10) DEFAULT ''::character varying,
    follow_up_days integer,
    patient_id integer,
    visit_id integer,
    uhid character varying(20) DEFAULT ''::character varying,
    created_by_doctor character varying(150) DEFAULT ''::character varying,
    symptoms text DEFAULT ''::text,
    clinical_notes text DEFAULT ''::text,
    temperature character varying(10) DEFAULT ''::character varying,
    weight character varying(10) DEFAULT ''::character varying,
    diet_advice text DEFAULT ''::text,
    special_instructions text DEFAULT ''::text,
    follow_up_date date
);


ALTER TABLE public.prescriptions OWNER TO ats_user;

--
-- Name: patient_timeline; Type: VIEW; Schema: public; Owner: ats_user
--

CREATE VIEW public.patient_timeline AS
 SELECT p.id AS patient_id,
    p.full_name AS patient_name,
    p.uhid,
    'visit'::text AS event_type,
    v.visit_id AS event_id,
    v.visit_date AS event_date,
    v.chief_complaint AS summary,
    v.doctor_assigned AS actor,
    v.status AS event_status
   FROM (public.patients p
     JOIN public.patient_visits v ON ((v.patient_id = p.id)))
UNION ALL
 SELECT p.id AS patient_id,
    p.full_name AS patient_name,
    p.uhid,
    'prescription'::text AS event_type,
    rx.id AS event_id,
    rx.created_at AS event_date,
    rx.diagnosis AS summary,
    rx.doctor_name AS actor,
    'saved'::character varying AS event_status
   FROM (public.patients p
     JOIN public.prescriptions rx ON ((rx.patient_id = p.id)))
UNION ALL
 SELECT p.id AS patient_id,
    p.full_name AS patient_name,
    p.uhid,
    'lab_order'::text AS event_type,
    lo.id AS event_id,
    lo.created_at AS event_date,
    lo.test_name AS summary,
    lo.doctor_username AS actor,
    lo.status AS event_status
   FROM (public.patients p
     JOIN public.lab_orders lo ON ((lo.patient_id = p.id)));


ALTER VIEW public.patient_timeline OWNER TO ats_user;

--
-- Name: patient_visits_visit_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.patient_visits_visit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patient_visits_visit_id_seq OWNER TO ats_user;

--
-- Name: patient_visits_visit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.patient_visits_visit_id_seq OWNED BY public.patient_visits.visit_id;


--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.patients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patients_id_seq OWNER TO ats_user;

--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.patients_id_seq OWNED BY public.patients.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    bill_id integer,
    amount_paid numeric(10,2) DEFAULT 0,
    payment_mode character varying(30) DEFAULT 'Cash'::character varying,
    reference_no character varying(100) DEFAULT ''::character varying,
    received_by character varying(80),
    paid_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.payments OWNER TO ats_user;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO ats_user;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: pharmacy_sale_items; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.pharmacy_sale_items (
    id integer NOT NULL,
    sale_id integer,
    medicine_id integer,
    medicine_name character varying(200),
    quantity integer DEFAULT 1,
    unit_price numeric(10,2) DEFAULT 0,
    total_price numeric(10,2) DEFAULT 0
);


ALTER TABLE public.pharmacy_sale_items OWNER TO ats_user;

--
-- Name: pharmacy_sale_items_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.pharmacy_sale_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pharmacy_sale_items_id_seq OWNER TO ats_user;

--
-- Name: pharmacy_sale_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.pharmacy_sale_items_id_seq OWNED BY public.pharmacy_sale_items.id;


--
-- Name: pharmacy_sales; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.pharmacy_sales (
    id integer NOT NULL,
    patient_name character varying(150) DEFAULT 'Walk-in'::character varying,
    patient_phone character varying(20) DEFAULT ''::character varying,
    prescription_id integer,
    total_amount numeric(10,2) DEFAULT 0,
    discount numeric(10,2) DEFAULT 0,
    net_amount numeric(10,2) DEFAULT 0,
    payment_mode character varying(30) DEFAULT 'Cash'::character varying,
    staff_username character varying(80),
    sold_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.pharmacy_sales OWNER TO ats_user;

--
-- Name: pharmacy_sales_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.pharmacy_sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pharmacy_sales_id_seq OWNER TO ats_user;

--
-- Name: pharmacy_sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.pharmacy_sales_id_seq OWNED BY public.pharmacy_sales.id;


--
-- Name: prescription_items; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.prescription_items (
    item_id integer NOT NULL,
    prescription_id integer,
    medicine_name character varying(200) NOT NULL,
    dosage character varying(100) DEFAULT ''::character varying,
    frequency character varying(100) DEFAULT ''::character varying,
    duration character varying(50) DEFAULT ''::character varying,
    instructions text DEFAULT ''::text,
    quantity integer DEFAULT 0,
    route character varying(80) DEFAULT 'Oral'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.prescription_items OWNER TO ats_user;

--
-- Name: prescription_items_item_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.prescription_items_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prescription_items_item_id_seq OWNER TO ats_user;

--
-- Name: prescription_items_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.prescription_items_item_id_seq OWNED BY public.prescription_items.item_id;


--
-- Name: prescription_medicines; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.prescription_medicines (
    id integer NOT NULL,
    prescription_id integer NOT NULL,
    medicine_name character varying(200) NOT NULL,
    dose character varying(100) DEFAULT ''::character varying,
    frequency character varying(100) DEFAULT ''::character varying,
    duration character varying(50) DEFAULT ''::character varying,
    route character varying(80) DEFAULT 'Oral'::character varying,
    notes text DEFAULT ''::text,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.prescription_medicines OWNER TO ats_user;

--
-- Name: prescription_medicines_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.prescription_medicines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prescription_medicines_id_seq OWNER TO ats_user;

--
-- Name: prescription_medicines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.prescription_medicines_id_seq OWNED BY public.prescription_medicines.id;


--
-- Name: prescriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.prescriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prescriptions_id_seq OWNER TO ats_user;

--
-- Name: prescriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.prescriptions_id_seq OWNED BY public.prescriptions.id;


--
-- Name: procedure_charges; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.procedure_charges (
    id integer NOT NULL,
    procedure_name character varying(200) NOT NULL,
    category character varying(80) DEFAULT 'General'::character varying,
    default_price numeric(10,2) DEFAULT 0,
    gst_percent numeric(5,2) DEFAULT 0,
    description text DEFAULT ''::text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.procedure_charges OWNER TO ats_user;

--
-- Name: procedure_charges_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.procedure_charges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procedure_charges_id_seq OWNER TO ats_user;

--
-- Name: procedure_charges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.procedure_charges_id_seq OWNED BY public.procedure_charges.id;


--
-- Name: registrations; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.registrations (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    age character varying(10) DEFAULT ''::character varying,
    phone character varying(20) DEFAULT ''::character varying,
    aadhar character varying(20) DEFAULT ''::character varying,
    issue text DEFAULT ''::text,
    doctor character varying(150) DEFAULT ''::character varying,
    appointment_time character varying(50) DEFAULT ''::character varying,
    status character varying(20) DEFAULT 'pending'::character varying,
    source character varying(30) DEFAULT 'chatbot'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.registrations OWNER TO ats_user;

--
-- Name: registrations_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.registrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.registrations_id_seq OWNER TO ats_user;

--
-- Name: registrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.registrations_id_seq OWNED BY public.registrations.id;


--
-- Name: services_catalogue; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.services_catalogue (
    service_id integer NOT NULL,
    service_name character varying(200) NOT NULL,
    department character varying(100) DEFAULT ''::character varying,
    default_price numeric(10,2) DEFAULT 0,
    tax_percentage numeric(5,2) DEFAULT 0,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.services_catalogue OWNER TO ats_user;

--
-- Name: services_catalogue_service_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.services_catalogue_service_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.services_catalogue_service_id_seq OWNER TO ats_user;

--
-- Name: services_catalogue_service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.services_catalogue_service_id_seq OWNED BY public.services_catalogue.service_id;


--
-- Name: staff_users; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.staff_users (
    id integer NOT NULL,
    username character varying(80) NOT NULL,
    password_hash text NOT NULL,
    role character varying(20) DEFAULT 'RECEPTION'::character varying NOT NULL,
    department character varying(100) DEFAULT ''::character varying,
    full_name character varying(150) DEFAULT ''::character varying,
    is_active boolean DEFAULT true,
    must_change_password boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.staff_users OWNER TO ats_user;

--
-- Name: staff_users_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.staff_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.staff_users_id_seq OWNER TO ats_user;

--
-- Name: staff_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.staff_users_id_seq OWNED BY public.staff_users.id;


--
-- Name: surgery_records; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.surgery_records (
    id integer NOT NULL,
    admission_id integer,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    surgeon_name character varying(150) DEFAULT ''::character varying,
    surgeon_username character varying(80) DEFAULT ''::character varying,
    surgery_type character varying(200) NOT NULL,
    anesthesia_type character varying(100) DEFAULT 'General'::character varying,
    estimated_cost numeric(10,2) DEFAULT 0,
    negotiated_cost numeric(10,2) DEFAULT 0,
    operation_date timestamp without time zone,
    duration_minutes integer DEFAULT 0,
    operation_notes text DEFAULT ''::text,
    complications text DEFAULT ''::text,
    status character varying(30) DEFAULT 'scheduled'::character varying,
    created_by character varying(80) DEFAULT ''::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.surgery_records OWNER TO ats_user;

--
-- Name: surgery_records_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.surgery_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.surgery_records_id_seq OWNER TO ats_user;

--
-- Name: surgery_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.surgery_records_id_seq OWNED BY public.surgery_records.id;


--
-- Name: system_logs; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.system_logs (
    id integer NOT NULL,
    username character varying(80) DEFAULT 'system'::character varying,
    role character varying(20) DEFAULT ''::character varying,
    action character varying(200) NOT NULL,
    details text DEFAULT ''::text,
    ip_address character varying(45) DEFAULT ''::character varying,
    logged_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_logs OWNER TO ats_user;

--
-- Name: system_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.system_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_logs_id_seq OWNER TO ats_user;

--
-- Name: system_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.system_logs_id_seq OWNED BY public.system_logs.id;


--
-- Name: visit_records; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.visit_records (
    id integer NOT NULL,
    patient_name character varying(150) NOT NULL,
    patient_phone character varying(20) DEFAULT ''::character varying,
    doctor_username character varying(80),
    doctor_name character varying(150) DEFAULT ''::character varying,
    department character varying(100) DEFAULT ''::character varying,
    chief_complaint text DEFAULT ''::text,
    examination text DEFAULT ''::text,
    diagnosis text DEFAULT ''::text,
    treatment_plan text DEFAULT ''::text,
    follow_up_date date,
    visit_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.visit_records OWNER TO ats_user;

--
-- Name: visit_records_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.visit_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.visit_records_id_seq OWNER TO ats_user;

--
-- Name: visit_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.visit_records_id_seq OWNED BY public.visit_records.id;


--
-- Name: vitals; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.vitals (
    id integer NOT NULL,
    patient_name character varying(150),
    patient_phone character varying(20) DEFAULT ''::character varying,
    nurse_username character varying(80),
    bp character varying(20) DEFAULT ''::character varying,
    pulse character varying(10) DEFAULT ''::character varying,
    temperature character varying(10) DEFAULT ''::character varying,
    spo2 character varying(10) DEFAULT ''::character varying,
    weight character varying(10) DEFAULT ''::character varying,
    notes text DEFAULT ''::text,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.vitals OWNER TO ats_user;

--
-- Name: vitals_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.vitals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vitals_id_seq OWNER TO ats_user;

--
-- Name: vitals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.vitals_id_seq OWNED BY public.vitals.id;


--
-- Name: wards; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.wards (
    id integer NOT NULL,
    ward_name character varying(100) NOT NULL,
    ward_type character varying(50) DEFAULT 'General'::character varying,
    total_beds integer DEFAULT 0,
    floor character varying(20) DEFAULT 'Ground'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.wards OWNER TO ats_user;

--
-- Name: wards_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.wards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wards_id_seq OWNER TO ats_user;

--
-- Name: wards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.wards_id_seq OWNED BY public.wards.id;


--
-- Name: appointments id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.appointments ALTER COLUMN id SET DEFAULT nextval('public.appointments_id_seq'::regclass);


--
-- Name: attendance id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.attendance ALTER COLUMN id SET DEFAULT nextval('public.attendance_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: bed_assignments id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bed_assignments ALTER COLUMN id SET DEFAULT nextval('public.bed_assignments_id_seq'::regclass);


--
-- Name: beds id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.beds ALTER COLUMN id SET DEFAULT nextval('public.beds_id_seq'::regclass);


--
-- Name: bill_items id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bill_items ALTER COLUMN id SET DEFAULT nextval('public.bill_items_id_seq'::regclass);


--
-- Name: billing id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.billing ALTER COLUMN id SET DEFAULT nextval('public.billing_id_seq'::regclass);


--
-- Name: daily_rounds id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.daily_rounds ALTER COLUMN id SET DEFAULT nextval('public.daily_rounds_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: discharge_summaries id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.discharge_summaries ALTER COLUMN id SET DEFAULT nextval('public.discharge_summaries_id_seq'::regclass);


--
-- Name: doctor_attendance id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_attendance ALTER COLUMN id SET DEFAULT nextval('public.doctor_attendance_id_seq'::regclass);


--
-- Name: doctor_notes note_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_notes ALTER COLUMN note_id SET DEFAULT nextval('public.doctor_notes_note_id_seq'::regclass);


--
-- Name: doctor_rounds id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_rounds ALTER COLUMN id SET DEFAULT nextval('public.doctor_rounds_id_seq'::regclass);


--
-- Name: doctors id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctors ALTER COLUMN id SET DEFAULT nextval('public.doctors_id_seq'::regclass);


--
-- Name: hospital_expenses expense_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.hospital_expenses ALTER COLUMN expense_id SET DEFAULT nextval('public.hospital_expenses_expense_id_seq'::regclass);


--
-- Name: imaging_orders id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_orders ALTER COLUMN id SET DEFAULT nextval('public.imaging_orders_id_seq'::regclass);


--
-- Name: imaging_reports id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_reports ALTER COLUMN id SET DEFAULT nextval('public.imaging_reports_id_seq'::regclass);


--
-- Name: imaging_tests id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_tests ALTER COLUMN id SET DEFAULT nextval('public.imaging_tests_id_seq'::regclass);


--
-- Name: inventory_stock id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.inventory_stock ALTER COLUMN id SET DEFAULT nextval('public.inventory_stock_id_seq'::regclass);


--
-- Name: lab_orders id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_orders ALTER COLUMN id SET DEFAULT nextval('public.lab_orders_id_seq'::regclass);


--
-- Name: lab_reports id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_reports ALTER COLUMN id SET DEFAULT nextval('public.lab_reports_id_seq'::regclass);


--
-- Name: lab_results result_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_results ALTER COLUMN result_id SET DEFAULT nextval('public.lab_results_result_id_seq'::regclass);


--
-- Name: lab_tests id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_tests ALTER COLUMN id SET DEFAULT nextval('public.lab_tests_id_seq'::regclass);


--
-- Name: medicines id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.medicines ALTER COLUMN id SET DEFAULT nextval('public.medicines_id_seq'::regclass);


--
-- Name: notification_logs id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_logs ALTER COLUMN id SET DEFAULT nextval('public.notification_logs_id_seq'::regclass);


--
-- Name: notification_settings id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_settings ALTER COLUMN id SET DEFAULT nextval('public.notification_settings_id_seq'::regclass);


--
-- Name: notification_templates id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_templates ALTER COLUMN id SET DEFAULT nextval('public.notification_templates_id_seq'::regclass);


--
-- Name: nurse_assignments id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.nurse_assignments ALTER COLUMN id SET DEFAULT nextval('public.nurse_assignments_id_seq'::regclass);


--
-- Name: patient_admissions id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patient_admissions ALTER COLUMN id SET DEFAULT nextval('public.patient_admissions_id_seq'::regclass);


--
-- Name: patient_visits visit_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patient_visits ALTER COLUMN visit_id SET DEFAULT nextval('public.patient_visits_visit_id_seq'::regclass);


--
-- Name: patients id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patients ALTER COLUMN id SET DEFAULT nextval('public.patients_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: pharmacy_sale_items id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sale_items ALTER COLUMN id SET DEFAULT nextval('public.pharmacy_sale_items_id_seq'::regclass);


--
-- Name: pharmacy_sales id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sales ALTER COLUMN id SET DEFAULT nextval('public.pharmacy_sales_id_seq'::regclass);


--
-- Name: prescription_items item_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_items ALTER COLUMN item_id SET DEFAULT nextval('public.prescription_items_item_id_seq'::regclass);


--
-- Name: prescription_medicines id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_medicines ALTER COLUMN id SET DEFAULT nextval('public.prescription_medicines_id_seq'::regclass);


--
-- Name: prescriptions id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescriptions ALTER COLUMN id SET DEFAULT nextval('public.prescriptions_id_seq'::regclass);


--
-- Name: procedure_charges id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.procedure_charges ALTER COLUMN id SET DEFAULT nextval('public.procedure_charges_id_seq'::regclass);


--
-- Name: registrations id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.registrations ALTER COLUMN id SET DEFAULT nextval('public.registrations_id_seq'::regclass);


--
-- Name: services_catalogue service_id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.services_catalogue ALTER COLUMN service_id SET DEFAULT nextval('public.services_catalogue_service_id_seq'::regclass);


--
-- Name: staff_users id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.staff_users ALTER COLUMN id SET DEFAULT nextval('public.staff_users_id_seq'::regclass);


--
-- Name: surgery_records id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.surgery_records ALTER COLUMN id SET DEFAULT nextval('public.surgery_records_id_seq'::regclass);


--
-- Name: system_logs id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.system_logs ALTER COLUMN id SET DEFAULT nextval('public.system_logs_id_seq'::regclass);


--
-- Name: visit_records id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.visit_records ALTER COLUMN id SET DEFAULT nextval('public.visit_records_id_seq'::regclass);


--
-- Name: vitals id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.vitals ALTER COLUMN id SET DEFAULT nextval('public.vitals_id_seq'::regclass);


--
-- Name: wards id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.wards ALTER COLUMN id SET DEFAULT nextval('public.wards_id_seq'::regclass);


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.appointments (id, patient_name, patient_phone, patient_aadhar, age, issue, doctor_name, department, appointment_date, appointment_time, status, source, notes, created_at, updated_at) FROM stdin;
4	Vikram Singh	+91 9903000001	300100000001	38	Routine check-up	Dr. Meena Pillai	General Medicine	2026-03-12	10:00 AM	scheduled	chatbot		2026-03-11 07:23:53.670267	2026-03-11 07:23:53.670267
5	Poonam Gupta	+91 9903000002	300100000002	33	Routine check-up	Dr. Raj Sharma	Surgery	2026-03-13	11:00 AM	scheduled	chatbot		2026-03-11 07:23:53.672518	2026-03-11 07:23:53.672518
6	Mohan Das	+91 9903000003	300100000003	56	Routine check-up	Dr. Uma Devi	Paediatrics	2026-03-14	12:00 AM	scheduled	chatbot		2026-03-11 07:23:53.673449	2026-03-11 07:23:53.673449
7	Suresh Reddy	9519667910		44	Hypertension	Dr. Anitha Sharma		2026-02-24	10:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
8	Poonam Gupta	+91 9903000002		67	Eye Check	Dr. Priya Nair		2026-02-19	13:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
9	Meena Kumari	9548060525		51	Headache	Dr. Anitha Sharma		2026-02-18	12:00	cancelled	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
10	Srinivas Yadav	9857496755		49	Cough	Dr. Suresh Reddy		2026-02-20	14:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
11	Srinivas Yadav	9857496755		50	Chest Pain	Dr. Anitha Sharma		2026-03-11	09:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
12	Rajesh Kumar	9455718159		60	Diabetes Check	Dr. Ravi Kumar		2026-02-16	12:00	pending	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
13	Lakshmi Bai	9739558258		32	Skin Rash	Dr. Anitha Sharma		2026-02-18	14:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
14	Poonam Gupta	+91 9903000002		36	Joint Pain	Dr. Suresh Reddy		2026-02-16	10:00	pending	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
15	Kavitha Nair	9330967910		23	Headache	Dr. Anitha Sharma		2026-03-01	12:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
16	Sunita Patel	9659624720		66	Hypertension	Dr. Priya Nair		2026-02-24	12:00	pending	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
17	Kishore Kumar	9413332335		57	Hypertension	Dr. Priya Nair		2026-03-05	17:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
18	Swathi Nair	+91 9903000004		46	Fever	Dr. Ravi Kumar		2026-03-03	17:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
19	Kishore Kumar	9413332335		72	Headache	Dr. Anitha Sharma		2026-03-02	13:00	cancelled	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
20	Poonam Gupta	+91 9903000002		38	Back Pain	Dr. Suresh Reddy		2026-02-21	15:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
21	Lakshmi Bai	9739558258		43	Chest Pain	Dr. Priya Nair		2026-02-27	17:00	cancelled	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
22	Srinivas Yadav	9857496755		40	Hypertension	Dr. Priya Nair		2026-02-28	15:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
23	Priya Sharma	9644726951		40	Fever	Dr. Ravi Kumar		2026-02-19	14:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
24	Vikram Singh	+91 9903000001		71	Chest Pain	Dr. Priya Nair		2026-02-15	15:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
25	Srinivas Yadav	9857496755		44	Joint Pain	Dr. Ravi Kumar		2026-03-12	09:00	cancelled	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
26	Rajesh Kumar	9455718159		69	Back Pain	Dr. Priya Nair		2026-02-14	14:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
27	Mohan Das	9614109329		32	Chest Pain	Dr. Ravi Kumar		2026-03-11	16:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
28	Deepa Singh	9174166531		61	Skin Rash	Dr. Anitha Sharma		2026-03-02	15:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
29	Meena Kumari	9548060525		41	Eye Check	Dr. Anitha Sharma		2026-02-18	11:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
30	Mohan Das	9614109329		47	Skin Rash	Dr. Ravi Kumar		2026-02-20	16:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
31	Poonam Gupta	+91 9903000002		23	Joint Pain	Dr. Suresh Reddy		2026-02-10	17:00	cancelled	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
32	Vikram Singh	+91 9903000001		66	Cough	Dr. Anitha Sharma		2026-02-12	12:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
33	Arjun Verma	+91 9903000005		70	Cough	Dr. Priya Nair		2026-03-08	14:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
34	Lakshmi Bai	9739558258		26	Joint Pain	Dr. Anitha Sharma		2026-02-28	13:00	pending	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
35	Lakshmi Bai	9739558258		61	Chest Pain	Dr. Anitha Sharma		2026-03-12	14:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
36	Arjun Verma	+91 9903000005		51	Chest Pain	Dr. Suresh Reddy		2026-03-10	14:00	completed	chatbot		2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698
\.


--
-- Data for Name: attendance; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.attendance (id, staff_name, action, notes, recorded_at) FROM stdin;
1	city_medical_admin	check-in	On duty	2026-03-11 00:04:09.82415
2	city_medical_doctor	check-in	On duty	2026-03-11 00:04:09.82415
3	city_medical_nurse	check-in	On duty	2026-03-11 00:04:09.82415
4	city_medical_admin	check-in	On duty	2026-03-11 00:10:54.557866
5	city_medical_doctor	check-in	On duty	2026-03-11 00:10:54.557866
6	city_medical_nurse	check-in	On duty	2026-03-11 00:10:54.557866
7	city_medical_lab	check-in	On duty	2026-03-11 00:10:54.557866
8	city_medical_reception	check-in	On duty	2026-03-11 00:10:54.557866
9	city_medical_admin	check-in	On duty	2026-03-11 00:12:32.00818
10	city_medical_doctor	check-in	On duty	2026-03-11 00:12:32.00818
11	city_medical_nurse	check-in	On duty	2026-03-11 00:12:32.00818
12	city_medical_lab	check-in	On duty	2026-03-11 00:12:32.00818
13	city_medical_reception	check-in	On duty	2026-03-11 00:12:32.00818
14	Sita Devi	check-in	Role: Nurse	2026-03-12 08:54:00
15	Sita Devi	check-out	Role: Nurse	2026-03-12 18:54:00
16	Ramesh Babu	check-in	Role: Receptionist	2026-03-12 08:23:00
17	Ramesh Babu	check-out	Role: Receptionist	2026-03-12 17:20:00
18	Kavitha	check-in	Role: Lab Technician	2026-03-12 08:25:00
19	Kavitha	check-out	Role: Lab Technician	2026-03-12 18:15:00
20	Mohan Kumar	check-in	Role: Pharmacist	2026-03-12 09:02:00
21	Mohan Kumar	check-out	Role: Pharmacist	2026-03-12 17:22:00
22	Priya G	check-in	Role: Nurse	2026-03-12 09:02:00
23	Priya G	check-out	Role: Nurse	2026-03-12 18:12:00
24	Sita Devi	check-in	Role: Nurse	2026-03-11 08:28:00
25	Sita Devi	check-out	Role: Nurse	2026-03-11 18:44:00
26	Ramesh Babu	check-in	Role: Receptionist	2026-03-11 08:18:00
27	Ramesh Babu	check-out	Role: Receptionist	2026-03-11 18:56:00
28	Kavitha	check-in	Role: Lab Technician	2026-03-11 09:57:00
29	Kavitha	check-out	Role: Lab Technician	2026-03-11 18:33:00
30	Mohan Kumar	check-in	Role: Pharmacist	2026-03-11 09:34:00
31	Mohan Kumar	check-out	Role: Pharmacist	2026-03-11 18:00:00
32	Priya G	check-in	Role: Nurse	2026-03-11 09:35:00
33	Priya G	check-out	Role: Nurse	2026-03-11 17:02:00
34	Sita Devi	check-in	Role: Nurse	2026-03-10 08:35:00
35	Sita Devi	check-out	Role: Nurse	2026-03-10 18:50:00
36	Ramesh Babu	check-in	Role: Receptionist	2026-03-10 08:12:00
37	Ramesh Babu	check-out	Role: Receptionist	2026-03-10 18:24:00
38	Kavitha	check-in	Role: Lab Technician	2026-03-10 09:42:00
39	Kavitha	check-out	Role: Lab Technician	2026-03-10 17:35:00
40	Mohan Kumar	check-in	Role: Pharmacist	2026-03-10 09:14:00
41	Mohan Kumar	check-out	Role: Pharmacist	2026-03-10 17:03:00
42	Priya G	check-in	Role: Nurse	2026-03-10 09:26:00
43	Priya G	check-out	Role: Nurse	2026-03-10 17:19:00
44	Sita Devi	check-in	Role: Nurse	2026-03-09 09:26:00
45	Sita Devi	check-out	Role: Nurse	2026-03-09 18:02:00
46	Ramesh Babu	check-in	Role: Receptionist	2026-03-09 08:39:00
47	Ramesh Babu	check-out	Role: Receptionist	2026-03-09 17:13:00
48	Kavitha	check-in	Role: Lab Technician	2026-03-09 09:26:00
49	Kavitha	check-out	Role: Lab Technician	2026-03-09 18:28:00
50	Mohan Kumar	check-in	Role: Pharmacist	2026-03-09 08:00:00
51	Mohan Kumar	check-out	Role: Pharmacist	2026-03-09 17:35:00
52	Priya G	check-in	Role: Nurse	2026-03-09 09:39:00
53	Priya G	check-out	Role: Nurse	2026-03-09 18:31:00
54	Sita Devi	check-in	Role: Nurse	2026-03-08 08:55:00
55	Sita Devi	check-out	Role: Nurse	2026-03-08 18:16:00
56	Ramesh Babu	check-in	Role: Receptionist	2026-03-08 09:12:00
57	Ramesh Babu	check-out	Role: Receptionist	2026-03-08 17:11:00
58	Kavitha	check-in	Role: Lab Technician	2026-03-08 08:32:00
59	Kavitha	check-out	Role: Lab Technician	2026-03-08 17:52:00
60	Mohan Kumar	check-in	Role: Pharmacist	2026-03-08 09:11:00
61	Mohan Kumar	check-out	Role: Pharmacist	2026-03-08 17:49:00
62	Priya G	check-in	Role: Nurse	2026-03-08 08:31:00
63	Priya G	check-out	Role: Nurse	2026-03-08 18:22:00
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.audit_log (id, client_id, username, role, action, details, ip_address, created_at) FROM stdin;
1	\N	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 00:34:33.832491
2	\N	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 00:39:43.567491
3	\N	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 00:41:52.91251
4	\N	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 00:45:32.69909
5	\N	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 06:12:46.744397
6	\N	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 06:15:04.644096
7	\N	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 06:18:53.214431
8	\N	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 06:22:43.905018
9	\N	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 06:26:33.313112
10	\N	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 06:30:18.523106
11	\N	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 07:24:51.660613
12	\N	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 07:29:55.240889
13	\N	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 07:36:08.045085
14	\N	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 08:32:54.679251
15	\N	city_medical_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 08:49:22.015774
16	\N	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 08:49:54.832425
17	\N	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 08:50:20.948945
\.


--
-- Data for Name: bed_assignments; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.bed_assignments (id, bed_id, patient_name, patient_phone, admitted_at, discharged_at, notes) FROM stdin;
\.


--
-- Data for Name: beds; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.beds (id, ward_id, bed_number, bed_type, status, created_at) FROM stdin;
\.


--
-- Data for Name: bill_items; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.bill_items (id, bill_id, item_type, item_name, item_price, quantity, actual_price, negotiated_price, tax_percent, tax_amount, total_amount, notes, created_at) FROM stdin;
\.


--
-- Data for Name: billing; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.billing (id, patient_name, patient_phone, bill_type, admission_id, consultation_fee, lab_charges, imaging_charges, pharmacy_charges, bed_charges, surgery_charges, procedure_charges, misc_charges, total_amount, tax_amount, discount, net_amount, status, notes, created_by, created_at, updated_at) FROM stdin;
15	Vikram Singh	+91 9903000001	OPD	\N	500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	500.00	0.00	0.00	500.00	paid		admin	2026-03-11 07:23:53.74509	2026-03-11 07:23:53.74509
16	Poonam Gupta	+91 9903000002	OPD	\N	750.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	750.00	0.00	0.00	750.00	paid		admin	2026-03-11 07:23:53.747159	2026-03-11 07:23:53.747159
17	Mohan Das	+91 9903000003	OPD	\N	1000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1000.00	0.00	0.00	1000.00	paid		admin	2026-03-11 07:23:53.748067	2026-03-11 07:23:53.748067
18	Vikram Singh	+91 9903000001	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	6085.00	0.00	0.00	6085.00	paid		\N	2026-02-23 00:00:00	2026-03-12 02:35:05.003698
19	Rajesh Kumar	9455718159	IPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	5341.00	0.00	0.00	5341.00	partial		\N	2026-03-02 00:00:00	2026-03-12 02:35:05.003698
20	Suresh Reddy	9519667910	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	2505.00	0.00	0.00	2505.00	partial		\N	2026-03-11 00:00:00	2026-03-12 02:35:05.003698
21	Venkatesh Rao	9275364098	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1141.00	0.00	0.00	1141.00	partial		\N	2026-03-05 00:00:00	2026-03-12 02:35:05.003698
22	Suresh Reddy	9519667910	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	6376.00	0.00	0.00	6376.00	paid		\N	2026-02-15 00:00:00	2026-03-12 02:35:05.003698
23	Suresh Reddy	9519667910	Pharmacy	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	9419.00	0.00	0.00	9419.00	paid		\N	2026-03-09 00:00:00	2026-03-12 02:35:05.003698
24	Rajesh Kumar	9455718159	Pharmacy	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	4591.00	0.00	0.00	4591.00	paid		\N	2026-03-07 00:00:00	2026-03-12 02:35:05.003698
25	Anita Devi	9374824327	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	7066.00	0.00	0.00	7066.00	paid		\N	2026-02-10 00:00:00	2026-03-12 02:35:05.003698
26	Ramesh Babu	9463121498	IPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	4141.00	0.00	0.00	4141.00	paid		\N	2026-02-22 00:00:00	2026-03-12 02:35:05.003698
27	Meena Kumari	9548060525	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	2679.00	0.00	0.00	2679.00	unpaid		\N	2026-02-11 00:00:00	2026-03-12 02:35:05.003698
28	Srinivas Yadav	9857496755	IPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	2311.00	0.00	0.00	2311.00	unpaid		\N	2026-02-19 00:00:00	2026-03-12 02:35:05.003698
29	Lakshmi Bai	9739558258	OPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	6117.00	0.00	0.00	6117.00	paid		\N	2026-02-17 00:00:00	2026-03-12 02:35:05.003698
30	Sunita Patel	9659624720	Pharmacy	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	7550.00	0.00	0.00	7550.00	paid		\N	2026-02-17 00:00:00	2026-03-12 02:35:05.003698
31	Vikram Singh	+91 9903000001	Pharmacy	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	10667.00	0.00	0.00	10667.00	unpaid		\N	2026-02-16 00:00:00	2026-03-12 02:35:05.003698
32	Lakshmi Bai	9739558258	IPD	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	5415.00	0.00	0.00	5415.00	paid		\N	2026-02-14 00:00:00	2026-03-12 02:35:05.003698
\.


--
-- Data for Name: daily_rounds; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.daily_rounds (id, admission_id, patient_name, doctor_name, doctor_username, round_date, bp, pulse, temperature, spo2, clinical_notes, treatment_change, created_at) FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.departments (id, name, description, head_doctor, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: discharge_summaries; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.discharge_summaries (id, admission_id, patient_name, discharge_date, final_diagnosis, treatment_given, discharge_medicines, follow_up_date, follow_up_notes, diet_advice, activity_advice, doctor_name, doctor_username, bill_id, created_at) FROM stdin;
\.


--
-- Data for Name: doctor_attendance; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.doctor_attendance (id, doctor_name, action, shift, notes, recorded_at) FROM stdin;
\.


--
-- Data for Name: doctor_notes; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.doctor_notes (note_id, patient_id, visit_id, doctor_username, doctor_name, note_type, note_text, created_at) FROM stdin;
\.


--
-- Data for Name: doctor_rounds; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.doctor_rounds (id, doctor_name, ward, round_time, status, notes, scheduled_at, completed_at) FROM stdin;
\.


--
-- Data for Name: doctors; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.doctors (id, name, department, specialization, phone, status, on_duty, created_at) FROM stdin;
4	Dr. Meena Pillai	General Medicine	MBBS	+91 9800300001	active	t	2026-03-11 07:23:53.466235
5	Dr. Raj Sharma	Surgery	MBBS MS	+91 9800300002	active	t	2026-03-11 07:23:53.466235
6	Dr. Uma Devi	Paediatrics	MBBS DCH	+91 9800300003	active	t	2026-03-11 07:23:53.466235
7	Dr. Vikram Reddy	Orthopaedics	MBBS MS	+91 9800300004	active	t	2026-03-11 07:23:53.466235
\.


--
-- Data for Name: hospital_expenses; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.hospital_expenses (expense_id, expense_date, category, sub_category, description, amount, payment_mode, vendor, invoice_ref, recurring, created_by, created_at) FROM stdin;
1	2026-03-01	Rent & Premises		Monthly hospital rent	85000.00	Bank Transfer			t	admin	2026-03-12 02:35:05.003698
2	2026-03-01	Staff Salaries		Monthly payroll	320000.00	Bank Transfer			t	admin	2026-03-12 02:35:05.003698
3	2026-03-01	Electricity & Power		Electricity bill - APSPDCL	28000.00	Bank Transfer			t	admin	2026-03-12 02:35:05.003698
4	2026-03-01	Water & Utilities		Municipal water charges	4500.00	Bank Transfer			t	admin	2026-03-12 02:35:05.003698
5	2026-03-01	Internet & Communication		Broadband + CCTV plan	3000.00	Bank Transfer			t	admin	2026-03-12 02:35:05.003698
6	2026-03-01	Medical Equipment		ECG machine EMI	45000.00	Bank Transfer			f	admin	2026-03-12 02:35:05.003698
7	2026-03-01	Medicines & Consumables		Monthly pharmacy stock	38000.00	Bank Transfer			f	admin	2026-03-12 02:35:05.003698
8	2026-03-01	Insurance		Hospital liability insurance	12000.00	Bank Transfer			t	admin	2026-03-12 02:35:05.003698
9	2026-03-01	Maintenance & Repairs		Generator service	8500.00	Bank Transfer			f	admin	2026-03-12 02:35:05.003698
10	2026-03-01	Marketing & Advertising		Google Ads + pamphlets	6000.00	Bank Transfer			f	admin	2026-03-12 02:35:05.003698
11	2026-03-01	Lab Supplies		Lab reagents & consumables	14000.00	Bank Transfer			f	admin	2026-03-12 02:35:05.003698
12	2026-03-01	Housekeeping		Cleaning & sanitisation	9500.00	Bank Transfer			t	admin	2026-03-12 02:35:05.003698
\.


--
-- Data for Name: imaging_orders; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.imaging_orders (id, patient_name, patient_phone, doctor_username, modality, body_part, clinical_notes, status, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: imaging_reports; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.imaging_reports (id, order_id, patient_name, modality, findings, impression, report_file_path, radiologist, reported_at) FROM stdin;
\.


--
-- Data for Name: imaging_tests; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.imaging_tests (id, test_code, test_name, modality, body_part, price, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: inventory_stock; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.inventory_stock (id, medicine_id, batch_no, batch_number, expiry_date, quantity, min_quantity, purchase_price, sell_price, supplier, updated_at) FROM stdin;
\.


--
-- Data for Name: lab_orders; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.lab_orders (id, patient_name, patient_phone, doctor_username, test_type, test_name, status, result_text, result_file, created_at, completed_at, patient_id, visit_id, prescription_id, urgency, lab_notes) FROM stdin;
35	Vikram Singh	+91 9903000001	Dr. Meena Pillai	Pathology	CBC	pending			2026-03-11 07:23:53.823564	\N	\N	\N	\N	routine	
36	Vikram Singh	+91 9903000001	Dr. Meena Pillai	Pathology	LFT	pending			2026-03-11 07:23:53.824626	\N	\N	\N	\N	routine	
37	Poonam Gupta	+91 9903000002	Dr. Raj Sharma	Pathology	CBC	pending			2026-03-11 07:23:53.825355	\N	\N	\N	\N	routine	
38	Poonam Gupta	+91 9903000002	Dr. Raj Sharma	Pathology	LFT	pending			2026-03-11 07:23:53.826279	\N	\N	\N	\N	routine	
\.


--
-- Data for Name: lab_reports; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.lab_reports (id, order_id, patient_name, patient_phone, test_name, result_text, result_file_path, remarks, lab_username, reported_at) FROM stdin;
1	\N	Mohan Das	9614109329	Complete Blood Count	Hemoglobin: 13.5 g/dL, WBC: 7200, Platelets: 2.8 lakhs – All Normal			\N	2026-03-12 00:00:00
2	\N	Swathi Nair	+91 9903000004	Blood Sugar Fasting	FBS: 98 mg/dL – Normal (ref: 70–100)			\N	2026-03-09 00:00:00
3	\N	Suresh Reddy	9519667910	Urine Routine	Colour: Pale yellow, Pus Cells: 2-4, No sugar, No albumin – Normal			\N	2026-03-06 00:00:00
\.


--
-- Data for Name: lab_results; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.lab_results (result_id, order_id, patient_id, patient_name, test_name, result_value, reference_range, unit, is_abnormal, remarks, lab_username, reported_at) FROM stdin;
\.


--
-- Data for Name: lab_tests; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.lab_tests (id, test_code, test_name, category, normal_range, unit, price, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: medicines; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.medicines (id, medicine_name, generic_name, category, manufacturer, unit, unit_price, is_active, created_at) FROM stdin;
21	City-Ibuprofen 400mg	City-Ibuprofen 400mg	NSAID	Abbott	Tablet	13.00	t	2026-03-11 07:23:53.598715
22	City-Azithromycin 500mg	City-Azithromycin 500mg	Antibiotic	Cipla	Tablet	75.00	t	2026-03-11 07:23:53.605245
23	City-Amlodipine 5mg	City-Amlodipine 5mg	Antihypert	Lupin	Tablet	15.00	t	2026-03-11 07:23:53.60601
24	City-ORS Sachet	City-ORS Sachet	Electrolyte	Electral	Sachet	5.00	t	2026-03-11 07:23:53.606748
25	City-Vitamin D3 60K	City-Vitamin D3 60K	Supplement	HealthVit	Capsule	55.00	t	2026-03-11 07:23:53.607666
\.


--
-- Data for Name: notification_logs; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.notification_logs (id, tenant_slug, channel, event_type, recipient, message, status, error_msg, sent_at) FROM stdin;
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.notification_settings (id, tenant_slug, setting_key, setting_value, updated_by, updated_at) FROM stdin;
1	city_medical	whatsapp_enabled	false	city_medical_admin	2026-03-11 00:04:09.82415
2	city_medical	email_enabled	false	city_medical_admin	2026-03-11 00:04:09.82415
3	city_medical	sms_enabled	false	city_medical_admin	2026-03-11 00:04:09.82415
4	city_medical	notify_on_appointment	true	city_medical_admin	2026-03-11 00:04:09.82415
\.


--
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.notification_templates (id, tenant_slug, event_type, channel, template, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: nurse_assignments; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.nurse_assignments (id, nurse_username, patient_name, patient_phone, ward, bed_number, shift, assigned_at, discharged_at) FROM stdin;
\.


--
-- Data for Name: patient_admissions; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.patient_admissions (id, patient_name, patient_phone, patient_aadhar, age, gender, blood_group, address, admission_date, discharge_date, ward_name, bed_number, admitting_doctor, department, diagnosis, admission_notes, status, created_by, created_at, updated_at) FROM stdin;
1	Vikram Singh	+91 9903000001		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	city_medical_doctor	General Medicine	Fever observation		admitted	city_medical_admin	2026-03-11 00:04:09.82415	2026-03-11 00:04:09.82415
2	Poonam Gupta	+91 9903000002		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	city_medical_doctor	General Medicine	Fever observation		admitted	city_medical_admin	2026-03-11 00:04:09.82415	2026-03-11 00:04:09.82415
3	Vikram Singh	+91 9903000001		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	city_medical_doctor	General Medicine	Fever observation		admitted	city_medical_admin	2026-03-11 00:10:54.557866	2026-03-11 00:10:54.557866
4	Poonam Gupta	+91 9903000002		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	city_medical_doctor	General Medicine	Fever observation		admitted	city_medical_admin	2026-03-11 00:10:54.557866	2026-03-11 00:10:54.557866
5	Mohan Das	+91 9903000003		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	city_medical_doctor	General Medicine	Fever observation		admitted	city_medical_admin	2026-03-11 00:10:54.557866	2026-03-11 00:10:54.557866
6	Vikram Singh	+91 9903000001		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	city_medical_doctor	General Medicine	Fever observation		admitted	city_medical_admin	2026-03-11 00:12:32.00818	2026-03-11 00:12:32.00818
7	Poonam Gupta	+91 9903000002		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	city_medical_doctor	General Medicine	Fever observation		admitted	city_medical_admin	2026-03-11 00:12:32.00818	2026-03-11 00:12:32.00818
8	Mohan Das	+91 9903000003		35	Male			2026-03-11 00:00:00	\N	General Ward	B101	city_medical_doctor	General Medicine	Fever observation		admitted	city_medical_admin	2026-03-11 00:12:32.00818	2026-03-11 00:12:32.00818
\.


--
-- Data for Name: patient_visits; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.patient_visits (visit_id, patient_id, visit_type, doctor_assigned, doctor_username, department, visit_date, chief_complaint, diagnosis, notes, status, op_ticket_no, created_at) FROM stdin;
\.


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.patients (id, full_name, dob, gender, phone, aadhar, address, blood_group, allergies, created_at, updated_at, uhid) FROM stdin;
12	Vikram Singh	1988-01-30	Male	+91 9903000001	300100000001				2026-03-11 07:23:53.534956	2026-03-11 07:23:53.534956	CIT001001
13	Poonam Gupta	1993-06-15	Female	+91 9903000002	300100000002				2026-03-11 07:23:53.536776	2026-03-11 07:23:53.536776	CIT001002
14	Mohan Das	1970-08-22	Male	+91 9903000003	300100000003				2026-03-11 07:23:53.537265	2026-03-11 07:23:53.537265	CIT001003
15	Swathi Nair	1999-03-07	Female	+91 9903000004	300100000004				2026-03-11 07:23:53.537703	2026-03-11 07:23:53.537703	CIT001004
16	Arjun Verma	1985-11-18	Male	+91 9903000005	300100000005				2026-03-11 07:23:53.538123	2026-03-11 07:23:53.538123	CIT001005
17	Rajesh Kumar	1992-03-20	Female	9455718159	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
18	Priya Sharma	1973-03-25	Male	9644726951	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
19	Suresh Reddy	1959-03-29	Male	9519667910	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
20	Anita Devi	1976-03-24	Male	9374824327	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
21	Venkatesh Rao	1999-03-19	Male	9275364098	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
22	Lakshmi Bai	1989-03-21	Female	9739558258	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
23	Mohan Das	1997-03-19	Female	9614109329	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
24	Kavitha Nair	1966-03-27	Male	9330967910	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
25	Ramesh Babu	1998-03-19	Female	9463121498	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
26	Sunita Patel	1989-03-21	Female	9659624720	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
27	Arun Verma	1967-03-27	Female	9517108226	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
28	Meena Kumari	1993-03-20	Female	9548060525	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
29	Srinivas Yadav	1980-03-23	Female	9857496755	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
30	Deepa Singh	1971-03-26	Female	9174166531	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
31	Kishore Kumar	1990-03-21	Male	9413332335	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
32	Bhavani Devi	1988-03-21	Female	9542999855	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
33	Ravi Shankar	1956-03-29	Female	9787048670	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
34	Pooja Gupta	1999-03-19	Female	9346970127	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
35	Naresh Naidu	1972-03-25	Female	9301971884	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
36	Sarala Devi	1991-03-21	Male	9912604063	\N				2026-03-12 02:35:05.003698	2026-03-12 02:35:05.003698	\N
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.payments (id, bill_id, amount_paid, payment_mode, reference_no, received_by, paid_at) FROM stdin;
\.


--
-- Data for Name: pharmacy_sale_items; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.pharmacy_sale_items (id, sale_id, medicine_id, medicine_name, quantity, unit_price, total_price) FROM stdin;
\.


--
-- Data for Name: pharmacy_sales; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.pharmacy_sales (id, patient_name, patient_phone, prescription_id, total_amount, discount, net_amount, payment_mode, staff_username, sold_at) FROM stdin;
\.


--
-- Data for Name: prescription_items; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.prescription_items (item_id, prescription_id, medicine_name, dosage, frequency, duration, instructions, quantity, route, created_at) FROM stdin;
\.


--
-- Data for Name: prescription_medicines; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.prescription_medicines (id, prescription_id, medicine_name, dose, frequency, duration, route, notes, sort_order, created_at) FROM stdin;
\.


--
-- Data for Name: prescriptions; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.prescriptions (id, patient_name, patient_phone, doctor_username, doctor_name, diagnosis, medicines, notes, created_at, chief_complaint, bp, pulse, spo2, follow_up_days, patient_id, visit_id, uhid, created_by_doctor, symptoms, clinical_notes, temperature, weight, diet_advice, special_instructions, follow_up_date) FROM stdin;
\.


--
-- Data for Name: procedure_charges; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.procedure_charges (id, procedure_name, category, default_price, gst_percent, description, is_active, created_at) FROM stdin;
1	OPD Consultation	Consultation	300.00	0.00		t	2026-03-10 18:12:18.162871
2	Specialist Consultation	Consultation	500.00	0.00		t	2026-03-10 18:12:18.162871
3	Dressing / Wound Care	Minor Procedure	200.00	0.00		t	2026-03-10 18:12:18.162871
4	Injection Administration	Minor Procedure	100.00	0.00		t	2026-03-10 18:12:18.162871
5	IV Cannula Insertion	Minor Procedure	150.00	0.00		t	2026-03-10 18:12:18.162871
6	ECG	Diagnostic	300.00	0.00		t	2026-03-10 18:12:18.162871
7	X-Ray Chest PA	Imaging	400.00	0.00		t	2026-03-10 18:12:18.162871
8	Ultrasound Abdomen	Imaging	700.00	0.00		t	2026-03-10 18:12:18.162871
9	MRI Brain	Imaging	4500.00	0.00		t	2026-03-10 18:12:18.162871
10	CT Scan Head	Imaging	3500.00	0.00		t	2026-03-10 18:12:18.162871
11	Complete Blood Count (CBC)	Lab	200.00	0.00		t	2026-03-10 18:12:18.162871
12	Blood Sugar Fasting	Lab	120.00	0.00		t	2026-03-10 18:12:18.162871
13	Urine Routine	Lab	100.00	0.00		t	2026-03-10 18:12:18.162871
14	Lipid Profile	Lab	500.00	0.00		t	2026-03-10 18:12:18.162871
15	Thyroid Profile (T3T4TSH)	Lab	800.00	0.00		t	2026-03-10 18:12:18.162871
16	Appendicectomy	Surgery	18000.00	0.00		t	2026-03-10 18:12:18.162871
17	Caesarean Section	Surgery	35000.00	0.00		t	2026-03-10 18:12:18.162871
18	Hernia Repair	Surgery	22000.00	0.00		t	2026-03-10 18:12:18.162871
19	Cataract Surgery	Surgery	15000.00	0.00		t	2026-03-10 18:12:18.162871
20	LSCS + Tubal Ligation	Surgery	40000.00	0.00		t	2026-03-10 18:12:18.162871
21	General Ward (per day)	Bed Charge	500.00	0.00		t	2026-03-10 18:12:18.162871
22	Semi-Private Ward (per day)	Bed Charge	1200.00	0.00		t	2026-03-10 18:12:18.162871
23	Private Ward (per day)	Bed Charge	2000.00	0.00		t	2026-03-10 18:12:18.162871
24	ICU (per day)	Bed Charge	3500.00	0.00		t	2026-03-10 18:12:18.162871
\.


--
-- Data for Name: registrations; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.registrations (id, name, age, phone, aadhar, issue, doctor, appointment_time, status, source, created_at, updated_at) FROM stdin;
1	Deepa Singh	38	9700222111		Joint pain	Dr. Anand	09:30 AM	pending	demo	2026-03-10 22:14:31.879637	2026-03-10 22:14:31.879637
2	Vijay Kumar	50	9700222112		Eye check	Dr. Preethi	12:00 PM	pending	demo	2026-03-10 22:14:31.879637	2026-03-10 22:14:31.879637
3	Kavita Sharma	27	9700222113		Skin allergy	Dr. Anand	02:30 PM	pending	demo	2026-03-10 22:14:31.879637	2026-03-10 22:14:31.879637
\.


--
-- Data for Name: services_catalogue; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.services_catalogue (service_id, service_name, department, default_price, tax_percentage, active, created_at) FROM stdin;
\.


--
-- Data for Name: staff_users; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.staff_users (id, username, password_hash, role, department, full_name, is_active, must_change_password, created_at) FROM stdin;
1	city_medical_admin	$2b$12$eCfeeQKmNOMoPIH6.8I16O37o6qLVrRpmH/b3z589o0M4XB13a.Uu	ADMIN	Administration	Hospital Administrator	t	f	2026-03-10 22:13:48.859622
2	city_medical_doctor	$2b$12$7yLiYK4HK38KWfSfVwWCIOe2HDRx2m0UozSX7dJFy3tktLqYGQbgO	DOCTOR	General Medicine	Dr. General Physician	t	f	2026-03-10 22:13:48.859622
3	city_medical_nurse	$2b$12$HPNubPSpPxvO08SLJKx3ueINHNdGTmZ0IDTsnpoeh0f7VEzdHeHUC	NURSE	Nursing	Staff Nurse	t	f	2026-03-10 22:13:48.859622
4	city_medical_lab	$2b$12$ST.vxRyDAddcNhiyE7czEeB2MCqNOA5D6qwjsBYAyUgrAmuSOochy	LAB	Pathology	Lab Technician	t	f	2026-03-10 22:13:48.859622
5	city_medical_stock	$2b$12$2IaQ55YgJ4nLEFavl4B/MuZxNAayr3ySJIH5RSqgG1PAGrQIs6Ccy	STOCK	Pharmacy	Pharmacy Staff	t	f	2026-03-10 22:13:48.859622
6	city_medical_reception	$2b$12$E.TW/0F5W9aUAHvVDzYwpOfKMBmHBcvL1M7i/V3eBhWc9M.2q1w9K	RECEPTION	OPD	Receptionist	t	f	2026-03-10 22:13:48.859622
\.


--
-- Data for Name: surgery_records; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.surgery_records (id, admission_id, patient_name, patient_phone, surgeon_name, surgeon_username, surgery_type, anesthesia_type, estimated_cost, negotiated_cost, operation_date, duration_minutes, operation_notes, complications, status, created_by, created_at, updated_at) FROM stdin;
1	\N	Deepa Singh	9100002221	Dr. Ravi Shankar		Appendectomy	General	0.00	0.00	2026-03-09 22:51:23.974186	0			completed		2026-03-10 22:51:23.973174	2026-03-10 22:51:23.973174
2	\N	Vijay Kumar	9100002222	Dr. Sunita Iyer		Knee Arthroscopy	General	0.00	0.00	2026-03-08 22:51:23.977965	0			completed		2026-03-10 22:51:23.973174	2026-03-10 22:51:23.973174
3	\N	Vikram Singh	+91 9903000001	Dr. Surgeon	city_medical_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	city_medical_admin	2026-03-11 00:04:09.82415	2026-03-11 00:04:09.82415
4	\N	Poonam Gupta	+91 9903000002	Dr. Surgeon	city_medical_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	city_medical_admin	2026-03-11 00:04:09.82415	2026-03-11 00:04:09.82415
5	\N	Vikram Singh	+91 9903000001	Dr. Surgeon	city_medical_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	city_medical_admin	2026-03-11 00:10:54.557866	2026-03-11 00:10:54.557866
6	\N	Poonam Gupta	+91 9903000002	Dr. Surgeon	city_medical_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	city_medical_admin	2026-03-11 00:10:54.557866	2026-03-11 00:10:54.557866
7	\N	Vikram Singh	+91 9903000001	Dr. Surgeon	city_medical_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	city_medical_admin	2026-03-11 00:12:32.00818	2026-03-11 00:12:32.00818
8	\N	Poonam Gupta	+91 9903000002	Dr. Surgeon	city_medical_doctor	Appendectomy	General	15000.00	0.00	2026-03-11 00:00:00	0			scheduled	city_medical_admin	2026-03-11 00:12:32.00818	2026-03-11 00:12:32.00818
\.


--
-- Data for Name: system_logs; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.system_logs (id, username, role, action, details, ip_address, logged_at) FROM stdin;
1	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 00:34:33.832491
2	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 00:39:43.567491
3	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 00:41:52.91251
4	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 00:45:32.69909
5	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 06:12:46.744397
6	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 06:15:04.644096
7	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 06:18:53.214431
8	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 06:22:43.905018
9	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 06:26:33.313112
10	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 06:30:18.523106
11	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 07:24:51.660613
12	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 07:29:55.240889
13	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 07:36:08.045085
14	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 08:32:54.679251
15	city_medical_admin	UNKNOWN	login_failed	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 08:49:22.015774
16	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 08:49:54.832425
17	city_medical_admin	ADMIN	login_success	ip=127.0.0.1 tenant=city_medical	127.0.0.1	2026-03-11 08:50:20.948945
\.


--
-- Data for Name: visit_records; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.visit_records (id, patient_name, patient_phone, doctor_username, doctor_name, department, chief_complaint, examination, diagnosis, treatment_plan, follow_up_date, visit_date, created_at) FROM stdin;
\.


--
-- Data for Name: vitals; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.vitals (id, patient_name, patient_phone, nurse_username, bp, pulse, temperature, spo2, weight, notes, recorded_at) FROM stdin;
\.


--
-- Data for Name: wards; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.wards (id, ward_name, ward_type, total_beds, floor, is_active, created_at) FROM stdin;
1	General Male	General	10	Ground	t	2026-03-10 18:12:18.16579
2	General Female	General	10	Ground	t	2026-03-10 18:12:18.16579
3	Private	Private	5	First	t	2026-03-10 18:12:18.16579
4	ICU	ICU	4	Ground	t	2026-03-10 18:12:18.16579
5	Maternity	Maternity	6	First	t	2026-03-10 18:12:18.16579
6	Paediatrics	Paediatrics	5	Second	t	2026-03-10 18:12:18.16579
\.


--
-- Name: appointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.appointments_id_seq', 36, true);


--
-- Name: attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.attendance_id_seq', 63, true);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 17, true);


--
-- Name: bed_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.bed_assignments_id_seq', 1, false);


--
-- Name: beds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.beds_id_seq', 1, false);


--
-- Name: bill_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.bill_items_id_seq', 1, false);


--
-- Name: billing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.billing_id_seq', 32, true);


--
-- Name: daily_rounds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.daily_rounds_id_seq', 1, false);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.departments_id_seq', 1, false);


--
-- Name: discharge_summaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.discharge_summaries_id_seq', 1, false);


--
-- Name: doctor_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.doctor_attendance_id_seq', 1, false);


--
-- Name: doctor_notes_note_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.doctor_notes_note_id_seq', 1, false);


--
-- Name: doctor_rounds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.doctor_rounds_id_seq', 1, false);


--
-- Name: doctors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.doctors_id_seq', 7, true);


--
-- Name: hospital_expenses_expense_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.hospital_expenses_expense_id_seq', 12, true);


--
-- Name: imaging_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.imaging_orders_id_seq', 1, false);


--
-- Name: imaging_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.imaging_reports_id_seq', 1, false);


--
-- Name: imaging_tests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.imaging_tests_id_seq', 1, false);


--
-- Name: inventory_stock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.inventory_stock_id_seq', 10, true);


--
-- Name: lab_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.lab_orders_id_seq', 38, true);


--
-- Name: lab_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.lab_reports_id_seq', 3, true);


--
-- Name: lab_results_result_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.lab_results_result_id_seq', 1, false);


--
-- Name: lab_tests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.lab_tests_id_seq', 1, false);


--
-- Name: medicines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.medicines_id_seq', 25, true);


--
-- Name: notification_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.notification_logs_id_seq', 1, false);


--
-- Name: notification_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.notification_settings_id_seq', 12, true);


--
-- Name: notification_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.notification_templates_id_seq', 1, false);


--
-- Name: nurse_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.nurse_assignments_id_seq', 1, false);


--
-- Name: patient_admissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.patient_admissions_id_seq', 8, true);


--
-- Name: patient_visits_visit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.patient_visits_visit_id_seq', 1, false);


--
-- Name: patients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.patients_id_seq', 36, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- Name: pharmacy_sale_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.pharmacy_sale_items_id_seq', 1, false);


--
-- Name: pharmacy_sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.pharmacy_sales_id_seq', 1, false);


--
-- Name: prescription_items_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.prescription_items_item_id_seq', 1, false);


--
-- Name: prescription_medicines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.prescription_medicines_id_seq', 1, false);


--
-- Name: prescriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.prescriptions_id_seq', 1, false);


--
-- Name: procedure_charges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.procedure_charges_id_seq', 48, true);


--
-- Name: registrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.registrations_id_seq', 3, true);


--
-- Name: services_catalogue_service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.services_catalogue_service_id_seq', 1, false);


--
-- Name: staff_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.staff_users_id_seq', 30, true);


--
-- Name: surgery_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.surgery_records_id_seq', 8, true);


--
-- Name: system_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.system_logs_id_seq', 17, true);


--
-- Name: visit_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.visit_records_id_seq', 1, false);


--
-- Name: vitals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.vitals_id_seq', 1, false);


--
-- Name: wards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.wards_id_seq', 12, true);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: attendance attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: bed_assignments bed_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bed_assignments
    ADD CONSTRAINT bed_assignments_pkey PRIMARY KEY (id);


--
-- Name: beds beds_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.beds
    ADD CONSTRAINT beds_pkey PRIMARY KEY (id);


--
-- Name: beds beds_ward_id_bed_number_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.beds
    ADD CONSTRAINT beds_ward_id_bed_number_key UNIQUE (ward_id, bed_number);


--
-- Name: bill_items bill_items_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bill_items
    ADD CONSTRAINT bill_items_pkey PRIMARY KEY (id);


--
-- Name: billing billing_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.billing
    ADD CONSTRAINT billing_pkey PRIMARY KEY (id);


--
-- Name: daily_rounds daily_rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.daily_rounds
    ADD CONSTRAINT daily_rounds_pkey PRIMARY KEY (id);


--
-- Name: departments departments_name_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_name_key UNIQUE (name);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: discharge_summaries discharge_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.discharge_summaries
    ADD CONSTRAINT discharge_summaries_pkey PRIMARY KEY (id);


--
-- Name: doctor_attendance doctor_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_attendance
    ADD CONSTRAINT doctor_attendance_pkey PRIMARY KEY (id);


--
-- Name: doctor_notes doctor_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_notes
    ADD CONSTRAINT doctor_notes_pkey PRIMARY KEY (note_id);


--
-- Name: doctor_rounds doctor_rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_rounds
    ADD CONSTRAINT doctor_rounds_pkey PRIMARY KEY (id);


--
-- Name: doctors doctors_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_pkey PRIMARY KEY (id);


--
-- Name: hospital_expenses hospital_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.hospital_expenses
    ADD CONSTRAINT hospital_expenses_pkey PRIMARY KEY (expense_id);


--
-- Name: imaging_orders imaging_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_orders
    ADD CONSTRAINT imaging_orders_pkey PRIMARY KEY (id);


--
-- Name: imaging_reports imaging_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_reports
    ADD CONSTRAINT imaging_reports_pkey PRIMARY KEY (id);


--
-- Name: imaging_tests imaging_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_tests
    ADD CONSTRAINT imaging_tests_pkey PRIMARY KEY (id);


--
-- Name: imaging_tests imaging_tests_test_code_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_tests
    ADD CONSTRAINT imaging_tests_test_code_key UNIQUE (test_code);


--
-- Name: inventory_stock inventory_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.inventory_stock
    ADD CONSTRAINT inventory_stock_pkey PRIMARY KEY (id);


--
-- Name: lab_orders lab_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_orders
    ADD CONSTRAINT lab_orders_pkey PRIMARY KEY (id);


--
-- Name: lab_reports lab_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_reports
    ADD CONSTRAINT lab_reports_pkey PRIMARY KEY (id);


--
-- Name: lab_results lab_results_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_results
    ADD CONSTRAINT lab_results_pkey PRIMARY KEY (result_id);


--
-- Name: lab_tests lab_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_tests
    ADD CONSTRAINT lab_tests_pkey PRIMARY KEY (id);


--
-- Name: lab_tests lab_tests_test_code_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_tests
    ADD CONSTRAINT lab_tests_test_code_key UNIQUE (test_code);


--
-- Name: medicines medicines_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.medicines
    ADD CONSTRAINT medicines_pkey PRIMARY KEY (id);


--
-- Name: notification_logs notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_tenant_slug_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_tenant_slug_setting_key_key UNIQUE (tenant_slug, setting_key);


--
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_tenant_slug_event_type_channel_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_tenant_slug_event_type_channel_key UNIQUE (tenant_slug, event_type, channel);


--
-- Name: nurse_assignments nurse_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.nurse_assignments
    ADD CONSTRAINT nurse_assignments_pkey PRIMARY KEY (id);


--
-- Name: patient_admissions patient_admissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patient_admissions
    ADD CONSTRAINT patient_admissions_pkey PRIMARY KEY (id);


--
-- Name: patient_visits patient_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patient_visits
    ADD CONSTRAINT patient_visits_pkey PRIMARY KEY (visit_id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: pharmacy_sale_items pharmacy_sale_items_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sale_items
    ADD CONSTRAINT pharmacy_sale_items_pkey PRIMARY KEY (id);


--
-- Name: pharmacy_sales pharmacy_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sales
    ADD CONSTRAINT pharmacy_sales_pkey PRIMARY KEY (id);


--
-- Name: prescription_items prescription_items_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_items
    ADD CONSTRAINT prescription_items_pkey PRIMARY KEY (item_id);


--
-- Name: prescription_medicines prescription_medicines_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_medicines
    ADD CONSTRAINT prescription_medicines_pkey PRIMARY KEY (id);


--
-- Name: prescriptions prescriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_pkey PRIMARY KEY (id);


--
-- Name: procedure_charges procedure_charges_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.procedure_charges
    ADD CONSTRAINT procedure_charges_pkey PRIMARY KEY (id);


--
-- Name: registrations registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.registrations
    ADD CONSTRAINT registrations_pkey PRIMARY KEY (id);


--
-- Name: services_catalogue services_catalogue_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.services_catalogue
    ADD CONSTRAINT services_catalogue_pkey PRIMARY KEY (service_id);


--
-- Name: staff_users staff_users_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.staff_users
    ADD CONSTRAINT staff_users_pkey PRIMARY KEY (id);


--
-- Name: staff_users staff_users_username_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.staff_users
    ADD CONSTRAINT staff_users_username_key UNIQUE (username);


--
-- Name: surgery_records surgery_records_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.surgery_records
    ADD CONSTRAINT surgery_records_pkey PRIMARY KEY (id);


--
-- Name: system_logs system_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.system_logs
    ADD CONSTRAINT system_logs_pkey PRIMARY KEY (id);


--
-- Name: visit_records visit_records_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.visit_records
    ADD CONSTRAINT visit_records_pkey PRIMARY KEY (id);


--
-- Name: vitals vitals_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.vitals
    ADD CONSTRAINT vitals_pkey PRIMARY KEY (id);


--
-- Name: wards wards_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.wards
    ADD CONSTRAINT wards_pkey PRIMARY KEY (id);


--
-- Name: wards wards_ward_name_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.wards
    ADD CONSTRAINT wards_ward_name_key UNIQUE (ward_name);


--
-- Name: idx_audit_log_created_at; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_audit_log_created_at ON public.audit_log USING btree (created_at DESC);


--
-- Name: idx_dn_patient_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_dn_patient_id ON public.doctor_notes USING btree (patient_id);


--
-- Name: idx_lr_patient_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_lr_patient_id ON public.lab_results USING btree (patient_id);


--
-- Name: idx_patients_uhid; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE UNIQUE INDEX idx_patients_uhid ON public.patients USING btree (uhid) WHERE (uhid IS NOT NULL);


--
-- Name: idx_pi_prescription; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_pi_prescription ON public.prescription_items USING btree (prescription_id);


--
-- Name: idx_pm_presc_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_pm_presc_id ON public.prescription_medicines USING btree (prescription_id);


--
-- Name: idx_pv_patient_id; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_pv_patient_id ON public.patient_visits USING btree (patient_id);


--
-- Name: idx_pv_visit_date; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_pv_visit_date ON public.patient_visits USING btree (visit_date DESC);


--
-- Name: bed_assignments bed_assignments_bed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bed_assignments
    ADD CONSTRAINT bed_assignments_bed_id_fkey FOREIGN KEY (bed_id) REFERENCES public.beds(id) ON DELETE SET NULL;


--
-- Name: beds beds_ward_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.beds
    ADD CONSTRAINT beds_ward_id_fkey FOREIGN KEY (ward_id) REFERENCES public.wards(id) ON DELETE CASCADE;


--
-- Name: bill_items bill_items_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.bill_items
    ADD CONSTRAINT bill_items_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.billing(id) ON DELETE CASCADE;


--
-- Name: daily_rounds daily_rounds_admission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.daily_rounds
    ADD CONSTRAINT daily_rounds_admission_id_fkey FOREIGN KEY (admission_id) REFERENCES public.patient_admissions(id) ON DELETE CASCADE;


--
-- Name: discharge_summaries discharge_summaries_admission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.discharge_summaries
    ADD CONSTRAINT discharge_summaries_admission_id_fkey FOREIGN KEY (admission_id) REFERENCES public.patient_admissions(id) ON DELETE CASCADE;


--
-- Name: doctor_notes doctor_notes_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_notes
    ADD CONSTRAINT doctor_notes_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: doctor_notes doctor_notes_visit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.doctor_notes
    ADD CONSTRAINT doctor_notes_visit_id_fkey FOREIGN KEY (visit_id) REFERENCES public.patient_visits(visit_id) ON DELETE SET NULL;


--
-- Name: discharge_summaries fk_ds_billing; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.discharge_summaries
    ADD CONSTRAINT fk_ds_billing FOREIGN KEY (bill_id) REFERENCES public.billing(id) ON DELETE SET NULL;


--
-- Name: imaging_reports imaging_reports_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.imaging_reports
    ADD CONSTRAINT imaging_reports_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.imaging_orders(id) ON DELETE SET NULL;


--
-- Name: inventory_stock inventory_stock_medicine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.inventory_stock
    ADD CONSTRAINT inventory_stock_medicine_id_fkey FOREIGN KEY (medicine_id) REFERENCES public.medicines(id) ON DELETE CASCADE;


--
-- Name: lab_reports lab_reports_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_reports
    ADD CONSTRAINT lab_reports_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.lab_orders(id) ON DELETE SET NULL;


--
-- Name: lab_results lab_results_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_results
    ADD CONSTRAINT lab_results_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.lab_orders(id) ON DELETE SET NULL;


--
-- Name: lab_results lab_results_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.lab_results
    ADD CONSTRAINT lab_results_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE SET NULL;


--
-- Name: patient_visits patient_visits_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.patient_visits
    ADD CONSTRAINT patient_visits_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: payments payments_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.billing(id) ON DELETE CASCADE;


--
-- Name: pharmacy_sale_items pharmacy_sale_items_medicine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sale_items
    ADD CONSTRAINT pharmacy_sale_items_medicine_id_fkey FOREIGN KEY (medicine_id) REFERENCES public.medicines(id) ON DELETE SET NULL;


--
-- Name: pharmacy_sale_items pharmacy_sale_items_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sale_items
    ADD CONSTRAINT pharmacy_sale_items_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.pharmacy_sales(id) ON DELETE CASCADE;


--
-- Name: pharmacy_sales pharmacy_sales_prescription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.pharmacy_sales
    ADD CONSTRAINT pharmacy_sales_prescription_id_fkey FOREIGN KEY (prescription_id) REFERENCES public.prescriptions(id) ON DELETE SET NULL;


--
-- Name: prescription_items prescription_items_prescription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_items
    ADD CONSTRAINT prescription_items_prescription_id_fkey FOREIGN KEY (prescription_id) REFERENCES public.prescriptions(id) ON DELETE CASCADE;


--
-- Name: prescription_medicines prescription_medicines_prescription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.prescription_medicines
    ADD CONSTRAINT prescription_medicines_prescription_id_fkey FOREIGN KEY (prescription_id) REFERENCES public.prescriptions(id) ON DELETE CASCADE;


--
-- Name: surgery_records surgery_records_admission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.surgery_records
    ADD CONSTRAINT surgery_records_admission_id_fkey FOREIGN KEY (admission_id) REFERENCES public.patient_admissions(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict yBaxLgKKZhtPFB2N91MNuLgogbbUm12Pu2kgUClm0Mn5eCPtPztf0Pt7xUFaLaq

