--
-- PostgreSQL database dump
--

\restrict aaICqysNt1QEjoFCcO6NsCQH4FViyb9wR4q9I4Y9GBluFvOqUuHogjEGlZexpST

-- Dumped from database version 17.8
-- Dumped by pg_dump version 17.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    actor text NOT NULL,
    action text NOT NULL,
    target text DEFAULT ''::text,
    ip_address text DEFAULT ''::text,
    client_slug text,
    details text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_logs OWNER TO ats_user;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO ats_user;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: clients; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.clients (
    id integer NOT NULL,
    hospital_name text NOT NULL,
    slug text NOT NULL,
    city text DEFAULT ''::text,
    phone text DEFAULT ''::text,
    db_name text DEFAULT ''::text,
    db_host text DEFAULT 'localhost'::text,
    db_port integer DEFAULT 5432,
    db_user text DEFAULT 'ats_user'::text,
    admin_user text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status text DEFAULT 'active'::text,
    last_activity timestamp without time zone,
    subdomain text DEFAULT ''::text
);


ALTER TABLE public.clients OWNER TO ats_user;

--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.clients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clients_id_seq OWNER TO ats_user;

--
-- Name: clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.clients_id_seq OWNED BY public.clients.id;


--
-- Name: founder_accounts; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.founder_accounts (
    id integer NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    email text DEFAULT ''::text,
    full_name text DEFAULT ''::text,
    is_active boolean DEFAULT true,
    last_login timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.founder_accounts OWNER TO ats_user;

--
-- Name: founder_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.founder_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.founder_accounts_id_seq OWNER TO ats_user;

--
-- Name: founder_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.founder_accounts_id_seq OWNED BY public.founder_accounts.id;


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.subscriptions (
    id integer NOT NULL,
    client_slug text NOT NULL,
    plan text DEFAULT 'starter'::text,
    status text DEFAULT 'trial'::text,
    start_date date DEFAULT CURRENT_DATE,
    expiry_date date,
    amount_paid numeric(12,2) DEFAULT 0,
    currency text DEFAULT 'INR'::text,
    notes text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.subscriptions OWNER TO ats_user;

--
-- Name: subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subscriptions_id_seq OWNER TO ats_user;

--
-- Name: subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.subscriptions_id_seq OWNED BY public.subscriptions.id;


--
-- Name: system_alerts; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.system_alerts (
    id integer NOT NULL,
    event_type text NOT NULL,
    message text NOT NULL,
    severity text DEFAULT 'info'::text,
    client_slug text,
    resolved boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_alerts OWNER TO ats_user;

--
-- Name: system_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.system_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_alerts_id_seq OWNER TO ats_user;

--
-- Name: system_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.system_alerts_id_seq OWNED BY public.system_alerts.id;


--
-- Name: system_health; Type: TABLE; Schema: public; Owner: ats_user
--

CREATE TABLE public.system_health (
    id integer NOT NULL,
    client_slug text NOT NULL,
    db_status text DEFAULT 'unknown'::text,
    tables_present boolean DEFAULT false,
    missing_tables text DEFAULT '[]'::text,
    checked_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_health OWNER TO ats_user;

--
-- Name: system_health_id_seq; Type: SEQUENCE; Schema: public; Owner: ats_user
--

CREATE SEQUENCE public.system_health_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_health_id_seq OWNER TO ats_user;

--
-- Name: system_health_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ats_user
--

ALTER SEQUENCE public.system_health_id_seq OWNED BY public.system_health.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_id_seq'::regclass);


--
-- Name: founder_accounts id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.founder_accounts ALTER COLUMN id SET DEFAULT nextval('public.founder_accounts_id_seq'::regclass);


--
-- Name: subscriptions id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.subscriptions ALTER COLUMN id SET DEFAULT nextval('public.subscriptions_id_seq'::regclass);


--
-- Name: system_alerts id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.system_alerts ALTER COLUMN id SET DEFAULT nextval('public.system_alerts_id_seq'::regclass);


--
-- Name: system_health id; Type: DEFAULT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.system_health ALTER COLUMN id SET DEFAULT nextval('public.system_health_id_seq'::regclass);


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.audit_logs (id, actor, action, target, ip_address, client_slug, details, created_at) FROM stdin;
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.clients (id, hospital_name, slug, city, phone, db_name, db_host, db_port, db_user, admin_user, created_at, status, last_activity, subdomain) FROM stdin;
1	Star Hospital	star_hospital	Khammam	+91 7981971015	hospital_ai	localhost	5432	ats_user	star_hospital_admin	2026-03-10 07:06:48.85939	active	\N	starhospital
2	Sai Care Hospital	sai_care	Khammam	+91 9100000001	srp_sai_care	localhost	5432	ats_user	sai_care_admin	2026-03-10 07:06:48.973063	active	\N	saicare
3	City Medical Centre	city_medical	Hyderabad	+91 9100000002	srp_city_medical	localhost	5432	ats_user	city_medical_admin	2026-03-10 07:06:49.098093	active	\N	citymedical
4	Apollo Clinic Warangal	apollo_warangal	Warangal	+91 9100000003	srp_apollo_warangal	localhost	5432	ats_user	apollo_warangal_admin	2026-03-10 07:06:49.219024	active	\N	apollowarangal
5	Green Cross Hospital	green_cross	Vijayawada	+91 9100000004	srp_green_cross	localhost	5432	ats_user	green_cross_admin	2026-03-10 07:06:49.361362	active	\N	greencross
\.


--
-- Data for Name: founder_accounts; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.founder_accounts (id, username, password_hash, email, full_name, is_active, last_login, created_at) FROM stdin;
1	founder	$2b$12$qXRh/JxIJKxuLGNu8wWvpemD1crOHPKvTV/ceaBWv8g2D.Nsl6PNi	founder@srpailabs.com	SRP Technologies Founder	t	2026-03-11 08:50:04.87144	2026-03-10 08:51:44.614606
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.subscriptions (id, client_slug, plan, status, start_date, expiry_date, amount_paid, currency, notes, created_at) FROM stdin;
\.


--
-- Data for Name: system_alerts; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.system_alerts (id, event_type, message, severity, client_slug, resolved, created_at) FROM stdin;
1	BACKUP_OK	All 6 database backups completed successfully.	info	\N	f	2026-03-11 02:00:08.151686
\.


--
-- Data for Name: system_health; Type: TABLE DATA; Schema: public; Owner: ats_user
--

COPY public.system_health (id, client_slug, db_status, tables_present, missing_tables, checked_at) FROM stdin;
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.clients_id_seq', 215, true);


--
-- Name: founder_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.founder_accounts_id_seq', 1, true);


--
-- Name: subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.subscriptions_id_seq', 1, false);


--
-- Name: system_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.system_alerts_id_seq', 1, true);


--
-- Name: system_health_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ats_user
--

SELECT pg_catalog.setval('public.system_health_id_seq', 1, false);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: clients clients_slug_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_slug_key UNIQUE (slug);


--
-- Name: founder_accounts founder_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.founder_accounts
    ADD CONSTRAINT founder_accounts_pkey PRIMARY KEY (id);


--
-- Name: founder_accounts founder_accounts_username_key; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.founder_accounts
    ADD CONSTRAINT founder_accounts_username_key UNIQUE (username);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: system_alerts system_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.system_alerts
    ADD CONSTRAINT system_alerts_pkey PRIMARY KEY (id);


--
-- Name: system_health system_health_pkey; Type: CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.system_health
    ADD CONSTRAINT system_health_pkey PRIMARY KEY (id);


--
-- Name: idx_alerts_created; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_alerts_created ON public.system_alerts USING btree (created_at DESC);


--
-- Name: idx_alerts_severity; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_alerts_severity ON public.system_alerts USING btree (severity);


--
-- Name: idx_audit_actor; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_audit_actor ON public.audit_logs USING btree (actor);


--
-- Name: idx_audit_created; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_audit_created ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_clients_slug; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE UNIQUE INDEX idx_clients_slug ON public.clients USING btree (slug);


--
-- Name: idx_clients_subdomain; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_clients_subdomain ON public.clients USING btree (subdomain);


--
-- Name: idx_health_checked; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_health_checked ON public.system_health USING btree (checked_at DESC);


--
-- Name: idx_health_slug; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_health_slug ON public.system_health USING btree (client_slug);


--
-- Name: idx_subscriptions_slug; Type: INDEX; Schema: public; Owner: ats_user
--

CREATE INDEX idx_subscriptions_slug ON public.subscriptions USING btree (client_slug);


--
-- Name: subscriptions subscriptions_client_slug_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ats_user
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_client_slug_fkey FOREIGN KEY (client_slug) REFERENCES public.clients(slug) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict aaICqysNt1QEjoFCcO6NsCQH4FViyb9wR4q9I4Y9GBluFvOqUuHogjEGlZexpST

